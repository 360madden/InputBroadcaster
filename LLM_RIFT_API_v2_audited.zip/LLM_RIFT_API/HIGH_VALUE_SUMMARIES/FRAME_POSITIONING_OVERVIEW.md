# Frame Positioning Overview

**Confidence:** High

## Purpose
This summary isolates the positioning and sizing APIs most relevant to placing Rift UI elements accurately.

## Verified from docs
- `Frame:SetPoint` pins a point on one frame to a location on another frame and supports both named anchor points and numeric coordinate pairs. Relevant raw docs: `Frame/frame_setpoint.md`.
- The documented anchor identifiers include `TOPLEFT`, `TOPCENTER`, `TOPRIGHT`, `CENTERLEFT`, `CENTER`, `CENTERRIGHT`, `BOTTOMLEFT`, `BOTTOMCENTER`, and `BOTTOMRIGHT`, along with axis forms such as `TOP`, `BOTTOM`, `LEFT`, `RIGHT`, `CENTERX`, and `CENTERY`. Relevant raw docs: `Frame/frame_setpoint.md`.
- `Frame:ClearAll` clears all set points and sizes from a frame. Relevant raw docs: `Frame/frame_clearall.md`.
- Frame and related UI types expose width/height setters and getters in their category docs. Relevant raw docs: `Frame/frame_setwidth.md`, `Frame/frame_setheight.md`, plus equivalent docs in `Text/`, `Texture/`, `Canvas/`, and widget folders.
- `Native:GetBounds`, `Native:GetLeft`, `Native:GetTop`, `Native:GetWidth`, and related geometry methods are documented in the Native category. Relevant raw docs: `Native/native_getbounds.md`, `Native/native_getleft.md`, `Native/native_gettop.md`, `Native/native_getwidth.md`.

## Strong inference
- The normal safe reset pattern before re-anchoring a frame is to clear existing points/sizes when needed, then call `SetPoint` again with the desired anchors and offsets.
- Because multiple UI element categories repeat the same positioning methods, positioning behavior is meant to be broadly consistent across frame-like UI elements.
- The base `Frame` positioning docs are the best canonical reference even when the target object is a widget subtype that exposes the same method names.

## Not established here
- This dump does not give complete worked positioning recipes for every widget type.
- This dump does not by itself document community-preferred layout idioms, drag systems, or resize-handle implementations.

## Most relevant raw docs
- `Frame/frame_setpoint.md`
- `Frame/frame_clearall.md`
- `Frame/frame_setwidth.md`
- `Frame/frame_setheight.md`
- `Native/native_getbounds.md`
- `Native/native_getleft.md`
- `Native/native_gettop.md`
- `Native/native_getwidth.md`
- `Native/native_getheight.md`

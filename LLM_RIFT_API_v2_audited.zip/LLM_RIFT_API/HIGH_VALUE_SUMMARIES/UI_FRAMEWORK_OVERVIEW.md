# UI Framework Overview

**Confidence:** High

## Purpose
This summary identifies the documented foundation for building Rift addon UI: contexts, frames, widget types, text, textures, and shared native behavior.

## Verified from docs
- `UI.CreateContext` creates a UI context, and a context must exist before frames can be created. Relevant raw docs: `UI/ui_createcontext.md`.
- `UI.CreateFrame` creates frames and explicitly lists valid frame types including `Frame`, `Mask`, `Text`, `Texture`, `RiftButton`, `RiftCheckbox`, `RiftScrollbar`, `RiftSlider`, `RiftTextfield`, and `RiftWindow`. Relevant raw docs: `UI/ui_createframe.md`.
- The docs state that contexts are guaranteed to have at least the capabilities of a `Frame`. Relevant raw docs: `UI/ui_createcontext.md`, `Context/context.md`.
- `Text:SetText` sets the current text of a text element and optionally enables a limited HTML mode. Relevant raw docs: `Text/text_settext.md`.
- `Texture:SetTexture` sets the texture source and texture identifier for a texture element. Relevant raw docs: `Texture/texture_settexture.md`.
- `Native:SetLayer` controls draw order, with frames drawn in ascending order, after their parents. Relevant raw docs: `Native/native_setlayer.md`.
- `Native:EventAttach` and the equivalent frame/widget `:EventAttach` methods attach frame-level handlers for UI events. Relevant raw docs: `Native/native_eventattach.md`, `Frame/frame_eventattach.md`, `Canvas/canvas_eventattach.md`.

## Strong inference
- The intended construction flow is: create a context, create one or more frames or widgets under that context, anchor/size them, then attach events and populate text or textures.
- Because `UI.CreateFrame` lists the standard widget types directly, it is the main factory entry point for most addon UI work rather than a collection of separate widget constructors.
- `Native` appears to represent a shared behavior layer across multiple UI element types, while `Frame`, `Canvas`, `Text`, `Texture`, and Rift widgets provide type-specific APIs on top.

## Not established here
- This dump does not by itself define best-practice widget composition patterns beyond the explicit API descriptions.
- This dump does not prove undocumented layout conventions, theming conventions, or community-standard control wrappers.
- This dump does not by itself show complete end-to-end example addons.

## Most relevant raw docs
- `UI/ui_createcontext.md`
- `UI/ui_createframe.md`
- `Context/context.md`
- `Frame/frame.md`
- `Canvas/canvas.md`
- `Text/text.md`
- `Text/text_settext.md`
- `Texture/texture.md`
- `Texture/texture_settexture.md`
- `Native/native.md`
- `Native/native_eventattach.md`
- `Native/native_setlayer.md`

# Event System Overview

**Confidence:** High

## Purpose
This summary separates global events from frame-local events and highlights the documented event attachment and inspection APIs.

## Verified from docs
- `Command.Event.Attach` attaches a handler to a global event handle from the `Event.` hierarchy, with an optional priority. Relevant raw docs: `Event/command_event_attach.md`.
- `Command.Event.Detach` detaches handlers from a global event. Relevant raw docs: `Event/command_event_detach.md`.
- `Inspect.Event.List` lists currently attached handlers for a global event and returns handler, label, owner, and priority data. Relevant raw docs: `Event/inspect_event_list.md`.
- `Utility.Event.Create` creates a custom event under `Event.Identifier.Path` and returns both a caller function and the resulting handle. Relevant raw docs: `Event/utility_event_create.md`.
- `Native:EventAttach` attaches a frame-level handler to a frame event handle, usually from the `Event.UI.` hierarchy. Relevant raw docs: `Native/native_eventattach.md`.
- The UI categories document many input and frame events such as key, mouse, move, size, and layer changes. Relevant raw docs include `UI/`, `Frame/`, `Canvas/`, and widget folders.

## Strong inference
- Rift’s addon event model is intentionally split between global event tables (`Command.Event.Attach`) and frame/widget event tables (`:EventAttach` on UI elements).
- For live UI addons, the usual architecture is event-driven rather than relying only on repeated polling.
- `Inspect.Event.List` is primarily useful for debugging or introspection of the current event registration state.

## Not established here
- This dump does not prescribe a single preferred architecture for large event-driven addons.
- This dump does not by itself quantify performance tradeoffs between different event patterns.

## Most relevant raw docs
- `Event/command_event_attach.md`
- `Event/command_event_detach.md`
- `Event/inspect_event_list.md`
- `Event/utility_event_create.md`
- `Native/native_eventattach.md`
- `Native/native_eventdetach.md`
- `Frame/frame_eventattach.md`
- `Canvas/canvas_eventattach.md`
- `UI/` event docs such as `event_ui_input_key_down.md`

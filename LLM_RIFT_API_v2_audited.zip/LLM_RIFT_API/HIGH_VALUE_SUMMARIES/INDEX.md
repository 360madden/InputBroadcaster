# High Value Summaries

Read these after `START_HERE_FOR_CODE.md` and before digging into raw category files.

## Recommended order
1. `UI_FRAMEWORK_OVERVIEW.md`
2. `FRAME_POSITIONING_OVERVIEW.md`
3. `EVENT_SYSTEM_OVERVIEW.md`
4. `UNIT_AND_TARGET_OVERVIEW.md`
5. `INSPECT_API_OVERVIEW.md`
6. `COMMAND_AND_SLASH_OVERVIEW.md`
7. `MAP_AND_COORDINATE_OVERVIEW.md`
8. `SETTINGS_AND_PERSISTENCE_OVERVIEW.md`

## What these are
These files are synthesis layers meant to route the model to the right subsystem quickly.

## What these are not
They are not the final authority for signatures, payload shapes, return tables, or undocumented behavior. Use the raw category files for exact wording.

# Map and Coordinate Overview

**Confidence:** Medium

## Purpose
This summary isolates the documented APIs for map locations, waypoint control, coordinate reads, and coordinate-change events.

## Verified from docs
- `Inspect.Map.List` returns valid map locations in `{id = true}` form. Relevant raw docs: `Map/inspect_map_list.md`.
- `Inspect.Map.Detail` returns detail for one or more map locations, including `coordX`, `coordY`, `coordZ`, `description`, `id`, and `title`. Relevant raw docs: `Map/inspect_map_detail.md`.
- `Event.Map.Detail.Coord` signals coordinate changes for map elements and passes per-element tables for X, Y, and Z. Relevant raw docs: `Map/event_map_detail_coord.md`.
- `Command.Map.Waypoint.Set` sets the player waypoint using X and Z coordinates, and `Command.Map.Waypoint.Clear` clears it. Relevant raw docs: `Map/command_map_waypoint_set.md`, `Map/command_map_waypoint_clear.md`.
- `Command.Map.Monitor` controls whether main-map data is monitored continuously or only while the built-in map window is open. Relevant raw docs: `Map/command_map_monitor.md`.
- `Inspect.Unit.Detail` also documents per-unit coordinates `coordX`, `coordY`, and `coordZ`. Relevant raw docs: `Unit/inspect_unit_detail.md`.

## Strong inference
- Coordinate-aware addons may need both map-location APIs and unit-detail APIs, depending on whether the target is a map element or a live unit.
- `Command.Map.Monitor` is likely important when an addon expects map data updates outside the built-in map window context.

## Not established here
- This dump does not document a complete built-in range calculation API between arbitrary units.
- This dump does not by itself prove that map coordinates and unit coordinates can always be interchanged without context-specific handling.

## Most relevant raw docs
- `Map/inspect_map_list.md`
- `Map/inspect_map_detail.md`
- `Map/event_map_detail_coord.md`
- `Map/command_map_waypoint_set.md`
- `Map/command_map_waypoint_clear.md`
- `Map/command_map_monitor.md`
- `Unit/inspect_unit_detail.md`
- `Unit/event_unit_detail_coord.md`

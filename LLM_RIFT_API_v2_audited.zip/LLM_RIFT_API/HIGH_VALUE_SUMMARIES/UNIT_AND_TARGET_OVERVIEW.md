# Unit and Target Overview

**Confidence:** High

## Purpose
This summary identifies the documented unit-data entry points most useful for addons that read player, target, or other unit information.

## Verified from docs
- `Inspect.Unit.Detail` provides detailed information about one unit or a table of units. Relevant raw docs: `Unit/inspect_unit_detail.md`.
- The documented members of `Inspect.Unit.Detail` include identity, combat/resource, targeting, and coordinate fields such as `id`, `name`, `level`, `health`, `mana`, `target`, `coordX`, `coordY`, and `coordZ`, along with many more conditional fields. Relevant raw docs: `Unit/inspect_unit_detail.md`.
- `Event.Unit.Detail.Coord` signals changes in unit location and passes per-element tables for X, Y, and Z. Relevant raw docs: `Unit/event_unit_detail_coord.md`.
- The Unit category also documents availability and other per-field change events. Relevant raw docs: `Unit/INDEX.md` and the individual `Unit/` event docs.
- `Command.Unit.Menu` creates a standard context menu for the chosen unit. Relevant raw docs: `Unit/command_unit_menu.md`.

## Strong inference
- `Inspect.Unit.Detail` is the main documented foundation for addons that need player or target facts, rather than assembling those facts from many smaller one-off APIs.
- For coordinate-aware addons, `Inspect.Unit.Detail` plus `Event.Unit.Detail.Coord` is the most direct documented pairing in this dump.
- The availability/detail event families appear intended to let addons refresh only when relevant unit data changes.

## Not established here
- This dump does not prove that every unit specifier or every target-adjacent use case will behave identically in all gameplay contexts.
- This dump does not by itself define a complete “best target tracking architecture” beyond the explicit APIs and events.

## Most relevant raw docs
- `Unit/inspect_unit_detail.md`
- `Unit/inspect_unit_list.md`
- `Unit/event_unit_detail_coord.md`
- `Unit/event_unit_availability_full.md`
- `Unit/event_unit_availability_partial.md`
- `Unit/event_unit_availability_none.md`
- `Unit/command_unit_menu.md`

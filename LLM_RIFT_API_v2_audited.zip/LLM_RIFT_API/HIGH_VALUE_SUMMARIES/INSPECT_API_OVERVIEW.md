# Inspect API Overview

**Confidence:** High

## Purpose
This summary highlights how the dump uses `Inspect.*` calls as the main read-only discovery layer for addon state, entities, and environment data.

## Verified from docs
- Many categories expose `Inspect.*.Detail` and `Inspect.*.List` functions for reading detailed information or enumerating valid identifiers. Examples include `Inspect.Unit.Detail`, `Inspect.Unit.List`, `Inspect.Map.Detail`, `Inspect.Map.List`, `Inspect.Setting.Detail`, and `Inspect.Setting.List`. Relevant raw docs: `Unit/`, `Map/`, `Setting/`.
- `Inspect.Event.List` reads the registered handlers for a global event. Relevant raw docs: `Event/inspect_event_list.md`.
- `Inspect.Addon.Cpu` and `Inspect.Addon.Memory` are documented in the Addon category. Relevant raw docs: `Addon/inspect_addon_cpu.md`, `Addon/inspect_addon_memory.md`.
- The dump repeatedly uses `Detail` for richer per-identifier data and `List` for discovery/enumeration tables.

## Strong inference
- A practical reading pattern is: first call a `List` function to enumerate identifiers, then call the corresponding `Detail` function on one or more of those identifiers.
- The `Inspect` layer is a primary source of addon-readable state, while `Event.*` families are the primary change-notification layer.
- Pairing `Inspect` with events is the documented way to keep addon data current without guessing at hidden state.

## Not established here
- This dump does not define a universal batching strategy or performance guidance for all `Inspect.*` calls.
- This dump does not imply that every category supports identical `List`/`Detail` semantics beyond what each raw page states.

## Most relevant raw docs
- `Unit/inspect_unit_detail.md`
- `Unit/inspect_unit_list.md`
- `Map/inspect_map_detail.md`
- `Map/inspect_map_list.md`
- `Setting/inspect_setting_detail.md`
- `Setting/inspect_setting_list.md`
- `Event/inspect_event_list.md`
- `Addon/inspect_addon_cpu.md`
- `Addon/inspect_addon_memory.md`

# Command and Slash Overview

**Confidence:** High

## Purpose
This summary collects the documented command-side APIs that are most useful for addon control surfaces and user entry points.

## Verified from docs
- `Command.Slash.Register` registers a slash command, creates a corresponding handle under `Event.Slash`, and returns that handle. Relevant raw docs: `Slash/command_slash_register.md`.
- The docs state that registering the same slash command again returns the same event table, and that registration can fail when the command conflicts with a built-in slash command. Relevant raw docs: `Slash/command_slash_register.md`.
- `Command.Event.Attach` and `Command.Event.Detach` are the global registration APIs for attaching logic to event handles. Relevant raw docs: `Event/command_event_attach.md`, `Event/command_event_detach.md`.
- The command layer also includes specific operational commands such as `Command.Map.Waypoint.Set`, `Command.Map.Waypoint.Clear`, `Command.Map.Monitor`, `Command.UI.Error`, and `Command.Unit.Menu`. Relevant raw docs: `Map/`, `UI/`, `Unit/`.

## Strong inference
- The intended slash-command workflow is: register the slash command, receive the returned event handle, then attach a handler to that event handle.
- `Command.*` functions are the imperative/action side of the API, complementing `Inspect.*` for reads and `Event.*` for change notifications.

## Not established here
- This dump does not document a single best command parsing framework for complex slash commands.
- This dump does not by itself define UX conventions for slash usage, aliases, or help text.

## Most relevant raw docs
- `Slash/command_slash_register.md`
- `Event/command_event_attach.md`
- `Event/command_event_detach.md`
- `Map/command_map_waypoint_set.md`
- `Map/command_map_waypoint_clear.md`
- `Map/command_map_monitor.md`
- `UI/command_ui_error.md`
- `Unit/command_unit_menu.md`

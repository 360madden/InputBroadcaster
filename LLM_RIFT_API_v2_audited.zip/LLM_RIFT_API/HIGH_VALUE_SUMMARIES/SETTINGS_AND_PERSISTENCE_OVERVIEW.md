# Settings and Persistence Overview

**Confidence:** Medium

## Purpose
This summary covers the documented APIs and lifecycle events related to addon saved variables and current setting inspection.

## Verified from docs
- `Event.Addon.SavedVariables.Load.Begin` and `Event.Addon.SavedVariables.Load.End` signal the beginning and end of an addon's saved-variable loading sequence. Relevant raw docs: `Addon/event_addon_savedvariables_load_begin.md`, `Addon/event_addon_savedvariables_load_end.md`.
- `Event.Addon.SavedVariables.Save.Begin` and `Event.Addon.SavedVariables.Save.End` signal the beginning and end of an addon's saved-variable saving sequence. Relevant raw docs: `Addon/event_addon_savedvariables_save_begin.md`, `Addon/event_addon_savedvariables_save_end.md`.
- `Event.Addon.Startup.End` signals that all addons are fully loaded and initialized. Relevant raw docs: `Addon/event_addon_startup_end.md`.
- `Inspect.Setting.List` lists current player settings. Relevant raw docs: `Setting/inspect_setting_list.md`.
- `Inspect.Setting.Detail` returns `id` and `value` for a setting or table of settings. Relevant raw docs: `Setting/inspect_setting_detail.md`.

## Strong inference
- The documented saved-variable events define the safest timing checkpoints for load/save-related addon logic.
- `Inspect.Setting.*` covers current settings inspection, but it is distinct from addon-specific saved-variable lifecycle events.
- `Event.Addon.Startup.End` is the broadest documented signal that the addon environment has finished loading.

## Not established here
- This dump does not, by itself, document the full write path or storage structure for addon saved variables.
- This dump does not by itself define naming conventions or serialization patterns for addon persistence.

## Most relevant raw docs
- `Addon/event_addon_savedvariables_load_begin.md`
- `Addon/event_addon_savedvariables_load_end.md`
- `Addon/event_addon_savedvariables_save_begin.md`
- `Addon/event_addon_savedvariables_save_end.md`
- `Addon/event_addon_startup_end.md`
- `Setting/inspect_setting_list.md`
- `Setting/inspect_setting_detail.md`

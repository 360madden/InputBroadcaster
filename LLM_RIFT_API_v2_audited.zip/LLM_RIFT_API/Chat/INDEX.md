# Chat
**Priority:** Secondary
**Purpose:** Chat inspection and chat-related events.
**Entry count:** 2
## Most important files first
- [Event.Chat.Notify](event_chat_notify.md) — Signals a screen notification. This is generally used as a warning mechanism during boss fights.
- [Event.Chat.Npc](event_chat_npc.md) — Signals an NPC speaking a line of text.

## Full file list
- [Event.Chat.Notify](event_chat_notify.md) — Signals a screen notification. This is generally used as a warning mechanism during boss fights.
- [Event.Chat.Npc](event_chat_npc.md) — Signals an NPC speaking a line of text.

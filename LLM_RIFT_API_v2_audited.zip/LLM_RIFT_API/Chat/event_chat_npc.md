# Event.Chat.Npc

- Original source: event_chat_npc.html
- Category: Chat
- Priority tier: Secondary
- Source index: Chat_index.html

**Doc summary:** Signals an NPC speaking a line of text.

Signals an NPC speaking a line of text.

### Usage:

| --- | --- | --- | --- |
| Event.Chat.Npc(*info*) | | | |
| Parameter | Type | Datatype | Description |
| *info* | parameter | *variant* | Detailed information table about this event, containing several named parameters. |

**members**
:   |  |  |
    | --- | --- |
    | from | The unit ID of the speaker, if available. |
    | fromName | The name of the speaker. |
    | message | The text said. |

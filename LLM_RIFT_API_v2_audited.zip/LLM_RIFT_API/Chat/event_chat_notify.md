# Event.Chat.Notify

- Original source: event_chat_notify.html
- Category: Chat
- Priority tier: Secondary
- Source index: Chat_index.html

**Doc summary:** Signals a screen notification. This is generally used as a warning mechanism during boss fights.

Signals a screen notification. This is generally used as a warning mechanism during boss fights.

### Usage:

| --- | --- | --- | --- |
| Event.Chat.Notify(*info*) | | | |
| Parameter | Type | Datatype | Description |
| *info* | parameter | *variant* | Detailed information table about this event, containing several named parameters. |

**members**
:   |  |  |
    | --- | --- |
    | message | The text said. |

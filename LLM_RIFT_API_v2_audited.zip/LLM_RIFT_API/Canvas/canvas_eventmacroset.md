# Canvas:EventMacroSet

- Original source: canvas_eventmacroset.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Sets the macro that will be triggered when this event occurs.

Sets the macro that will be triggered when this event occurs.

### Usage:

| --- | --- | --- | --- |
| Layout:EventMacroSet(*handle*, *macro*) | | | |
| Parameter | Type | Datatype | Description |
| *handle* | parameter | *eventFrame* | A handle to a frame event, usually pulled out of the "Event.UI." hierarchy. |
| *macro* | parameter | *string/nil* | The macro to trigger. nil to clear the macro. |

**requireSecureFrameAndInsecureEnvironment**
:   true

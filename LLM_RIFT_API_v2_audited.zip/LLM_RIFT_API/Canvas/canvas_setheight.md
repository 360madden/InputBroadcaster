# Canvas:SetHeight

- Original source: canvas_setheight.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Sets the height of this frame. Undefined results if the frame already has two pinned Y coordinates.

Sets the height of this frame. Undefined results if the frame already has two pinned Y coordinates.

### Usage:

| --- | --- | --- | --- |
| Frame:SetHeight(*height*) | | | |
| Parameter | Type | Datatype | Description |
| *height* | parameter | *number* | The new height of this frame. |

**noSecureFrameAndEnvironment**
:   true

# Canvas:GetChildren

- Original source: canvas_getchildren.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Returns a table containing all of this element's children.

Returns a table containing all of this element's children.

### Usage:

| --- | --- | --- | --- |
| *children* = Element:GetChildren() | | | |
| Parameter | Type | Datatype | Description |
| *children* | result | *table* | A table containing this element's children. |

# Canvas:GetType

- Original source: canvas_gettype.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Retrieves the type of this element.

Retrieves the type of this element.

### Usage:

| --- | --- | --- | --- |
| *type* = Layout:GetType() | | | |
| Parameter | Type | Datatype | Description |
| *type* | result | *string* | The type of this element. |

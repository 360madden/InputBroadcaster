# Canvas.Event:KeyDown

- Original source: canvas_event_keydown.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals a key pressed.

Signals a key pressed.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyDown(*button*) | | | |
| Parameter | Type | Datatype | Description |
| *button* | parameter | *variant* | The key, in string form. |

# Canvas.Event:MiddleClick

- Original source: canvas_event_middleclick.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse's middle button has been clicked inside the frame. Blocks middle mouse events from frames below this one.

Signals that the mouse's middle button has been clicked inside the frame. Blocks middle mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:MiddleClick() | | | |

# Canvas:SetMouseMasking

- Original source: canvas_setmousemasking.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Sets the frame's mouse masking mode.

Sets the frame's mouse masking mode.

### Usage:

| --- | --- | --- | --- |
| Element:SetMouseMasking(*mask*) | | | |
| Parameter | Type | Datatype | Description |
| *mask* | parameter | *string* | The new mouse masking mode. "full" is the standard mode, and means that creating any Left, Right, or movement-related mouse event will cause the frame to accept and consume any event from any of those types. "limited" causes the frame to accept and consume only events for buttons that have been hooked, so that hooking "LeftDown" will still pass Right mouse events through the frame. Note that hooking any mouse event will still consume MouseMove/In/Out events. |

**noSecureFrameAndEnvironment**
:   true

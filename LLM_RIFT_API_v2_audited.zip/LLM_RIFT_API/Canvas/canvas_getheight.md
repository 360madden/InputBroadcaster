# Canvas:GetHeight

- Original source: canvas_getheight.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Retrieves the height of this element.

Retrieves the height of this element.

### Usage:

| --- | --- | --- | --- |
| *height* = Layout:GetHeight() | | | |
| Parameter | Type | Datatype | Description |
| *height* | result | *number* | The height of this element. |

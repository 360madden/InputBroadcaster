# Canvas.Event:Move

- Original source: canvas_event_move.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the frame's vertices have moved.

Signals that the frame's vertices have moved.

### Usage:

| --- | --- | --- | --- |
| Layout.Event:Move() | | | |

# Canvas.Event:Strata

- Original source: canvas_event_strata.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals a change in the item's strata.

Signals a change in the item's strata.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Strata() | | | |

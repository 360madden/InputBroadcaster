# Canvas.Event:KeyRepeat

- Original source: canvas_event_keyrepeat.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Frame.Event:KeyRepeat@summary

Frame.Event:KeyRepeat@summary

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyRepeat(*button*) | | | |
| Parameter | Type | Datatype | Description |
| *button* | parameter | *variant* | The key, in string form. |

# Canvas.Event:Mouse4Click

- Original source: canvas_event_mouse4click.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse's fourth button has been clicked inside the frame. Blocks fourth button mouse events from frames below this one.

Signals that the mouse's fourth button has been clicked inside the frame. Blocks fourth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse4Click() | | | |

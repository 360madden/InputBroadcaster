# Canvas.Event:LeftClick

- Original source: canvas_event_leftclick.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse's left button has been clicked inside the frame. Blocks left mouse events and mouse movement events from frames below this one. May block right mouse events depending on the MouseMasking mode.

Signals that the mouse's left button has been clicked inside the frame. Blocks left mouse events and mouse movement events from frames below this one. May block right mouse events depending on the MouseMasking mode.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:LeftClick() | | | |

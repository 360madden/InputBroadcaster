# Canvas.Event:KeyUp

- Original source: canvas_event_keyup.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals a key released.

Signals a key released.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyUp(*button*) | | | |
| Parameter | Type | Datatype | Description |
| *button* | parameter | *variant* | The key, in string form. |

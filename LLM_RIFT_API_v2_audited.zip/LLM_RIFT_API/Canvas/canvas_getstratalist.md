# Canvas:GetStrataList

- Original source: canvas_getstratalist.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Gets a list of valid stratas for this frame.

Gets a list of valid stratas for this frame.

### Usage:

| --- | --- | --- | --- |
| *stratas* = Frame:GetStrataList() | | | |
| Parameter | Type | Datatype | Description |
| *stratas* | result | *table* | An array of valid stratas, in order. |

# Canvas.Event:Mouse4Up

- Original source: canvas_event_mouse4up.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse's fourth button has been released inside the frame. Blocks fourth button mouse events from frames below this one.

Signals that the mouse's fourth button has been released inside the frame. Blocks fourth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse4Up() | | | |

# Canvas:GetOwner

- Original source: canvas_getowner.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Retrieves the owner of this element.

Retrieves the owner of this element.

### Usage:

| --- | --- | --- | --- |
| *owner* = Layout:GetOwner() | | | |
| Parameter | Type | Datatype | Description |
| *owner* | result | *string* | The owner of this element. Given as an addon identifier. |

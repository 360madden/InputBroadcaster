# Canvas.Event:KeyFocusLoss

- Original source: canvas_event_keyfocusloss.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals losing key focus.

Signals losing key focus.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyFocusLoss() | | | |

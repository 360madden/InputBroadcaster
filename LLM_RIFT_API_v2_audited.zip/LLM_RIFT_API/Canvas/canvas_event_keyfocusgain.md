# Canvas.Event:KeyFocusGain

- Original source: canvas_event_keyfocusgain.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals gaining key focus.

Signals gaining key focus.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyFocusGain() | | | |

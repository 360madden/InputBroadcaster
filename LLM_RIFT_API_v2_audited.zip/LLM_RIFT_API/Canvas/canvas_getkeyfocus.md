# Canvas:GetKeyFocus

- Original source: canvas_getkeyfocus.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Gets the key focus status.

Gets the key focus status.

### Usage:

| --- | --- | --- | --- |
| *focus* = Element:GetKeyFocus() | | | |
| Parameter | Type | Datatype | Description |
| *focus* | result | *boolean* | Whether this frame is the current key focus. |

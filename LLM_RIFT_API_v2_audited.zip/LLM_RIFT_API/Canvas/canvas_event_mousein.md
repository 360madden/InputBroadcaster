# Canvas.Event:MouseIn

- Original source: canvas_event_mousein.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse cursor has been moved onto the frame. Blocks mouse movement events from frames below this one. May block left and right events depending on the MouseMasking mode.

Signals that the mouse cursor has been moved onto the frame. Blocks mouse movement events from frames below this one. May block left and right events depending on the MouseMasking mode.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:MouseIn() | | | |

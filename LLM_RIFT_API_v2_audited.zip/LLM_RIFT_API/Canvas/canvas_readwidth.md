# Canvas:ReadWidth

- Original source: canvas_readwidth.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Read a set width from this frame.

Read a set width from this frame.

### Usage:

| --- | --- | --- | --- |
| *width* = Layout:ReadWidth() | | | |
| Parameter | Type | Datatype | Description |
| *width* | result | *number* | The parameter passed to SetWidth(), or nil if no such parameter has been passed. |

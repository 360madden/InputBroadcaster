# Canvas:GetSecureMode

- Original source: canvas_getsecuremode.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Get the current secure mode. See SetSecureMode for details.

Get the current secure mode. See SetSecureMode for details.

### Usage:

| --- | --- | --- | --- |
| *secure* = Frame:GetSecureMode() | | | |
| Parameter | Type | Datatype | Description |
| *secure* | result | *string* | The current secure mode. |

# Canvas:ClearAll

- Original source: canvas_clearall.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Clear all set points and sizes from this frame.

Clear all set points and sizes from this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:ClearAll() | | | |

**noSecureFrameAndEnvironment**
:   true

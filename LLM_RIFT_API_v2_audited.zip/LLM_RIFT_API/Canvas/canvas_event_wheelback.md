# Canvas.Event:WheelBack

- Original source: canvas_event_wheelback.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mousewheel has been moved backward inside the frame. Blocks mousewheel events from frames below this one.

Signals that the mousewheel has been moved backward inside the frame. Blocks mousewheel events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:WheelBack() | | | |

# Canvas:GetLeft

- Original source: canvas_getleft.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Retrieves the X position of the left edge of this element.

Retrieves the X position of the left edge of this element.

### Usage:

| --- | --- | --- | --- |
| *left* = Layout:GetLeft() | | | |
| Parameter | Type | Datatype | Description |
| *left* | result | *number* | The X position of the left edge of this element. |

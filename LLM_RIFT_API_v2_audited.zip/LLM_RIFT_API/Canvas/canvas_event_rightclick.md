# Canvas.Event:RightClick

- Original source: canvas_event_rightclick.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse's right button has been clicked inside the frame. Blocks right mouse events and mouse movement events from frames below this one. May block left mouse events depending on the MouseMasking mode.

Signals that the mouse's right button has been clicked inside the frame. Blocks right mouse events and mouse movement events from frames below this one. May block left mouse events depending on the MouseMasking mode.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:RightClick() | | | |

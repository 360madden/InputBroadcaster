# Canvas

- Original source: canvas.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** A UI element of type Canvas or derived from Canvas.

A UI element of type Canvas or derived from Canvas.

# Canvas:SetSecureMode

- Original source: canvas_setsecuremode.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Sets the frame's secure mode. "normal" is the standard mode. It allows for most functionality to be used and does not restrict frames in combat. "restricted" allows for certain sensitive functions to be called, but disables a significant amount of functionality in combat. In order to change a frame to "restricted", its parent must already be "restricted". Note that a "restricted" frame can still have "normal" children. If you are not planning to use any restricted functions, your frame should remain in normal mode. At the moment, it is not possible to change from "restricted" back to "normal".

Sets the frame's secure mode.
"normal" is the standard mode. It allows for most functionality to be used and does not restrict frames in combat. "restricted" allows for certain sensitive functions to be called, but disables a significant amount of functionality in combat. In order to change a frame to "restricted", its parent must already be "restricted". Note that a "restricted" frame can still have "normal" children.
If you are not planning to use any restricted functions, your frame should remain in normal mode.
At the moment, it is not possible to change from "restricted" back to "normal".

### Usage:

| --- | --- | --- | --- |
| Frame:SetSecureMode(*secure*) | | | |
| Parameter | Type | Datatype | Description |
| *secure* | parameter | *string* | The new secure mode. Valid inputs are "normal" and "restricted". |

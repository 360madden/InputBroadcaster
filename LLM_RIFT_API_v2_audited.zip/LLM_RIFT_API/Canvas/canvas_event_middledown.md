# Canvas.Event:MiddleDown

- Original source: canvas_event_middledown.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse's middle button has been pressed inside the frame. Blocks middle mouse events from frames below this one.

Signals that the mouse's middle button has been pressed inside the frame. Blocks middle mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:MiddleDown() | | | |

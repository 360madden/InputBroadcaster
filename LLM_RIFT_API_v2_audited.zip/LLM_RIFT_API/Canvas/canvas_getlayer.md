# Canvas:GetLayer

- Original source: canvas_getlayer.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Gets the frame's layer order.

Gets the frame's layer order.

### Usage:

| --- | --- | --- | --- |
| *layer* = Frame:GetLayer() | | | |
| Parameter | Type | Datatype | Description |
| *layer* | result | *number* | The render layer of this frame. See Frame:SetLayer for details. |

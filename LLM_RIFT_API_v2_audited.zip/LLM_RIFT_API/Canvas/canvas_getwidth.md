# Canvas:GetWidth

- Original source: canvas_getwidth.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Retrieves the width of this element.

Retrieves the width of this element.

### Usage:

| --- | --- | --- | --- |
| *width* = Layout:GetWidth() | | | |
| Parameter | Type | Datatype | Description |
| *width* | result | *number* | The width of this element. |

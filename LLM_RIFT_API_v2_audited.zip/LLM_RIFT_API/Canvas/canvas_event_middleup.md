# Canvas.Event:MiddleUp

- Original source: canvas_event_middleup.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse's middle button has been released inside the frame. Blocks middle mouse events from frames below this one.

Signals that the mouse's middle button has been released inside the frame. Blocks middle mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:MiddleUp() | | | |

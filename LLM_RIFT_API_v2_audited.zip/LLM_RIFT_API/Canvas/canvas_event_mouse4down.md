# Canvas.Event:Mouse4Down

- Original source: canvas_event_mouse4down.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse's fourth button has been pressed inside the frame. Blocks fourth button mouse events from frames below this one.

Signals that the mouse's fourth button has been pressed inside the frame. Blocks fourth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse4Down() | | | |

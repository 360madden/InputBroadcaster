# Canvas.Event:Size

- Original source: canvas_event_size.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the frame's size has changed.

Signals that the frame's size has changed.

### Usage:

| --- | --- | --- | --- |
| Layout.Event:Size() | | | |

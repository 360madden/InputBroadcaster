# Canvas:GetMouseMasking

- Original source: canvas_getmousemasking.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Get the current mouse masking mode. See SetMouseMasking for details.

Get the current mouse masking mode. See SetMouseMasking for details.

### Usage:

| --- | --- | --- | --- |
| *mask* = Element:GetMouseMasking() | | | |
| Parameter | Type | Datatype | Description |
| *mask* | result | *string* | The current mouse masking mode. |

# Canvas:GetParent

- Original source: canvas_getparent.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Gets the parent of this frame.

Gets the parent of this frame.

### Usage:

| --- | --- | --- | --- |
| *parent* = Frame:GetParent() | | | |
| Parameter | Type | Datatype | Description |
| *parent* | result | *Element* | The parent element of this frame. |

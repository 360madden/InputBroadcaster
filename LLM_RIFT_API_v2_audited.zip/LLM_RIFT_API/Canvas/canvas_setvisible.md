# Canvas:SetVisible

- Original source: canvas_setvisible.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Sets the frame's visibility flag. If set to false, then this frame and all its children will not be rendered or accept mouse input.

Sets the frame's visibility flag. If set to false, then this frame and all its children will not be rendered or accept mouse input.

### Usage:

| --- | --- | --- | --- |
| Element:SetVisible(*visible*) | | | |
| Parameter | Type | Datatype | Description |
| *visible* | parameter | *boolean* | The new visibility flag. |

**noSecureFrameAndEnvironment**
:   true

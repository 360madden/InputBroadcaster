# Canvas:SetBackgroundColor

- Original source: canvas_setbackgroundcolor.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Sets the background color of this frame.

Sets the background color of this frame.

### Usage:

| --- | --- | --- | --- |
| Element:SetBackgroundColor(*r*, *g*, *b*) | | | |
| Element:SetBackgroundColor(*r*, *g*, *b*, *a*) | | | |
| Parameter | Type | Datatype | Description |
| *a* | parameter | *number* | Alpha. 1 is fully opaque, 0 is fully transparent. Defaults to 1. |
| *b* | parameter | *number* | Blue. |
| *g* | parameter | *number* | Green. |
| *r* | parameter | *number* | Red. |

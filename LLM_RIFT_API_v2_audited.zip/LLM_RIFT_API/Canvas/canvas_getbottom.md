# Canvas:GetBottom

- Original source: canvas_getbottom.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Retrieves the Y position of the bottom edge of this element.

Retrieves the Y position of the bottom edge of this element.

### Usage:

| --- | --- | --- | --- |
| *bottom* = Layout:GetBottom() | | | |
| Parameter | Type | Datatype | Description |
| *bottom* | result | *number* | The Y position of the bottom edge of this element. |

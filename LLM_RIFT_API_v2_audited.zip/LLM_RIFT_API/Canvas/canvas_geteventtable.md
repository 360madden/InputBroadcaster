# Canvas:GetEventTable

- Original source: canvas_geteventtable.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Retrieves the event table of this element. By default, this value is also stored in "this.Event".

Retrieves the event table of this element. By default, this value is also stored in "this.Event".

### Usage:

| --- | --- | --- | --- |
| *eventTable* = Layout:GetEventTable() | | | |
| Parameter | Type | Datatype | Description |
| *eventTable* | result | *table* | The event table of this element. |

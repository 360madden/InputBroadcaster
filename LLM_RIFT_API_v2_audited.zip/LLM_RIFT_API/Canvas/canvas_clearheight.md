# Canvas:ClearHeight

- Original source: canvas_clearheight.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Clear a set height from this frame.

Clear a set height from this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:ClearHeight() | | | |

**noSecureFrameAndEnvironment**
:   true

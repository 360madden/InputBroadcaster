# Canvas.Event:LeftUpoutside

- Original source: canvas_event_leftupoutside.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse's left button has been released outside the frame, after a "Down" message. Blocks left mouse events and mouse movement events from frames below this one. May block right mouse events depending on the MouseMasking mode.

Signals that the mouse's left button has been released outside the frame, after a "Down" message. Blocks left mouse events and mouse movement events from frames below this one. May block right mouse events depending on the MouseMasking mode.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:LeftUpoutside() | | | |

# Canvas:SetPoint

- Original source: canvas_setpoint.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Pins a point on this frame to a location on another frame. This is a rather complex function and you should look at examples to see how to use it. This function can take many different forms. In general, it looks like this: SetPoint(point_on_this_frame, target_frame, point_on_target_frame [, x_offset, y_offset]). The first part is the point on this frame that will be attached. Usually, these are string identifiers. "TOPLEFT", "TOPCENTER", "TOPRIGHT", "CENTERLEFT", "CENTER", "CENTERRIGHT", "BOTTOMLEFT", "BOTTOMCENTER", "BOTTOMRIGHT". You may also use a string identifier that refers to a single axis - "TOP", "BOTTOM", "LEFT", "RIGHT", "CENTERX", "CENTERY". If you want more direct numeric control you can use number pairs. 0,0 is equivalent to "TOPLEFT", 1,1 is equivalent to "BOTTOMRIGHT", 0.5,nil is equivalent to "CENTERX". The second part is the frame to attach to, as well as the point on that frame to attach to. The frame is simply passing in the frame table. The point is the same identifier or number pair as the first parameter. Optionally, you may include an X or Y offset to the point. This connection is permanent, and if the target frame moves, this frame will move along with it. Caveat: If the target is a frame set to the "restricted" SecureMode, and the client is currently in "secure" mode, then unexpected behavior may occur.

Pins a point on this frame to a location on another frame. This is a rather complex function and you should look at examples to see how to use it.
This function can take many different forms. In general, it looks like this: SetPoint(point\_on\_this\_frame, target\_frame, point\_on\_target\_frame [, x\_offset, y\_offset]).
The first part is the point on this frame that will be attached. Usually, these are string identifiers. "TOPLEFT", "TOPCENTER", "TOPRIGHT", "CENTERLEFT", "CENTER", "CENTERRIGHT", "BOTTOMLEFT", "BOTTOMCENTER", "BOTTOMRIGHT". You may also use a string identifier that refers to a single axis - "TOP", "BOTTOM", "LEFT", "RIGHT", "CENTERX", "CENTERY". If you want more direct numeric control you can use number pairs. 0,0 is equivalent to "TOPLEFT", 1,1 is equivalent to "BOTTOMRIGHT", 0.5,nil is equivalent to "CENTERX".
The second part is the frame to attach to, as well as the point on that frame to attach to. The frame is simply passing in the frame table. The point is the same identifier or number pair as the first parameter.
Optionally, you may include an X or Y offset to the point.
This connection is permanent, and if the target frame moves, this frame will move along with it.
Caveat: If the target is a frame set to the "restricted" SecureMode, and the client is currently in "secure" mode, then unexpected behavior may occur.

### Usage:

| --- | --- | --- | --- |
| Frame:SetPoint(*...*) | | | |
| Parameter | Type | Datatype | Description |
| *...* | parameter | *...* | This function's parameters are complicated. Read the above summary for details. |

**noSecureFrameAndEnvironment**
:   true

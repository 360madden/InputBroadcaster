# Canvas:EventList

- Original source: canvas_eventlist.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Lists the current event handlers for an event.

Lists the current event handlers for an event.

### Usage:

| --- | --- | --- | --- |
| *result* = Layout:EventList(*handle*) | | | |
| Parameter | Type | Datatype | Description |
| *handle* | parameter | *eventFrame* | A handle to a frame event, usually pulled out of the "Event.UI." hierarchy. |
| *result* | result | *table* | A table of event handlers for this event. |

**members**
:   |  |  |
    | --- | --- |
    | handler | The handler that will be called when the event fires. |
    | label | Human-readable label used to identify the handler in error reports, performance reports, and for later detaching. |
    | macro | The macro that will run when the event fires. |
    | owner | Owner to search for. |
    | priority | Priority of the event handler. Higher numbers trigger first. |

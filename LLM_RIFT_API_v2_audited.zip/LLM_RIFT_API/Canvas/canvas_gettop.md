# Canvas:GetTop

- Original source: canvas_gettop.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Retrieves the Y position of the top edge of this element.

Retrieves the Y position of the top edge of this element.

### Usage:

| --- | --- | --- | --- |
| *top* = Layout:GetTop() | | | |
| Parameter | Type | Datatype | Description |
| *top* | result | *number* | The Y position of the top edge of this element. |

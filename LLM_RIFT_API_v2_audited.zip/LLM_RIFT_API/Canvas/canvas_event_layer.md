# Canvas.Event:Layer

- Original source: canvas_event_layer.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals a change in the item's layer.

Signals a change in the item's layer.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Layer() | | | |

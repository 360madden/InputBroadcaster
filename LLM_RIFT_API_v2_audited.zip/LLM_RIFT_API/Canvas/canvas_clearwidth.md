# Canvas:ClearWidth

- Original source: canvas_clearwidth.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Clear a set width from this frame.

Clear a set width from this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:ClearWidth() | | | |

**noSecureFrameAndEnvironment**
:   true

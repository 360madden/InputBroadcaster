# Canvas.Event:KeyType

- Original source: canvas_event_keytype.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals text typed.

Signals text typed.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyType(*typed*) | | | |
| Parameter | Type | Datatype | Description |
| *typed* | parameter | *variant* | The text. |

# Canvas:GetShape

- Original source: canvas_getshape.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Returns the current canvas shape.

Returns the current canvas shape.

### Usage:

| --- | --- | --- | --- |
| *shape, fill, stroke* = Canvas:GetShape() | | | |
| Parameter | Type | Datatype | Description |
| *fill* | result | *table* | The current fill style. See Canvas:SetShape() for details. |
| *shape* | result | *table* | The current shape. See Canvas:SetShape() for details. |
| *stroke* | result | *table* | The current stroke style. See Canvas:SetShape() for details. |

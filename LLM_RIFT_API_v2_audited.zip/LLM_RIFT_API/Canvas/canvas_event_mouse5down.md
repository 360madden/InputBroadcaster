# Canvas.Event:Mouse5Down

- Original source: canvas_event_mouse5down.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mouse's fifth button has been pressed inside the frame. Blocks fifth button mouse events from frames below this one.

Signals that the mouse's fifth button has been pressed inside the frame. Blocks fifth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse5Down() | | | |

# Canvas.Event:WheelForward

- Original source: canvas_event_wheelforward.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Signals that the mousewheel has been moved forward inside the frame. Blocks mousewheel events from frames below this one.

Signals that the mousewheel has been moved forward inside the frame. Blocks mousewheel events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:WheelForward() | | | |

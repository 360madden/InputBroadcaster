# Canvas:GetBackgroundColor

- Original source: canvas_getbackgroundcolor.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Retrieves the background color of this frame.

Retrieves the background color of this frame.

### Usage:

| --- | --- | --- | --- |
| *r, g, b, a* = Element:GetBackgroundColor() | | | |
| Parameter | Type | Datatype | Description |
| *a* | result | *number* | Alpha. 1 is fully opaque, 0 is fully transparent. |
| *b* | result | *number* | Blue. |
| *g* | result | *number* | Green. |
| *r* | result | *number* | Red. |

# Canvas:GetRight

- Original source: canvas_getright.html
- Category: Canvas
- Priority tier: Core
- Source index: Canvas_index.html

**Doc summary:** Retrieves the X position of the right edge of this element.

Retrieves the X position of the right edge of this element.

### Usage:

| --- | --- | --- | --- |
| *right* = Layout:GetRight() | | | |
| Parameter | Type | Datatype | Description |
| *right* | result | *number* | The X position of the right edge of this element. |

# CopyToClipboard
**Priority:** Secondary
**Purpose:** Clipboard helper command.
**Entry count:** 1
**LLM note:** Niche utility. Ignore unless clipboard output is part of the addon.
## Most important files first
- [Command.CopyToClipboard](command_copytoclipboard.md) — Copies text to clipboard

## Full file list
- [Command.CopyToClipboard](command_copytoclipboard.md) — Copies text to clipboard
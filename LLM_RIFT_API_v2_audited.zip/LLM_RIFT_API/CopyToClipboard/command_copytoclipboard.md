# Command.CopyToClipboard

- Original source: command_copytoclipboard.html
- Category: CopyToClipboard
- Priority tier: Core
- Source index: CopyToClipboard_index.html

**Doc summary:** Copies text to clipboard

Copies text to clipboard

### Usage:

| --- | --- | --- | --- |
| Command.CopyToClipboard(*text*) | | | |
| Parameter | Type | Datatype | Description |
| *text* | parameter | *string* | The new text for the element. |

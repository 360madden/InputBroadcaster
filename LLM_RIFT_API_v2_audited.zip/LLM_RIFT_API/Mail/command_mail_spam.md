# Command.Mail.Spam

- Original source: command_mail_spam.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Marks mail as spam.

Marks mail as spam.

### Usage:

Interaction category: mail

Throttled.

| --- | --- | --- | --- |
| Command.Mail.Spam(*mail*) | | | |
| Command.Mail.Spam(*mail*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *mail* | parameter | *mail* | The ID of the mail to be targeted. |

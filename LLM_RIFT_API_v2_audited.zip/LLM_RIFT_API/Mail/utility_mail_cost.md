# Utility.Mail.Cost

- Original source: utility_mail_cost.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Returns the amount of silver it will cost to send a given mail.

Returns the amount of silver it will cost to send a given mail.

### Usage:

| --- | --- | --- | --- |
| *cost* = Utility.Mail.Cost(*mail*) | | | |
| Parameter | Type | Datatype | Description |
| *mail* | parameter | *table* | The mail to check. In the same format as the parameter of Command.Mail.Send. |
| *cost* | result | *number* | The cost of sending this mail, in silver. |

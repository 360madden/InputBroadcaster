# Command.Mail.Send

- Original source: command_mail_send.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Sends mail.

Sends mail.

### Usage:

Interaction category: mail

| --- | --- | --- | --- |
| Command.Mail.Send(*mail*) | | | |
| Command.Mail.Send(*mail*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *mail* | parameter | *table* | Table containing data about the mail to send.  to: The name of the player to send mail to. Required.  subject: The mail's subject. Required.  body: The mail's body.  cod: The money required for the recipient to remove attachments. Mutually exclusive with "coin", requires non-empty "attachments".  coin: The amount of money attached to this message. Mutually exclusive with "cod".  attachments: A table listing the item IDs of the items you wish to attach. Maximum of 6. |

**hardwareevent**
:   true

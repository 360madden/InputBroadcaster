# Command.Mail.Take

- Original source: command_mail_take.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Takes an attached item from mail.

Takes an attached item from mail.

### Usage:

Interaction category: mail

Throttled.

| --- | --- | --- | --- |
| Command.Mail.Take(*mail*, *item*) | | | |
| Command.Mail.Take(*mail*, *items*) | | | |
| Command.Mail.Take(*mail*, *item*, *callback*) | | | |
| Command.Mail.Take(*mail*, *items*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *item* | parameter | *item* | The ID of the item to be taken. |
| *items* | parameter | *table* | A table containing a list of the items to be taken. |
| *mail* | parameter | *mail* | The ID of the mail to be targeted. |

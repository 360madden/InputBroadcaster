# Inspect.Mail.List

- Original source: inspect_mail_list.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Returns a table of valid mail and its status.

Returns a table of valid mail and its status.

### Usage:

Interaction category: mail

| --- | --- | --- | --- |
| *mails* = Inspect.Mail.List() | | | |
| Parameter | Type | Datatype | Description |
| *mails* | result | *table* | Valid mail, in {id = "type"} format. The type may be either "basic" or "detail", indicating whether the mail has been opened and its detailed information is available. |

# Mail
**Priority:** Secondary
**Purpose:** Mail commands, inspection, and events.
**Entry count:** 11
## Most important files first
- [Inspect.Mail.Detail](inspect_mail_detail.md) — Returns information about mail.
- [Inspect.Mail.List](inspect_mail_list.md) — Returns a table of valid mail and its status.
- [Command.Mail.Delete](command_mail_delete.md) — Deletes a mail.
- [Command.Mail.Open](command_mail_open.md) — Opens a mail, retrieving detailed information for it.
- [Command.Mail.Pay](command_mail_pay.md) — Pays the COD fee on a mail.
- [Command.Mail.Return](command_mail_return.md) — Returns a mail to its sender.

## Full file list
- [Inspect.Mail.Detail](inspect_mail_detail.md) — Returns information about mail.
- [Inspect.Mail.List](inspect_mail_list.md) — Returns a table of valid mail and its status.
- [Command.Mail.Delete](command_mail_delete.md) — Deletes a mail.
- [Command.Mail.Open](command_mail_open.md) — Opens a mail, retrieving detailed information for it.
- [Command.Mail.Pay](command_mail_pay.md) — Pays the COD fee on a mail.
- [Command.Mail.Return](command_mail_return.md) — Returns a mail to its sender.
- [Command.Mail.Send](command_mail_send.md) — Sends mail.
- [Command.Mail.Spam](command_mail_spam.md) — Marks mail as spam.
- [Command.Mail.Take](command_mail_take.md) — Takes an attached item from mail.
- [Event.Mail](event_mail.md) — Signals a change in the available mail messages.
- [Utility.Mail.Cost](utility_mail_cost.md) — Returns the amount of silver it will cost to send a given mail.

# Command.Mail.Open

- Original source: command_mail_open.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Opens a mail, retrieving detailed information for it.

Opens a mail, retrieving detailed information for it.

### Usage:

Interaction category: mail

Throttled.

| --- | --- | --- | --- |
| Command.Mail.Open(*mail*) | | | |
| Command.Mail.Open(*mail*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *mail* | parameter | *mail* | The ID of the mail to be targeted. |

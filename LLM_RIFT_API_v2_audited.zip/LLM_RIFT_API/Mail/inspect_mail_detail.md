# Inspect.Mail.Detail

- Original source: inspect_mail_detail.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Returns information about mail.

Returns information about mail.

### Usage:

Interaction category: mail

| --- | --- | --- | --- |
| *detail* = Inspect.Mail.Detail(*mail*) | | | |
| *details* = Inspect.Mail.Detail(*mails*) | | | |
| Parameter | Type | Datatype | Description |
| *mail* | parameter | *mail* | The identifier of the mail to retrieve detail for. |
| *mails* | parameter | *table* | A table of identifiers of mail to retrieve detail for. |
| *detail* | result | *table* | Detail table for a single mail. |
| *details* | result | *table* | Detail tables for all requested mail. The key is the mail ID, the value is the mail's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | attachments | The attachments available on this mail. A number if this mail has basic information, or a table of item IDs if this mail has detailed information. |
    | body | The body of this mail. Available only if detailed information on the mail has been retrieved. |
    | cod | The Cash on Delivery required to retrieve attachments out of this mail message. |
    | expire | The time this mail will expire, in Unix timestamp form. |
    | from | The name of the character this mail was sent from. |
    | id | The ID of the requested element. |
    | read | "true" if you have already opened this mail. |
    | spam | "true" if this mail is considered spam. |
    | subject | The subject line for this mail. |

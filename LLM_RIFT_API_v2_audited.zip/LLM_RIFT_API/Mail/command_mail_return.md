# Command.Mail.Return

- Original source: command_mail_return.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Returns a mail to its sender.

Returns a mail to its sender.

### Usage:

Interaction category: mail

Throttled.

| --- | --- | --- | --- |
| Command.Mail.Return(*mail*) | | | |
| Command.Mail.Return(*mail*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *mail* | parameter | *mail* | The ID of the mail to be targeted. |

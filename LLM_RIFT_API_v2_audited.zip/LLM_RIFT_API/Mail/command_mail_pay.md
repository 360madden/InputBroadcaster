# Command.Mail.Pay

- Original source: command_mail_pay.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Pays the COD fee on a mail.

Pays the COD fee on a mail.

### Usage:

Interaction category: mail

Throttled.

| --- | --- | --- | --- |
| Command.Mail.Pay(*mail*) | | | |
| Command.Mail.Pay(*mail*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *mail* | parameter | *mail* | The ID of the mail to be targeted. |

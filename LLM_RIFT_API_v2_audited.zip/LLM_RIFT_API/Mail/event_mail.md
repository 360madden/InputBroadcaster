# Event.Mail

- Original source: event_mail.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Signals a change in the available mail messages.

Signals a change in the available mail messages.

### Usage:

| --- | --- | --- | --- |
| Event.Mail(*mail*) | | | |
| Parameter | Type | Datatype | Description |
| *mail* | parameter | *variant* | The changed mail messages. Takes the form of a table. The key is the mail ID, the value is "basic" to indicate basic information available about a piece of mail, "detail" to indicate detailed information available, or false to indicate no information available. |

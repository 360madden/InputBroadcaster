# Command.Mail.Delete

- Original source: command_mail_delete.html
- Category: Mail
- Priority tier: Secondary
- Source index: Mail_index.html

**Doc summary:** Deletes a mail.

Deletes a mail.

### Usage:

Interaction category: mail

Throttled.

| --- | --- | --- | --- |
| Command.Mail.Delete(*mail*) | | | |
| Command.Mail.Delete(*mail*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *mail* | parameter | *mail* | The ID of the mail to be targeted. |

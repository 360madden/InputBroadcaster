# Event.Buff.Description

- Original source: event_buff_description.html
- Category: Buff
- Priority tier: Secondary
- Source index: Buff_index.html

**Doc summary:** Signals a change in an existing buff's detailed description. Value of the key is "true" if detail is now available, "false" if it is no longer available.

Signals a change in an existing buff's detailed description. Value of the key is "true" if detail is now available, "false" if it is no longer available.

### Usage:

| --- | --- | --- | --- |
| Event.Buff.Description(*unit*, *buffs*) | | | |
| Parameter | Type | Datatype | Description |
| *buffs* | parameter | *<nope>* | A table containing the buffs involved. |
| *unit* | parameter | *variant* | The Unit ID of the unit involved. |

# Command.Buff.Cancel

- Original source: command_buff_cancel.html
- Category: Buff
- Priority tier: Secondary
- Source index: Buff_index.html

**Doc summary:** Cancels a buff on the player. Not all buffs are cancelable.

Cancels a buff on the player. Not all buffs are cancelable.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Buff.Cancel(*buff*) | | | |
| Parameter | Type | Datatype | Description |
| *buff* | parameter | *buff* | The ID of the buff to cancel. |

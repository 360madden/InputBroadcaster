# Event.Buff.Remove

- Original source: event_buff_remove.html
- Category: Buff
- Priority tier: Secondary
- Source index: Buff_index.html

**Doc summary:** Signals removal of buffs from a unit.

Signals removal of buffs from a unit.

### Usage:

| --- | --- | --- | --- |
| Event.Buff.Remove(*unit*, *buffs*) | | | |
| Parameter | Type | Datatype | Description |
| *buffs* | parameter | *<nope>* | A table containing the buffs involved. |
| *unit* | parameter | *variant* | The Unit ID of the unit involved. |

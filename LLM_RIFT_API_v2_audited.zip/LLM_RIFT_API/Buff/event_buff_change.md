# Event.Buff.Change

- Original source: event_buff_change.html
- Category: Buff
- Priority tier: Secondary
- Source index: Buff_index.html

**Doc summary:** Signals a change in existing buffs on a unit.

Signals a change in existing buffs on a unit.

### Usage:

| --- | --- | --- | --- |
| Event.Buff.Change(*unit*, *buffs*) | | | |
| Parameter | Type | Datatype | Description |
| *buffs* | parameter | *<nope>* | A table containing the buffs involved. |
| *unit* | parameter | *variant* | The Unit ID of the unit involved. |

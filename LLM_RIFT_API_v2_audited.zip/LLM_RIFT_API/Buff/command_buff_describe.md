# Command.Buff.Describe

- Original source: command_buff_describe.html
- Category: Buff
- Priority tier: Secondary
- Source index: Buff_index.html

**Doc summary:** Requests a detailed description for a given buff.

Requests a detailed description for a given buff.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Buff.Describe(*unit*, *buff*) | | | |
| Parameter | Type | Datatype | Description |
| *buff* | parameter | *buff* | The ID of the buff to describe. |
| *unit* | parameter | *unit* | The ID of the unit that the buff is on. |

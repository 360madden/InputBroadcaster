# Inspect.Buff.List

- Original source: inspect_buff_list.html
- Category: Buff
- Priority tier: Secondary
- Source index: Buff_index.html

**Doc summary:** List buffs on a unit.

List buffs on a unit.

### Usage:

| --- | --- | --- | --- |
| *buffs* = Inspect.Buff.List(*unit*) | | | |
| Parameter | Type | Datatype | Description |
| *unit* | parameter | *unit* | The unit to inspect. |
| *buffs* | result | *table* | A table of the IDs of the buffs on the unit. |

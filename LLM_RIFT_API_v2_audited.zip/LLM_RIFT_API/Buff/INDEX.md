# Buff
**Priority:** Secondary
**Purpose:** Buff inspection and buff-related events.
**Entry count:** 8
## Most important files first
- [Inspect.Buff.Detail](inspect_buff_detail.md) — Provides detailed information about the buffs on a unit.
- [Inspect.Buff.List](inspect_buff_list.md) — List buffs on a unit.
- [Command.Buff.Cancel](command_buff_cancel.md) — Cancels a buff on the player. Not all buffs are cancelable.
- [Command.Buff.Describe](command_buff_describe.md) — Requests a detailed description for a given buff.
- [Event.Buff.Add](event_buff_add.md) — Signals new buffs on a unit.
- [Event.Buff.Change](event_buff_change.md) — Signals a change in existing buffs on a unit.

## Full file list
- [Inspect.Buff.Detail](inspect_buff_detail.md) — Provides detailed information about the buffs on a unit.
- [Inspect.Buff.List](inspect_buff_list.md) — List buffs on a unit.
- [Command.Buff.Cancel](command_buff_cancel.md) — Cancels a buff on the player. Not all buffs are cancelable.
- [Command.Buff.Describe](command_buff_describe.md) — Requests a detailed description for a given buff.
- [Event.Buff.Add](event_buff_add.md) — Signals new buffs on a unit.
- [Event.Buff.Change](event_buff_change.md) — Signals a change in existing buffs on a unit.
- [Event.Buff.Description](event_buff_description.md) — Signals a change in an existing buff's detailed description. Value of the key is "true" if detail...
- [Event.Buff.Remove](event_buff_remove.md) — Signals removal of buffs from a unit.

# Event.Buff.Add

- Original source: event_buff_add.html
- Category: Buff
- Priority tier: Secondary
- Source index: Buff_index.html

**Doc summary:** Signals new buffs on a unit.

Signals new buffs on a unit.

### Usage:

| --- | --- | --- | --- |
| Event.Buff.Add(*unit*, *buffs*) | | | |
| Parameter | Type | Datatype | Description |
| *buffs* | parameter | *<nope>* | A table containing the buffs involved. The key is the buff ID, the value is the buff type ID or 'true' if the buff has no type. |
| *unit* | parameter | *variant* | The Unit ID of the unit involved. |

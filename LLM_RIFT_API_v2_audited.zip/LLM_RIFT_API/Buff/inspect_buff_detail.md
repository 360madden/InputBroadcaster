# Inspect.Buff.Detail

- Original source: inspect_buff_detail.html
- Category: Buff
- Priority tier: Secondary
- Source index: Buff_index.html

**Doc summary:** Provides detailed information about the buffs on a unit.

Provides detailed information about the buffs on a unit.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Buff.Detail(*unit*, *buff*) | | | |
| *details* = Inspect.Buff.Detail(*unit*, *buffs*) | | | |
| Parameter | Type | Datatype | Description |
| *buff* | parameter | *buff* | An identifier for the buff to retrieve detail for. |
| *buffs* | parameter | *table* | A table containing buff identifiers to retrieve details for. |
| *unit* | parameter | *unit* | The unit to inspect. |
| *detail* | result | *table* | Detail table for a single buff. |
| *details* | result | *table* | Detail tables for all requested buffs. The key is the buff ID, the value is the buff's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | ability | The ID of the ability that created this buff. Not guaranteed to exist. |
    | begin | The time the buff started, in the context of Inspect.Time.Frame. |
    | caster | Unit ID of the buff's caster. |
    | curse | Signals that the buff is a curse. |
    | debuff | Signals that the buff is a debuff. If this is missing, then it's an actual buff. |
    | description | Description for the buff. Numbers may not be accurate - see Command.Buff.Describe(). |
    | descriptionComplete | Signals that the buff description is complete. |
    | disease | Signals that the buff is a disease. |
    | duration | Duration of the buff in seconds. |
    | expired | Number of seconds the buff is past its expiration time. Generally indicates lag. |
    | icon | Resource filename of the buff's icon. |
    | id | The ID of the requested element. |
    | name | Name of the buff. |
    | noncancelable | Signals that the buff cannot be voluntarily canceled. Does not show up for debuffs. |
    | poison | Signals that the buff is a poison. |
    | remaining | Time remaining on the buff, in seconds. |
    | rune | If this buff is created by a rune, the ID of the rune causing it. |
    | stack | Number of stacks on the buff. |
    | type | The buff type ID. |

# Event.Ability.New.Range.False

- Original source: event_ability_new_range_false.html
- Category: Ability
- Priority tier: Secondary
- Source index: Ability_index.html

**Doc summary:** Signals a player ability exiting range from its current target.

Signals a player ability exiting range from its current target.

### Usage:

| --- | --- | --- | --- |
| Event.Ability.New.Range.False(*abilities*) | | | |
| Parameter | Type | Datatype | Description |
| *abilities* | parameter | *variant* | The abilities that have entered or exited range. The key is the ability ID, the value is whether they are currently in range. |

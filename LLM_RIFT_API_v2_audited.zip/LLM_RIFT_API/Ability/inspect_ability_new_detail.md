# Inspect.Ability.New.Detail

- Original source: inspect_ability_new_detail.html
- Category: Ability
- Priority tier: Secondary
- Source index: Ability_index.html

**Doc summary:** Provides detailed information about abilities.

Provides detailed information about abilities.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Ability.New.Detail(*ability*) | | | |
| *details* = Inspect.Ability.New.Detail(*abilities*) | | | |
| Parameter | Type | Datatype | Description |
| *abilities* | parameter | *table* | A table of identifiers of abilities to retrieve detail for. |
| *ability* | parameter | *ability* | The identifier of the ability to retrieve detail for. |
| *detail* | result | *table* | Detail table for a single ability. |
| *details* | result | *table* | Detail tables for all requested abilities. The key is the ability ID, the value is the ability's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | autoattack | Autoattack mode of the ability. |
    | castingTime | Casting time of the ability, in seconds. |
    | channeled | Signals that the ability is channeled. |
    | continuous | Signals that the ability is continuous. |
    | cooldown | Cooldown of the ability, in seconds. |
    | costCharge | The amount of charge this ability consumes on use. |
    | costEnergy | The amount of energy this ability consumes on use. |
    | costMana | The amount of mana this ability consumes on use. |
    | costPlanarCharge | The amount of planar charges this ability consumes on use. |
    | costPower | The amount of power this ability consumes on use. |
    | costSpirit | The amount of spirit this ability consumes on use. |
    | currentCooldownBegin | The time the current cooldown started, in the context of Inspect.Time.Frame. |
    | currentCooldownDuration | Duration of the current cooldown the ability is influenced by, in seconds. |
    | currentCooldownExpired | Number of seconds the current cooldown is past its expiration time. Generally indicates lag. |
    | currentCooldownPaused | Indicates that this ability's cooldown is paused. |
    | currentCooldownRemaining | Time remaining in the ability's current cooldown, in seconds. |
    | description | Description for the ability. |
    | focusMax | The maximum focus to use this ability. |
    | focusMin | The minimum focus to use this ability. |
    | gainCharge | Amount of charge gained by using the ability. |
    | icon | Resource filename of the ability's icon. |
    | id | The ID of the requested element. |
    | idNew | The new ability ID. |
    | name | Name of the ability. |
    | outOfRange | Signals that the ability is out of range. |
    | passive | Signals that the ability is passive. |
    | positioned | Signals that the ability's effect is manually positioned by the user. |
    | racial | Signals that the ability is a racial ability. |
    | rangeMax | The maximum range of the ability. |
    | rangeMin | The minimum range of the ability. |
    | stealthRequired | Signals that the ability requires the user to be in stealth. |
    | target | The Unit ID of the unit that this ability will be used on if triggered at this moment. |
    | unusable | Signals that this ability is unusable. |
    | weapon | The required equipped weapon for this ability. May be "any", "melee", or "ranged". |

# Ability
**Priority:** Secondary
**Purpose:** Ability inspection and ability-related events.
**Entry count:** 11
## Most important files first
- [Inspect.Ability.New.Detail](inspect_ability_new_detail.md) — Provides detailed information about abilities.
- [Inspect.Ability.New.List](inspect_ability_new_list.md) — List available abilities.
- [Event.Ability.New.Add](event_ability_new_add.md) — Signals the addition of a player ability.
- [Event.Ability.New.Cooldown.Begin](event_ability_new_cooldown_begin.md) — Signals the start of an ability's cooldown.
- [Event.Ability.New.Cooldown.End](event_ability_new_cooldown_end.md) — Signals the end of an ability's cooldown. All the values in the "cooldown" parameter will be 0.
- [Event.Ability.New.Range.False](event_ability_new_range_false.md) — Signals a player ability exiting range from its current target.

## Full file list
- [Inspect.Ability.New.Detail](inspect_ability_new_detail.md) — Provides detailed information about abilities.
- [Inspect.Ability.New.List](inspect_ability_new_list.md) — List available abilities.
- [Event.Ability.New.Add](event_ability_new_add.md) — Signals the addition of a player ability.
- [Event.Ability.New.Cooldown.Begin](event_ability_new_cooldown_begin.md) — Signals the start of an ability's cooldown.
- [Event.Ability.New.Cooldown.End](event_ability_new_cooldown_end.md) — Signals the end of an ability's cooldown. All the values in the "cooldown" parameter will be 0.
- [Event.Ability.New.Range.False](event_ability_new_range_false.md) — Signals a player ability exiting range from its current target.
- [Event.Ability.New.Range.True](event_ability_new_range_true.md) — Signals a player ability entering range from its current target.
- [Event.Ability.New.Remove](event_ability_new_remove.md) — Signals the removal of a player ability.
- [Event.Ability.New.Target](event_ability_new_target.md) — Signals a player ability changing its current target.
- [Event.Ability.New.Usable.False](event_ability_new_usable_false.md) — Signals a player ability becoming unusable.
- [Event.Ability.New.Usable.True](event_ability_new_usable_true.md) — Signals a player ability becoming usable.

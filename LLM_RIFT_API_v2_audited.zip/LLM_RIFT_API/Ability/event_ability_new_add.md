# Event.Ability.New.Add

- Original source: event_ability_new_add.html
- Category: Ability
- Priority tier: Secondary
- Source index: Ability_index.html

**Doc summary:** Signals the addition of a player ability.

Signals the addition of a player ability.

### Usage:

| --- | --- | --- | --- |
| Event.Ability.New.Add(*abilities*) | | | |
| Parameter | Type | Datatype | Description |
| *abilities* | parameter | *variant* | Lists the abilities that were added. Table from ability ID to "true". |

# Event.Ability.New.Cooldown.End

- Original source: event_ability_new_cooldown_end.html
- Category: Ability
- Priority tier: Secondary
- Source index: Ability_index.html

**Doc summary:** Signals the end of an ability's cooldown. All the values in the "cooldown" parameter will be 0.

Signals the end of an ability's cooldown. All the values in the "cooldown" parameter will be 0.

### Usage:

| --- | --- | --- | --- |
| Event.Ability.New.Cooldown.End(*cooldowns*) | | | |
| Parameter | Type | Datatype | Description |
| *cooldowns* | parameter | *variant* | The abilities whose cooldown has been changed. The key is the ability ID, the value is the new cooldown. 0 indicates that the cooldown has finished. |

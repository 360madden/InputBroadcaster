# Event.Ability.New.Target

- Original source: event_ability_new_target.html
- Category: Ability
- Priority tier: Secondary
- Source index: Ability_index.html

**Doc summary:** Signals a player ability changing its current target.

Signals a player ability changing its current target.

### Usage:

| --- | --- | --- | --- |
| Event.Ability.New.Target(*abilities*) | | | |
| Parameter | Type | Datatype | Description |
| *abilities* | parameter | *variant* | The abilities whose target has changed. The key is the ability ID, the value is the new target. |

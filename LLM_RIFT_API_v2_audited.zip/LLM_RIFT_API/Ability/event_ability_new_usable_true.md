# Event.Ability.New.Usable.True

- Original source: event_ability_new_usable_true.html
- Category: Ability
- Priority tier: Secondary
- Source index: Ability_index.html

**Doc summary:** Signals a player ability becoming usable.

Signals a player ability becoming usable.

### Usage:

| --- | --- | --- | --- |
| Event.Ability.New.Usable.True(*abilities*) | | | |
| Parameter | Type | Datatype | Description |
| *abilities* | parameter | *variant* | The abilities whose usability has changed. The key is the ability ID, the value is the new usability. |

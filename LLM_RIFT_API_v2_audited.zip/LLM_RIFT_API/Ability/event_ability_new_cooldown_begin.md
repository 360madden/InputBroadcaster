# Event.Ability.New.Cooldown.Begin

- Original source: event_ability_new_cooldown_begin.html
- Category: Ability
- Priority tier: Secondary
- Source index: Ability_index.html

**Doc summary:** Signals the start of an ability's cooldown.

Signals the start of an ability's cooldown.

### Usage:

| --- | --- | --- | --- |
| Event.Ability.New.Cooldown.Begin(*cooldowns*) | | | |
| Parameter | Type | Datatype | Description |
| *cooldowns* | parameter | *variant* | The abilities whose cooldown has been changed. The key is the ability ID, the value is the new cooldown. 0 indicates that the cooldown has finished. |

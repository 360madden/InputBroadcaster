# Event.Ability.New.Remove

- Original source: event_ability_new_remove.html
- Category: Ability
- Priority tier: Secondary
- Source index: Ability_index.html

**Doc summary:** Signals the removal of a player ability.

Signals the removal of a player ability.

### Usage:

| --- | --- | --- | --- |
| Event.Ability.New.Remove(*abilities*) | | | |
| Parameter | Type | Datatype | Description |
| *abilities* | parameter | *variant* | Lists the abilities that were removed. Table from ability ID to "false". |

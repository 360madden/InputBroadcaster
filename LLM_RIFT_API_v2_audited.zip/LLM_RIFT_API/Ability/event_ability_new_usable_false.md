# Event.Ability.New.Usable.False

- Original source: event_ability_new_usable_false.html
- Category: Ability
- Priority tier: Secondary
- Source index: Ability_index.html

**Doc summary:** Signals a player ability becoming unusable.

Signals a player ability becoming unusable.

### Usage:

| --- | --- | --- | --- |
| Event.Ability.New.Usable.False(*abilities*) | | | |
| Parameter | Type | Datatype | Description |
| *abilities* | parameter | *variant* | The abilities whose usability has changed. The key is the ability ID, the value is the new usability. |

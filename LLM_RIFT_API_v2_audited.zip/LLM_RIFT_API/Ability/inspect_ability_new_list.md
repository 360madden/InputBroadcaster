# Inspect.Ability.New.List

- Original source: inspect_ability_new_list.html
- Category: Ability
- Priority tier: Secondary
- Source index: Ability_index.html

**Doc summary:** List available abilities.

List available abilities.

### Usage:

| --- | --- | --- | --- |
| *abilities* = Inspect.Ability.New.List() | | | |
| Parameter | Type | Datatype | Description |
| *abilities* | result | *table* | A table of IDs of the available abilities. |

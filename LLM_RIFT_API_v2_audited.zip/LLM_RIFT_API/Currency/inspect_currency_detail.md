# Inspect.Currency.Detail

- Original source: inspect_currency_detail.html
- Category: Currency
- Priority tier: Secondary
- Source index: Currency_index.html

**Doc summary:** Provides detailed information about currencies.

Provides detailed information about currencies.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Currency.Detail(*coin*) | | | |
| *detail* = Inspect.Currency.Detail(*currency*) | | | |
| *details* = Inspect.Currency.Detail(*currencies*) | | | |
| Parameter | Type | Datatype | Description |
| *coin* | parameter | *string* | The string "coin", used as a value to request the player's money. |
| *currencies* | parameter | *table* | A table of identifiers of currencies to retrieve detail for. |
| *currency* | parameter | *itemtype* | The identifier of the currency to retrieve detail for. |
| *detail* | result | *table* | Detail table for a single currency. |
| *details* | result | *table* | Detail tables for all requested currencies. The key is the currency ID, the value is the currency's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | category | ID of the currency's category. |
    | icon | Internal name of the currency's icon. |
    | id | The ID of the requested element. |
    | name | The currency's name. |
    | stack | The number of this currency that you have. |
    | stackMax | The maximum number of this currency that you can have. |

# Inspect.Currency.Category.List

- Original source: inspect_currency_category_list.html
- Category: Currency
- Priority tier: Secondary
- Source index: Currency_index.html

**Doc summary:** Returns a table of valid currency categories.

Returns a table of valid currency categories.

### Usage:

| --- | --- | --- | --- |
| *categories* = Inspect.Currency.Category.List() | | | |
| Parameter | Type | Datatype | Description |
| *categories* | result | *table* | Valid currency categories, in {id = true} format. |

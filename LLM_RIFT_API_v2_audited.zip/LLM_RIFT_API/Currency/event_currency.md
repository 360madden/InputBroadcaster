# Event.Currency

- Original source: event_currency.html
- Category: Currency
- Priority tier: Secondary
- Source index: Currency_index.html

**Doc summary:** Signals a change in the player's available currency.

Signals a change in the player's available currency.

### Usage:

| --- | --- | --- | --- |
| Event.Currency(*currencies*) | | | |
| Parameter | Type | Datatype | Description |
| *currencies* | parameter | *variant* | New currency counts, in key/value form. |

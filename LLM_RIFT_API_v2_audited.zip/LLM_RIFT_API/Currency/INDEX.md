# Currency
**Priority:** Secondary
**Purpose:** Currency inspection and currency events.
**Entry count:** 5
## Most important files first
- [Inspect.Currency.Category.Detail](inspect_currency_category_detail.md) — Returns information about currency categories.
- [Inspect.Currency.Detail](inspect_currency_detail.md) — Provides detailed information about currencies.
- [Inspect.Currency.Category.List](inspect_currency_category_list.md) — Returns a table of valid currency categories.
- [Inspect.Currency.List](inspect_currency_list.md) — Returns a table of all known currencies.
- [Event.Currency](event_currency.md) — Signals a change in the player's available currency.

## Full file list
- [Inspect.Currency.Category.Detail](inspect_currency_category_detail.md) — Returns information about currency categories.
- [Inspect.Currency.Detail](inspect_currency_detail.md) — Provides detailed information about currencies.
- [Inspect.Currency.Category.List](inspect_currency_category_list.md) — Returns a table of valid currency categories.
- [Inspect.Currency.List](inspect_currency_list.md) — Returns a table of all known currencies.
- [Event.Currency](event_currency.md) — Signals a change in the player's available currency.

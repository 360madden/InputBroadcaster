# Inspect.Currency.Category.Detail

- Original source: inspect_currency_category_detail.html
- Category: Currency
- Priority tier: Secondary
- Source index: Currency_index.html

**Doc summary:** Returns information about currency categories.

Returns information about currency categories.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Currency.Category.Detail(*category*) | | | |
| *details* = Inspect.Currency.Category.Detail(*categories*) | | | |
| Parameter | Type | Datatype | Description |
| *categories* | parameter | *table* | A table of identifiers of currency categories to retrieve detail for. |
| *category* | parameter | *currencycategory* | The identifier of the currency category to retrieve detail for. |
| *detail* | result | *table* | Detail table for a single currency category. |
| *details* | result | *table* | Detail tables for all requested currency categories. The key is the category ID, the value is the category's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | id | The ID of the requested element. |
    | name | The name of the currency category. |

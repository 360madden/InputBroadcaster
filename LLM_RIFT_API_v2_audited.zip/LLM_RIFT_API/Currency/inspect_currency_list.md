# Inspect.Currency.List

- Original source: inspect_currency_list.html
- Category: Currency
- Priority tier: Secondary
- Source index: Currency_index.html

**Doc summary:** Returns a table of all known currencies.

Returns a table of all known currencies.

### Usage:

| --- | --- | --- | --- |
| *currencies* = Inspect.Currency.List() | | | |
| Parameter | Type | Datatype | Description |
| *currencies* | result | *table* | All known currencies, in {id = amount} format. |

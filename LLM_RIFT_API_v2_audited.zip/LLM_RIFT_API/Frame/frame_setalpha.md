# Frame:SetAlpha

- Original source: frame_setalpha.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Sets the alpha transparency multiplier for this frame and its children.

Sets the alpha transparency multiplier for this frame and its children.

### Usage:

| --- | --- | --- | --- |
| Element:SetAlpha(*alpha*) | | | |
| Parameter | Type | Datatype | Description |
| *alpha* | parameter | *number* | The new alpha multiplier. 1 is fully opaque, 0 is fully transparent. |

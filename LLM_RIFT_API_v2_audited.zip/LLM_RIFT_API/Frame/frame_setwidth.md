# Frame:SetWidth

- Original source: frame_setwidth.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Sets the width of this frame. Undefined results if the frame already has two pinned X coordinates.

Sets the width of this frame. Undefined results if the frame already has two pinned X coordinates.

### Usage:

| --- | --- | --- | --- |
| Frame:SetWidth(*width*) | | | |
| Parameter | Type | Datatype | Description |
| *width* | parameter | *number* | The new width of this frame. |

**noSecureFrameAndEnvironment**
:   true

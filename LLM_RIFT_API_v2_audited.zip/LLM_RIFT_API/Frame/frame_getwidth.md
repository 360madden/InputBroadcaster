# Frame:GetWidth

- Original source: frame_getwidth.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Retrieves the width of this element.

Retrieves the width of this element.

### Usage:

| --- | --- | --- | --- |
| *width* = Layout:GetWidth() | | | |
| Parameter | Type | Datatype | Description |
| *width* | result | *number* | The width of this element. |

# Frame:GetBottom

- Original source: frame_getbottom.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Retrieves the Y position of the bottom edge of this element.

Retrieves the Y position of the bottom edge of this element.

### Usage:

| --- | --- | --- | --- |
| *bottom* = Layout:GetBottom() | | | |
| Parameter | Type | Datatype | Description |
| *bottom* | result | *number* | The Y position of the bottom edge of this element. |

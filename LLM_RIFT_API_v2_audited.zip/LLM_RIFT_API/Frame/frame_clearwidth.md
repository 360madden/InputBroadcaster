# Frame:ClearWidth

- Original source: frame_clearwidth.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Clear a set width from this frame.

Clear a set width from this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:ClearWidth() | | | |

**noSecureFrameAndEnvironment**
:   true

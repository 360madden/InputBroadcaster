# Frame:SetLayer

- Original source: frame_setlayer.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Sets the frame layer for this frame. This can be any number. Frames are drawn in ascending order. If two frames have the same layer number, then the order of those frames is undefined, but guarantees no Z-fighting. Frames are always drawn after their parents.

Sets the frame layer for this frame. This can be any number. Frames are drawn in ascending order. If two frames have the same layer number, then the order of those frames is undefined, but guarantees no Z-fighting. Frames are always drawn after their parents.

### Usage:

| --- | --- | --- | --- |
| Frame:SetLayer(*layer*) | | | |
| Parameter | Type | Datatype | Description |
| *layer* | parameter | *number* | The new layer for this frame. |

**noSecureFrameAndEnvironment**
:   true

# Frame.Event:WheelForward

- Original source: frame_event_wheelforward.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals that the mousewheel has been moved forward inside the frame. Blocks mousewheel events from frames below this one.

Signals that the mousewheel has been moved forward inside the frame. Blocks mousewheel events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:WheelForward() | | | |

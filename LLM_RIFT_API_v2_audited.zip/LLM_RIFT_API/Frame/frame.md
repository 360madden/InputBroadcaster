# Frame

- Original source: frame.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** A UI element of type Frame or derived from Frame.

A UI element of type Frame or derived from Frame.

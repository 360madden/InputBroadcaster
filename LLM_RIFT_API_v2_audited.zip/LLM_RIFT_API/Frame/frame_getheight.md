# Frame:GetHeight

- Original source: frame_getheight.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Retrieves the height of this element.

Retrieves the height of this element.

### Usage:

| --- | --- | --- | --- |
| *height* = Layout:GetHeight() | | | |
| Parameter | Type | Datatype | Description |
| *height* | result | *number* | The height of this element. |

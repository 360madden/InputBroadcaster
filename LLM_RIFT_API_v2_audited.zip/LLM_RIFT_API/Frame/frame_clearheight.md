# Frame:ClearHeight

- Original source: frame_clearheight.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Clear a set height from this frame.

Clear a set height from this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:ClearHeight() | | | |

**noSecureFrameAndEnvironment**
:   true

# Frame.Event:KeyRepeat

- Original source: frame_event_keyrepeat.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Frame.Event:KeyRepeat@summary

Frame.Event:KeyRepeat@summary

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyRepeat(*button*) | | | |
| Parameter | Type | Datatype | Description |
| *button* | parameter | *variant* | The key, in string form. |

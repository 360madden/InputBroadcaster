# Frame:GetVisible

- Original source: frame_getvisible.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Gets the visibility flag for this frame.

Gets the visibility flag for this frame.

### Usage:

| --- | --- | --- | --- |
| *visible* = Element:GetVisible() | | | |
| Parameter | Type | Datatype | Description |
| *visible* | result | *boolean* | This frame's visibility flag, as set by SetVisible. Does not check the visibility flags of the frame's parents. |

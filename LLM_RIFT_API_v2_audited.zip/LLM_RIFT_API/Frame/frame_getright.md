# Frame:GetRight

- Original source: frame_getright.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Retrieves the X position of the right edge of this element.

Retrieves the X position of the right edge of this element.

### Usage:

| --- | --- | --- | --- |
| *right* = Layout:GetRight() | | | |
| Parameter | Type | Datatype | Description |
| *right* | result | *number* | The X position of the right edge of this element. |

# Frame.Event:Size

- Original source: frame_event_size.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals that the frame's size has changed.

Signals that the frame's size has changed.

### Usage:

| --- | --- | --- | --- |
| Layout.Event:Size() | | | |

# Frame:GetMouseMasking

- Original source: frame_getmousemasking.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Get the current mouse masking mode. See SetMouseMasking for details.

Get the current mouse masking mode. See SetMouseMasking for details.

### Usage:

| --- | --- | --- | --- |
| *mask* = Element:GetMouseMasking() | | | |
| Parameter | Type | Datatype | Description |
| *mask* | result | *string* | The current mouse masking mode. |

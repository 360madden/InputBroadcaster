# Frame.Event:Move

- Original source: frame_event_move.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals that the frame's vertices have moved.

Signals that the frame's vertices have moved.

### Usage:

| --- | --- | --- | --- |
| Layout.Event:Move() | | | |

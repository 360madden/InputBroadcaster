# Frame:GetKeyFocus

- Original source: frame_getkeyfocus.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Gets the key focus status.

Gets the key focus status.

### Usage:

| --- | --- | --- | --- |
| *focus* = Element:GetKeyFocus() | | | |
| Parameter | Type | Datatype | Description |
| *focus* | result | *boolean* | Whether this frame is the current key focus. |

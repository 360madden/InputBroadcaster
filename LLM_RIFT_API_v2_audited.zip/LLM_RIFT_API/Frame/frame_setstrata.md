# Frame:SetStrata

- Original source: frame_setstrata.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Sets the strata for this frame.

Sets the strata for this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:SetStrata(*strata*) | | | |
| Parameter | Type | Datatype | Description |
| *strata* | parameter | *string* | The item's new strata. Must be one of the elements returned by :GetStrataList(). |

**noSecureFrameAndEnvironment**
:   true

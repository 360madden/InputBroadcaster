# Frame.Event:KeyType

- Original source: frame_event_keytype.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals text typed.

Signals text typed.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyType(*typed*) | | | |
| Parameter | Type | Datatype | Description |
| *typed* | parameter | *variant* | The text. |

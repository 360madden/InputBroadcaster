# Frame.Event:MouseIn

- Original source: frame_event_mousein.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals that the mouse cursor has been moved onto the frame. Blocks mouse movement events from frames below this one. May block left and right events depending on the MouseMasking mode.

Signals that the mouse cursor has been moved onto the frame. Blocks mouse movement events from frames below this one. May block left and right events depending on the MouseMasking mode.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:MouseIn() | | | |

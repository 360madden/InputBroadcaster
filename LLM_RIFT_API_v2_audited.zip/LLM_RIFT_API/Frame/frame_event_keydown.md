# Frame.Event:KeyDown

- Original source: frame_event_keydown.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals a key pressed.

Signals a key pressed.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyDown(*button*) | | | |
| Parameter | Type | Datatype | Description |
| *button* | parameter | *variant* | The key, in string form. |

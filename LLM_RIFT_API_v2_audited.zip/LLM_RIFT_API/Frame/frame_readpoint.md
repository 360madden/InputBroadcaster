# Frame:ReadPoint

- Original source: frame_readpoint.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Read a set point from this frame. Must be given a single-axis coordinate.

Read a set point from this frame. Must be given a single-axis coordinate.

### Usage:

| --- | --- | --- | --- |
| *layout, position, offset* = Layout:ReadPoint(*coordinate*) | | | |
| *layout, position, offset* = Layout:ReadPoint(*x*, *y*) | | | |
| *origin, offset* = Layout:ReadPoint(*coordinate*) | | | |
| *origin, offset* = Layout:ReadPoint(*x*, *y*) | | | |
| Parameter | Type | Datatype | Description |
| *coordinate* | parameter | *string* | Named coordinate. Must be a one-axis coordinate. |
| *x* | parameter | *number/nil* | X coordinate of the point. Either this or Y must be nil. |
| *y* | parameter | *number/nil* | Y coordinate of the point. Either this or X must be nil. |
| *layout* | result | *Layout* | The table that this point is pinned to. |
| *offset* | result | *number* | The offset in pixels from the source location to the actual location. |
| *origin* | result | *string* | The string "origin". |
| *position* | result | *number* | The position on "layout" that this point is pinned. 0 refers to the top or left edge, 1 refers to the bottom or right edge. |

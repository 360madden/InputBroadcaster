# Frame:GetStrata

- Original source: frame_getstrata.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Gets the frame's strata. The strata determines render order on a coarser level than Layer does, as well as determining how far an element is brought to the front when clicked on.

Gets the frame's strata. The strata determines render order on a coarser level than Layer does, as well as determining how far an element is brought to the front when clicked on.

### Usage:

| --- | --- | --- | --- |
| *strata* = Frame:GetStrata() | | | |
| Parameter | Type | Datatype | Description |
| *strata* | result | *string* | The item's current strata. |

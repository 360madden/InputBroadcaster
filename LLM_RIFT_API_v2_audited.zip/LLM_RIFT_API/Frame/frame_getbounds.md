# Frame:GetBounds

- Original source: frame_getbounds.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Retrieves the complete bounds of this element.

Retrieves the complete bounds of this element.

### Usage:

| --- | --- | --- | --- |
| *left, top, right, bottom* = Layout:GetBounds() | | | |
| Parameter | Type | Datatype | Description |
| *bottom* | result | *number* | The Y position of the bottom edge of this element. |
| *left* | result | *number* | The X position of the left edge of this element. |
| *right* | result | *number* | The X position of the right edge of this element. |
| *top* | result | *number* | The Y position of the top edge of this element. |

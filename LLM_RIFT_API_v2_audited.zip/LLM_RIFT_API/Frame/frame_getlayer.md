# Frame:GetLayer

- Original source: frame_getlayer.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Gets the frame's layer order.

Gets the frame's layer order.

### Usage:

| --- | --- | --- | --- |
| *layer* = Frame:GetLayer() | | | |
| Parameter | Type | Datatype | Description |
| *layer* | result | *number* | The render layer of this frame. See Frame:SetLayer for details. |

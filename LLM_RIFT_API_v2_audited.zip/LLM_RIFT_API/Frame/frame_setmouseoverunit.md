# Frame:SetMouseoverUnit

- Original source: frame_setmouseoverunit.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Sets the unit that will be represented by this frame.

Sets the unit that will be represented by this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:SetMouseoverUnit(*unit*) | | | |
| Parameter | Type | Datatype | Description |
| *unit* | parameter | *nil, unit* | The new mouseover unit. May be a unit ID or a unit specifier. Pass in nil to disable the mouseover effect. |

**requireSecureFrameAndInsecureEnvironment**
:   true

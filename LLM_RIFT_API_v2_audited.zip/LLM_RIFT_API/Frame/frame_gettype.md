# Frame:GetType

- Original source: frame_gettype.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Retrieves the type of this element.

Retrieves the type of this element.

### Usage:

| --- | --- | --- | --- |
| *type* = Layout:GetType() | | | |
| Parameter | Type | Datatype | Description |
| *type* | result | *string* | The type of this element. |

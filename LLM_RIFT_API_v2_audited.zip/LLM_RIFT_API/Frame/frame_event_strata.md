# Frame.Event:Strata

- Original source: frame_event_strata.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals a change in the item's strata.

Signals a change in the item's strata.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Strata() | | | |

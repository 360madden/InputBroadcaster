# Frame.Event:KeyFocusLoss

- Original source: frame_event_keyfocusloss.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals losing key focus.

Signals losing key focus.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyFocusLoss() | | | |

# Frame:ReadHeight

- Original source: frame_readheight.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Read a set height from this frame.

Read a set height from this frame.

### Usage:

| --- | --- | --- | --- |
| *height* = Layout:ReadHeight() | | | |
| Parameter | Type | Datatype | Description |
| *height* | result | *number* | The parameter passed to SetHeight(), or nil if no such parameter has been passed. |

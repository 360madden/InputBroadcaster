# Frame:GetOwner

- Original source: frame_getowner.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Retrieves the owner of this element.

Retrieves the owner of this element.

### Usage:

| --- | --- | --- | --- |
| *owner* = Layout:GetOwner() | | | |
| Parameter | Type | Datatype | Description |
| *owner* | result | *string* | The owner of this element. Given as an addon identifier. |

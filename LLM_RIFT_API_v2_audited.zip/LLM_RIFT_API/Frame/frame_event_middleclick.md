# Frame.Event:MiddleClick

- Original source: frame_event_middleclick.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals that the mouse's middle button has been clicked inside the frame. Blocks middle mouse events from frames below this one.

Signals that the mouse's middle button has been clicked inside the frame. Blocks middle mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:MiddleClick() | | | |

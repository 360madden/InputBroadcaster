# Frame.Event:KeyFocusGain

- Original source: frame_event_keyfocusgain.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals gaining key focus.

Signals gaining key focus.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyFocusGain() | | | |

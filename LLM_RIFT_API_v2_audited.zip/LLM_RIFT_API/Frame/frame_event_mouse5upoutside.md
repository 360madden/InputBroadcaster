# Frame.Event:Mouse5Upoutside

- Original source: frame_event_mouse5upoutside.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals that the mouse's fifth button has been released outside the frame, after a "Down" message. Blocks fifth button mouse events from frames below this one.

Signals that the mouse's fifth button has been released outside the frame, after a "Down" message. Blocks fifth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse5Upoutside() | | | |

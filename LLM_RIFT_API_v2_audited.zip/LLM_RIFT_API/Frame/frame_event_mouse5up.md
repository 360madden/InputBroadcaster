# Frame.Event:Mouse5Up

- Original source: frame_event_mouse5up.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals that the mouse's fifth button has been released inside the frame. Blocks fifth button mouse events from frames below this one.

Signals that the mouse's fifth button has been released inside the frame. Blocks fifth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse5Up() | | | |

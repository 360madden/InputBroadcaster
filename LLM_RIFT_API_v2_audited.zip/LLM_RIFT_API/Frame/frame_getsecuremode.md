# Frame:GetSecureMode

- Original source: frame_getsecuremode.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Get the current secure mode. See SetSecureMode for details.

Get the current secure mode. See SetSecureMode for details.

### Usage:

| --- | --- | --- | --- |
| *secure* = Frame:GetSecureMode() | | | |
| Parameter | Type | Datatype | Description |
| *secure* | result | *string* | The current secure mode. |

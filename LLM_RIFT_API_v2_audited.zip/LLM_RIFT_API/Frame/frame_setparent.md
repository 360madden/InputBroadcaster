# Frame:SetParent

- Original source: frame_setparent.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Sets the parent of this frame. Circular dependencies result in undefined behavior. If this frame's secure mode is "restricted", then its parent must also have a secure mode of "restricted".

Sets the parent of this frame. Circular dependencies result in undefined behavior. If this frame's secure mode is "restricted", then its parent must also have a secure mode of "restricted".

### Usage:

| --- | --- | --- | --- |
| Frame:SetParent(*parent*) | | | |
| Parameter | Type | Datatype | Description |
| *parent* | parameter | *Element* | The new parent for this frame. |

**noSecureFrameAndEnvironment**
:   true

# Frame.Event:KeyUp

- Original source: frame_event_keyup.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals a key released.

Signals a key released.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyUp(*button*) | | | |
| Parameter | Type | Datatype | Description |
| *button* | parameter | *variant* | The key, in string form. |

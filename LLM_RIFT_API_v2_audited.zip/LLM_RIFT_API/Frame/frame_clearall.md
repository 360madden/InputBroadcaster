# Frame:ClearAll

- Original source: frame_clearall.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Clear all set points and sizes from this frame.

Clear all set points and sizes from this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:ClearAll() | | | |

**noSecureFrameAndEnvironment**
:   true

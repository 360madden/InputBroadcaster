# Frame:ReadAll

- Original source: frame_readall.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Read all set points and sizes from this frame.

Read all set points and sizes from this frame.

### Usage:

| --- | --- | --- | --- |
| *results* = Layout:ReadAll() | | | |
| Parameter | Type | Datatype | Description |
| *results* | result | *table* | Result table. Contains data in the following format: {x = {size = (size), [(position)] = {layout = (layout), position = (position), offset = (offset)}}, y = (the same thing)}. |

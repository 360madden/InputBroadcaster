# Frame.Event:Mouse4Upoutside

- Original source: frame_event_mouse4upoutside.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Signals that the mouse's fourth button has been released outside the frame, after a "Down" message. Blocks fourth button mouse events from frames below this one.

Signals that the mouse's fourth button has been released outside the frame, after a "Down" message. Blocks fourth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse4Upoutside() | | | |

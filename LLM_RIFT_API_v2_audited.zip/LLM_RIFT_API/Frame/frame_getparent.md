# Frame:GetParent

- Original source: frame_getparent.html
- Category: Frame
- Priority tier: Core
- Source index: Frame_index.html

**Doc summary:** Gets the parent of this frame.

Gets the parent of this frame.

### Usage:

| --- | --- | --- | --- |
| *parent* = Frame:GetParent() | | | |
| Parameter | Type | Datatype | Description |
| *parent* | result | *Element* | The parent element of this frame. |

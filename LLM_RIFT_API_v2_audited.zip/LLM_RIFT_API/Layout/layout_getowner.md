# Layout:GetOwner

- Original source: layout_getowner.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Retrieves the owner of this element.

Retrieves the owner of this element.

### Usage:

| --- | --- | --- | --- |
| *owner* = Layout:GetOwner() | | | |
| Parameter | Type | Datatype | Description |
| *owner* | result | *string* | The owner of this element. Given as an addon identifier. |

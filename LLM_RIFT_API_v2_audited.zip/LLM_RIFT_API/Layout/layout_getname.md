# Layout:GetName

- Original source: layout_getname.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Retrieves the name of this element.

Retrieves the name of this element.

### Usage:

| --- | --- | --- | --- |
| *name* = Layout:GetName() | | | |
| Parameter | Type | Datatype | Description |
| *name* | result | *string* | The name of this element, as provided by the addon that created it. |

# Layout:GetHeight

- Original source: layout_getheight.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Retrieves the height of this element.

Retrieves the height of this element.

### Usage:

| --- | --- | --- | --- |
| *height* = Layout:GetHeight() | | | |
| Parameter | Type | Datatype | Description |
| *height* | result | *number* | The height of this element. |

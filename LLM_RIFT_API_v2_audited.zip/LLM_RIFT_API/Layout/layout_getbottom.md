# Layout:GetBottom

- Original source: layout_getbottom.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Retrieves the Y position of the bottom edge of this element.

Retrieves the Y position of the bottom edge of this element.

### Usage:

| --- | --- | --- | --- |
| *bottom* = Layout:GetBottom() | | | |
| Parameter | Type | Datatype | Description |
| *bottom* | result | *number* | The Y position of the bottom edge of this element. |

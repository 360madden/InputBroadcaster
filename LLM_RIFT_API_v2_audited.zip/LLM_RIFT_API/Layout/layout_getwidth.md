# Layout:GetWidth

- Original source: layout_getwidth.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Retrieves the width of this element.

Retrieves the width of this element.

### Usage:

| --- | --- | --- | --- |
| *width* = Layout:GetWidth() | | | |
| Parameter | Type | Datatype | Description |
| *width* | result | *number* | The width of this element. |

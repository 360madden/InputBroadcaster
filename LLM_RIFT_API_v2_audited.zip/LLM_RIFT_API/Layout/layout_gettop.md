# Layout:GetTop

- Original source: layout_gettop.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Retrieves the Y position of the top edge of this element.

Retrieves the Y position of the top edge of this element.

### Usage:

| --- | --- | --- | --- |
| *top* = Layout:GetTop() | | | |
| Parameter | Type | Datatype | Description |
| *top* | result | *number* | The Y position of the top edge of this element. |

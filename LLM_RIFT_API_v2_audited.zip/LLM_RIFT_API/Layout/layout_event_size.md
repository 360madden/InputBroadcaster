# Layout.Event:Size

- Original source: layout_event_size.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Signals that the frame's size has changed.

Signals that the frame's size has changed.

### Usage:

| --- | --- | --- | --- |
| Layout.Event:Size() | | | |

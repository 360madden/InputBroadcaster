# Layout:GetType

- Original source: layout_gettype.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Retrieves the type of this element.

Retrieves the type of this element.

### Usage:

| --- | --- | --- | --- |
| *type* = Layout:GetType() | | | |
| Parameter | Type | Datatype | Description |
| *type* | result | *string* | The type of this element. |

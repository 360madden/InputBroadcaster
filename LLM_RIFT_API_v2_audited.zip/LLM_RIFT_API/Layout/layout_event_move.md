# Layout.Event:Move

- Original source: layout_event_move.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Signals that the frame's vertices have moved.

Signals that the frame's vertices have moved.

### Usage:

| --- | --- | --- | --- |
| Layout.Event:Move() | | | |

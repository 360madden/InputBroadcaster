# Layout:ReadAll

- Original source: layout_readall.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Read all set points and sizes from this frame.

Read all set points and sizes from this frame.

### Usage:

| --- | --- | --- | --- |
| *results* = Layout:ReadAll() | | | |
| Parameter | Type | Datatype | Description |
| *results* | result | *table* | Result table. Contains data in the following format: {x = {size = (size), [(position)] = {layout = (layout), position = (position), offset = (offset)}}, y = (the same thing)}. |

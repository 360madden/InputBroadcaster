# Layout:GetEventTable

- Original source: layout_geteventtable.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Retrieves the event table of this element. By default, this value is also stored in "this.Event".

Retrieves the event table of this element. By default, this value is also stored in "this.Event".

### Usage:

| --- | --- | --- | --- |
| *eventTable* = Layout:GetEventTable() | | | |
| Parameter | Type | Datatype | Description |
| *eventTable* | result | *table* | The event table of this element. |

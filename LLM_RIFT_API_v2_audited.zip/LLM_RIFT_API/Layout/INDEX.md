# Layout
**Priority:** Secondary
**Purpose:** Layout-oriented frame methods and event helpers.
**Entry count:** 23
**LLM note:** Layout is specialized. Start with Frame unless the task explicitly needs Layout behavior.
## Most important files first
- [Layout](layout.md) — A UI element of type Layout or derived from Layout.
- [Layout:EventAttach](layout_eventattach.md) — Attaches an event handler to an event.
- [Layout:EventDetach](layout_eventdetach.md) — Detaches an event handler from an event. Any parameter can be 'nil', and this is interpreted as a...
- [Layout.Event:Move](layout_event_move.md) — Signals that the frame's vertices have moved.
- [Layout.Event:Size](layout_event_size.md) — Signals that the frame's size has changed.
- [Layout:EventList](layout_eventlist.md) — Lists the current event handlers for an event.
- [Layout:EventMacroGet](layout_eventmacroget.md) — Gets the macro that will be triggered when this event occurs.
- [Layout:EventMacroSet](layout_eventmacroset.md) — Sets the macro that will be triggered when this event occurs.

## Full file list
- [Layout](layout.md) — A UI element of type Layout or derived from Layout.
- [Layout:EventList](layout_eventlist.md) — Lists the current event handlers for an event.
- [Layout:EventAttach](layout_eventattach.md) — Attaches an event handler to an event.
- [Layout:EventDetach](layout_eventdetach.md) — Detaches an event handler from an event. Any parameter can be 'nil', and this is interpreted as a...
- [Layout.Event:Move](layout_event_move.md) — Signals that the frame's vertices have moved.
- [Layout.Event:Size](layout_event_size.md) — Signals that the frame's size has changed.
- [Layout:EventMacroGet](layout_eventmacroget.md) — Gets the macro that will be triggered when this event occurs.
- [Layout:EventMacroSet](layout_eventmacroset.md) — Sets the macro that will be triggered when this event occurs.
- [Layout:GetBottom](layout_getbottom.md) — Retrieves the Y position of the bottom edge of this element.
- [Layout:GetBounds](layout_getbounds.md) — Retrieves the complete bounds of this element.
- [Layout:GetEventTable](layout_geteventtable.md) — Retrieves the event table of this element. By default, this value is also stored in "this.Event".
- [Layout:GetHeight](layout_getheight.md) — Retrieves the height of this element.
- [Layout:GetLeft](layout_getleft.md) — Retrieves the X position of the left edge of this element.
- [Layout:GetName](layout_getname.md) — Retrieves the name of this element.
- [Layout:GetOwner](layout_getowner.md) — Retrieves the owner of this element.
- [Layout:GetRight](layout_getright.md) — Retrieves the X position of the right edge of this element.
- [Layout:GetTop](layout_gettop.md) — Retrieves the Y position of the top edge of this element.
- [Layout:GetType](layout_gettype.md) — Retrieves the type of this element.
- [Layout:GetWidth](layout_getwidth.md) — Retrieves the width of this element.
- [Layout:ReadAll](layout_readall.md) — Read all set points and sizes from this frame.
- [Layout:ReadHeight](layout_readheight.md) — Read a set height from this frame.
- [Layout:ReadPoint](layout_readpoint.md) — Read a set point from this frame. Must be given a single-axis coordinate.
- [Layout:ReadWidth](layout_readwidth.md) — Read a set width from this frame.
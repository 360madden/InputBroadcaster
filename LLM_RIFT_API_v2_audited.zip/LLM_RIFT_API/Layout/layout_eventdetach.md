# Layout:EventDetach

- Original source: layout_eventdetach.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Detaches an event handler from an event. Any parameter can be 'nil', and this is interpreted as a wildcard. If multiple events match the constraints, only one will be detached.

Detaches an event handler from an event. Any parameter can be 'nil', and this is interpreted as a wildcard. If multiple events match the constraints, only one will be detached.

### Usage:

| --- | --- | --- | --- |
| Layout:EventDetach(*handle*, *callback*) | | | |
| Layout:EventDetach(*handle*, *callback*, *label*) | | | |
| Layout:EventDetach(*handle*, *callback*, *label*, *priority*) | | | |
| Layout:EventDetach(*handle*, *callback*, *label*, *priority*, *owner*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *function/nil* | A callback function to search for. |
| *handle* | parameter | *eventFrame* | A handle to a frame event, usually pulled out of the "Event.UI." hierarchy. |
| *label* | parameter | *string/nil* | Human-readable label used to identify the handler in error reports, performance reports, and for later detaching. |
| *owner* | parameter | *string/nil* | Owner to search for. |
| *priority* | parameter | *number/nil* | Priority of the event handler. Higher numbers trigger first. |

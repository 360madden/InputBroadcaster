# Layout

- Original source: layout.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** A UI element of type Layout or derived from Layout.

A UI element of type Layout or derived from Layout.

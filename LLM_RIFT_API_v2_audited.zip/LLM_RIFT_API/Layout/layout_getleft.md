# Layout:GetLeft

- Original source: layout_getleft.html
- Category: Layout
- Priority tier: Core
- Source index: Layout_index.html

**Doc summary:** Retrieves the X position of the left edge of this element.

Retrieves the X position of the left edge of this element.

### Usage:

| --- | --- | --- | --- |
| *left* = Layout:GetLeft() | | | |
| Parameter | Type | Datatype | Description |
| *left* | result | *number* | The X position of the left edge of this element. |

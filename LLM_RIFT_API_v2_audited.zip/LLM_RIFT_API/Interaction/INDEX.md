# Interaction
**Priority:** Secondary
**Purpose:** Interaction inspection and interaction events.
**Entry count:** 2
## Most important files first
- [Inspect.Interaction](inspect_interaction.md) — Provides information about what types of interaction are available.
- [Event.Interaction](event_interaction.md) — Signals a change in available interaction types.

## Full file list
- [Inspect.Interaction](inspect_interaction.md) — Provides information about what types of interaction are available.
- [Event.Interaction](event_interaction.md) — Signals a change in available interaction types.

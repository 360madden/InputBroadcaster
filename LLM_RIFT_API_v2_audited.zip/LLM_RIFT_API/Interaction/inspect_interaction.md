# Inspect.Interaction

- Original source: inspect_interaction.html
- Category: Interaction
- Priority tier: Secondary
- Source index: Interaction_index.html

**Doc summary:** Provides information about what types of interaction are available.

Provides information about what types of interaction are available.

### Usage:

| --- | --- | --- | --- |
| *interactions* = Inspect.Interaction() | | | |
| *status* = Inspect.Interaction(*interaction*) | | | |
| Parameter | Type | Datatype | Description |
| *interaction* | parameter | *string* | Optional name of the interaction type to query. Valid values include "auction", "bank", "guildbank", and "mail". |
| *interactions* | result | *table* | Table from interaction type to indicator of whether that interaction is available. |
| *status* | result | *boolean* | Whether or not that interaction type is available. |

# Event.Interaction

- Original source: event_interaction.html
- Category: Interaction
- Priority tier: Secondary
- Source index: Interaction_index.html

**Doc summary:** Signals a change in available interaction types.

Signals a change in available interaction types.

### Usage:

| --- | --- | --- | --- |
| Event.Interaction(*interaction*, *state*) | | | |
| Parameter | Type | Datatype | Description |
| *interaction* | parameter | *variant* | The identifier of the interaction type. May be any of "auction", "bank", "guildbank", or "mail". |
| *state* | parameter | *<nope>* | Boolean indicating whether or not that interaction is available. |

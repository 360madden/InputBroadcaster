# Event.Attunement.Progress.Rested

- Original source: event_attunement_progress_rested.html
- Category: Attunement
- Priority tier: Secondary
- Source index: Attunement_index.html

**Doc summary:** Signals your available attunement rested experience changing.

Signals your available attunement rested experience changing.

### Usage:

| --- | --- | --- | --- |
| Event.Attunement.Progress.Rested(*rested*) | | | |
| Parameter | Type | Datatype | Description |
| *rested* | parameter | *variant* | Quantity of available attunement rested experience. |

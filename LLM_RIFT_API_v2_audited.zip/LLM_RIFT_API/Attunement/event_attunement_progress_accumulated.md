# Event.Attunement.Progress.Accumulated

- Original source: event_attunement_progress_accumulated.html
- Category: Attunement
- Priority tier: Secondary
- Source index: Attunement_index.html

**Doc summary:** Signals your accumulated attunement experience changing.

Signals your accumulated attunement experience changing.

### Usage:

| --- | --- | --- | --- |
| Event.Attunement.Progress.Accumulated(*accumulated*) | | | |
| Parameter | Type | Datatype | Description |
| *accumulated* | parameter | *variant* | Total quantity of accumulated attunement experience in this level. |

# Inspect.Attunement.Progress

- Original source: inspect_attunement_progress.html
- Category: Attunement
- Priority tier: Secondary
- Source index: Attunement_index.html

**Doc summary:** Returns information on your current attunement progress.

Returns information on your current attunement progress.

### Usage:

| --- | --- | --- | --- |
| *result* = Inspect.Attunement.Progress() | | | |
| Parameter | Type | Datatype | Description |
| *result* | result | *table* | Table containing information on attunement progress. |

**members**
:   |  |  |
    | --- | --- |
    | accumulated | Attunement experience accumulated so far in this attunement level. |
    | available | Number of unused attunement ranks. |
    | needed | Quantity of attunement experience needed to gain a level. |
    | rested | Quantity of available attunement rested experience. |
    | spent | Number of spent attunement ranks. |

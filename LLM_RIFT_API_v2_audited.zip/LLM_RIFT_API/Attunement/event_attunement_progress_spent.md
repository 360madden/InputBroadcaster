# Event.Attunement.Progress.Spent

- Original source: event_attunement_progress_spent.html
- Category: Attunement
- Priority tier: Secondary
- Source index: Attunement_index.html

**Doc summary:** Signals your spent attunement points changing.

Signals your spent attunement points changing.

### Usage:

| --- | --- | --- | --- |
| Event.Attunement.Progress.Spent(*spent*) | | | |
| Parameter | Type | Datatype | Description |
| *spent* | parameter | *variant* | Number of spent attunement ranks. |

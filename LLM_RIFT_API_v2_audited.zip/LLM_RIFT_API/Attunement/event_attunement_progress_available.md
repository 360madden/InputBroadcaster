# Event.Attunement.Progress.Available

- Original source: event_attunement_progress_available.html
- Category: Attunement
- Priority tier: Secondary
- Source index: Attunement_index.html

**Doc summary:** Signals your available attunement points changing.

Signals your available attunement points changing.

### Usage:

| --- | --- | --- | --- |
| Event.Attunement.Progress.Available(*available*) | | | |
| Parameter | Type | Datatype | Description |
| *available* | parameter | *variant* | Number of unused attunement ranks. |

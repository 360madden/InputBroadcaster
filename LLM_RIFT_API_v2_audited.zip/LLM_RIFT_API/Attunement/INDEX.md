# Attunement
**Priority:** Secondary
**Purpose:** Attunement inspection and events.
**Entry count:** 5
## Most important files first
- [Inspect.Attunement.Progress](inspect_attunement_progress.md) — Returns information on your current attunement progress.
- [Event.Attunement.Progress.Accumulated](event_attunement_progress_accumulated.md) — Signals your accumulated attunement experience changing.
- [Event.Attunement.Progress.Available](event_attunement_progress_available.md) — Signals your available attunement points changing.
- [Event.Attunement.Progress.Rested](event_attunement_progress_rested.md) — Signals your available attunement rested experience changing.
- [Event.Attunement.Progress.Spent](event_attunement_progress_spent.md) — Signals your spent attunement points changing.

## Full file list
- [Inspect.Attunement.Progress](inspect_attunement_progress.md) — Returns information on your current attunement progress.
- [Event.Attunement.Progress.Accumulated](event_attunement_progress_accumulated.md) — Signals your accumulated attunement experience changing.
- [Event.Attunement.Progress.Available](event_attunement_progress_available.md) — Signals your available attunement points changing.
- [Event.Attunement.Progress.Rested](event_attunement_progress_rested.md) — Signals your available attunement rested experience changing.
- [Event.Attunement.Progress.Spent](event_attunement_progress_spent.md) — Signals your spent attunement points changing.

# Inspect.Addon.Current

- Original source: inspect_addon_current.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Returns the current addon. This information is used internally for counting CPU usage and determining frame ownership.

Returns the current addon. This information is used internally for counting CPU usage and determining frame ownership.

### Usage:

| --- | --- | --- | --- |
| *addonIdentifier* = Inspect.Addon.Current() | | | |
| Parameter | Type | Datatype | Description |
| *addonIdentifier* | result | *string* | The addon's identifier, as written in its TOC file. |

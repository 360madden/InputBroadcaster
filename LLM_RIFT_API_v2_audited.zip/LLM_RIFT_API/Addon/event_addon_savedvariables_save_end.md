# Event.Addon.SavedVariables.Save.End

- Original source: event_addon_savedvariables_save_end.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Signals the end of an addon's saved variable saving.

Signals the end of an addon's saved variable saving.

### Usage:

| --- | --- | --- | --- |
| Event.Addon.SavedVariables.Save.End(*addonidentifier*) | | | |
| Parameter | Type | Datatype | Description |
| *addonidentifier* | parameter | *variant* | The addon's identifier. |

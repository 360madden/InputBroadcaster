# Inspect.Addon.List

- Original source: inspect_addon_list.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Lists all the addons that the client has loaded.

Lists all the addons that the client has loaded.

### Usage:

| --- | --- | --- | --- |
| *addons* = Inspect.Addon.List() | | | |
| Parameter | Type | Datatype | Description |
| *addons* | result | *table* | Map of addon identifier to addon version, or "true" if no version is provided. |

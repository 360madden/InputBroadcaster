# Event.Addon.SavedVariables.Load.Begin

- Original source: event_addon_savedvariables_load_begin.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Signals the beginning of an addon's saved variable loading.

Signals the beginning of an addon's saved variable loading.

### Usage:

| --- | --- | --- | --- |
| Event.Addon.SavedVariables.Load.Begin(*addonidentifier*) | | | |
| Parameter | Type | Datatype | Description |
| *addonidentifier* | parameter | *variant* | The addon's identifier. |

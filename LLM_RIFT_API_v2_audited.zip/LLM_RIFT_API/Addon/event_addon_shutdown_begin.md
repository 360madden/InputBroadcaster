# Event.Addon.Shutdown.Begin

- Original source: event_addon_shutdown_begin.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Signals the beginning of the shutdown sequence.

Signals the beginning of the shutdown sequence.

### Usage:

| --- | --- | --- | --- |
| Event.Addon.Shutdown.Begin() | | | |

# Event.Addon.Shutdown.End

- Original source: event_addon_shutdown_end.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Signals the end of the shutdown sequence. This is the last event that will be sent.

Signals the end of the shutdown sequence. This is the last event that will be sent.

### Usage:

| --- | --- | --- | --- |
| Event.Addon.Shutdown.End() | | | |

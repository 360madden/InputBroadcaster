# Event.Addon.SavedVariables.Load.End

- Original source: event_addon_savedvariables_load_end.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Signals the end of an addon's saved variable load.

Signals the end of an addon's saved variable load.

### Usage:

| --- | --- | --- | --- |
| Event.Addon.SavedVariables.Load.End(*addonidentifier*) | | | |
| Parameter | Type | Datatype | Description |
| *addonidentifier* | parameter | *variant* | The addon's identifier. |

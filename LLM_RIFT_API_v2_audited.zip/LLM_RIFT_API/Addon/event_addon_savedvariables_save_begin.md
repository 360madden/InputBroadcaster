# Event.Addon.SavedVariables.Save.Begin

- Original source: event_addon_savedvariables_save_begin.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Signals the beginning of an addon's saved variable saving.

Signals the beginning of an addon's saved variable saving.

### Usage:

| --- | --- | --- | --- |
| Event.Addon.SavedVariables.Save.Begin(*addonidentifier*) | | | |
| Parameter | Type | Datatype | Description |
| *addonidentifier* | parameter | *variant* | The addon's identifier. |

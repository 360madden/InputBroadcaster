# Event.Addon.Startup.End

- Original source: event_addon_startup_end.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Signals the end of the startup sequence. At this point, all addons are fully loaded and initialized.

Signals the end of the startup sequence. At this point, all addons are fully loaded and initialized.

### Usage:

| --- | --- | --- | --- |
| Event.Addon.Startup.End() | | | |

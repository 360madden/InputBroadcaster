# Inspect.Addon.Detail

- Original source: inspect_addon_detail.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Provides detailed information about loaded addons.

Provides detailed information about loaded addons.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Addon.Detail(*addon*) | | | |
| *details* = Inspect.Addon.Detail(*addons*) | | | |
| Parameter | Type | Datatype | Description |
| *addon* | parameter | *string* | An addon identifier. |
| *addons* | parameter | *table* | A table containing addon identifiers. |
| *detail* | result | *table* | Detail table for a single addon. |
| *details* | result | *table* | Detail tables for all requested addons. The key is the addon identifier, the value is the addon's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | data | The "data" table provided to the addon at load time. |
    | description | The chosen localization of the TOC Description field. |
    | id | The ID of the requested element. |
    | identifier | The addon's identifier. |
    | name | The chosen localization of the TOC Name field. |
    | nameShort | The chosen localization of the TOC NameShort field. |
    | toc | The addon's RiftAddon.toc file, parsed and in table form. |

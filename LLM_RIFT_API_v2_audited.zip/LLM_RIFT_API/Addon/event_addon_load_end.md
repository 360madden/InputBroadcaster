# Event.Addon.Load.End

- Original source: event_addon_load_end.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Signals the end of an addon's loading sequence. At this point, that addon is fully loaded and initialized.

Signals the end of an addon's loading sequence. At this point, that addon is fully loaded and initialized.

### Usage:

| --- | --- | --- | --- |
| Event.Addon.Load.End(*addonidentifier*) | | | |
| Parameter | Type | Datatype | Description |
| *addonidentifier* | parameter | *variant* | The addon's identifier. |

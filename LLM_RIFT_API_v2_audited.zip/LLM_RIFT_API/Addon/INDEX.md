# Addon
**Priority:** Core
**Purpose:** Addon lifecycle events, startup/shutdown, and saved-variable timing.
**Entry count:** 13
**LLM note:** Use addon lifecycle events as timing anchors for startup and persistence logic.
## Most important files first
- [Event.Addon.Startup.End](event_addon_startup_end.md) — Signals the end of the startup sequence. At this point, all addons are fully loaded and initialized.
- [Event.Addon.SavedVariables.Load.Begin](event_addon_savedvariables_load_begin.md) — Signals the beginning of an addon's saved variable loading.
- [Event.Addon.SavedVariables.Load.End](event_addon_savedvariables_load_end.md) — Signals the end of an addon's saved variable load.
- [Event.Addon.SavedVariables.Save.Begin](event_addon_savedvariables_save_begin.md) — Signals the beginning of an addon's saved variable saving.
- [Event.Addon.SavedVariables.Save.End](event_addon_savedvariables_save_end.md) — Signals the end of an addon's saved variable saving.
- [Inspect.Addon.Detail](inspect_addon_detail.md) — Provides detailed information about loaded addons.
- [Inspect.Addon.List](inspect_addon_list.md) — Lists all the addons that the client has loaded.
- [Event.Addon.Load.End](event_addon_load_end.md) — Signals the end of an addon's loading sequence. At this point, that addon is fully loaded and ini...

## Full file list
- [Inspect.Addon.Detail](inspect_addon_detail.md) — Provides detailed information about loaded addons.
- [Inspect.Addon.List](inspect_addon_list.md) — Lists all the addons that the client has loaded.
- [Event.Addon.SavedVariables.Load.Begin](event_addon_savedvariables_load_begin.md) — Signals the beginning of an addon's saved variable loading.
- [Event.Addon.SavedVariables.Load.End](event_addon_savedvariables_load_end.md) — Signals the end of an addon's saved variable load.
- [Event.Addon.SavedVariables.Save.Begin](event_addon_savedvariables_save_begin.md) — Signals the beginning of an addon's saved variable saving.
- [Event.Addon.SavedVariables.Save.End](event_addon_savedvariables_save_end.md) — Signals the end of an addon's saved variable saving.
- [Event.Addon.Startup.End](event_addon_startup_end.md) — Signals the end of the startup sequence. At this point, all addons are fully loaded and initialized.
- [Event.Addon.Shutdown.Begin](event_addon_shutdown_begin.md) — Signals the beginning of the shutdown sequence.
- [Event.Addon.Shutdown.End](event_addon_shutdown_end.md) — Signals the end of the shutdown sequence. This is the last event that will be sent.
- [Inspect.Addon.Cpu](inspect_addon_cpu.md) — Returns recent CPU usage information. This is calculated using an exponential-falloff method.
- [Inspect.Addon.Current](inspect_addon_current.md) — Returns the current addon. This information is used internally for counting CPU usage and determi...
- [Event.Addon.Load.Begin](event_addon_load_begin.md) — Signals the beginning of an addon's loading sequence.
- [Event.Addon.Load.End](event_addon_load_end.md) — Signals the end of an addon's loading sequence. At this point, that addon is fully loaded and ini...
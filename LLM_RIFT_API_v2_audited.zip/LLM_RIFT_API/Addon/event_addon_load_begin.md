# Event.Addon.Load.Begin

- Original source: event_addon_load_begin.html
- Category: Addon
- Priority tier: Core
- Source index: Addon_index.html

**Doc summary:** Signals the beginning of an addon's loading sequence.

Signals the beginning of an addon's loading sequence.

### Usage:

| --- | --- | --- | --- |
| Event.Addon.Load.Begin(*addonidentifier*) | | | |
| Parameter | Type | Datatype | Description |
| *addonidentifier* | parameter | *variant* | The addon's identifier. |

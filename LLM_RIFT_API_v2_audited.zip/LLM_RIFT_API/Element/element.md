# Element

- Original source: element.html
- Category: Element
- Priority tier: Core
- Source index: Element_index.html

**Doc summary:** A UI element of type Element or derived from Element.

A UI element of type Element or derived from Element.

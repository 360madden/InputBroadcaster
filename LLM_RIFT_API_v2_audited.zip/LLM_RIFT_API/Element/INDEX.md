# Element
**Priority:** Secondary
**Purpose:** Base UI element type documentation.
**Entry count:** 1
**LLM note:** Base-type reference only. Usually less useful than Frame, Native, or UI.CreateFrame.
## Most important files first
- [Element](element.md) — A UI element of type Element or derived from Element.

## Full file list
- [Element](element.md) — A UI element of type Element or derived from Element.
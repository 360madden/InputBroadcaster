# Inspect.Event.List

- Original source: inspect_event_list.html
- Category: Event
- Priority tier: Core
- Source index: Event_index.html

**Doc summary:** Lists the current event handlers for an event.

Lists the current event handlers for an event.

### Usage:

| --- | --- | --- | --- |
| *result* = Inspect.Event.List(*event*) | | | |
| Parameter | Type | Datatype | Description |
| *event* | parameter | *eventGlobal* | A global event handle, usually pulled out of the "Event." hierarchy. |
| *result* | result | *table* | A table of event handlers for this event. |

**members**
:   |  |  |
    | --- | --- |
    | handler | The handler that will be called when the event fires. |
    | label | Label assigned to the event handler at creation. |
    | owner | Owner addon for the event handler. |
    | priority | Priority for the event handler. |

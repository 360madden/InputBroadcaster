# Command.Event.Attach

- Original source: command_event_attach.html
- Category: Event
- Priority tier: Core
- Source index: Event_index.html

**Doc summary:** Attaches an event handler to an event.

Attaches an event handler to an event.

### Usage:

| --- | --- | --- | --- |
| Command.Event.Attach(*event*, *handler*, *label*) | | | |
| Command.Event.Attach(*event*, *handler*, *label*, *priority*) | | | |
| Parameter | Type | Datatype | Description |
| *event* | parameter | *eventGlobal* | A global event handle, usually pulled out of the "Event." hierarchy. |
| *handler* | parameter | *function* | A global event handler function. This will be called when the event fires. The first parameter will be the standard global event handle, any other parameters will follow that. |
| *label* | parameter | *string* | Human-readable label used to identify the handler in error reports, performance reports, and for later detaching. |
| *priority* | parameter | *number* | Priority of the event handler. Higher numbers trigger first. |

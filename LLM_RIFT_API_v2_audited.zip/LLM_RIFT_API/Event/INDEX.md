# Event
**Priority:** Core
**Purpose:** Global event creation, attachment, detachment, and inspection.
**Entry count:** 4
**LLM note:** Prefer these global event docs before diving into specific Event.* families.
## Most important files first
- [Command.Event.Attach](command_event_attach.md) — Attaches an event handler to an event.
- [Command.Event.Detach](command_event_detach.md) — Detaches an event handler from an event. Any parameter can be 'nil', and this is interpreted as a...
- [Utility.Event.Create](utility_event_create.md) — Creates a custom event. Takes an identifier and an event path as parameters. Called with Create("...
- [Inspect.Event.List](inspect_event_list.md) — Lists the current event handlers for an event.

## Full file list
- [Inspect.Event.List](inspect_event_list.md) — Lists the current event handlers for an event.
- [Utility.Event.Create](utility_event_create.md) — Creates a custom event. Takes an identifier and an event path as parameters. Called with Create("...
- [Command.Event.Attach](command_event_attach.md) — Attaches an event handler to an event.
- [Command.Event.Detach](command_event_detach.md) — Detaches an event handler from an event. Any parameter can be 'nil', and this is interpreted as a...
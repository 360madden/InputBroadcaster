# Utility.Event.Create

- Original source: utility_event_create.html
- Category: Event
- Priority tier: Core
- Source index: Event_index.html

**Doc summary:** Creates a custom event. Takes an identifier and an event path as parameters. Called with Create("Identifier", "The.Event.Path") the event table will end up at Event.Identifier.The.Event.Path, and will behave like a standard Rift event table in every way. Undefined behavior if given an identifier or a path that conflicts with a built-in Rift event or an existing addon event.

Creates a custom event. Takes an identifier and an event path as parameters. Called with Create("Identifier", "The.Event.Path") the event table will end up at Event.Identifier.The.Event.Path, and will behave like a standard Rift event table in every way. Undefined behavior if given an identifier or a path that conflicts with a built-in Rift event or an existing addon event.

### Usage:

| --- | --- | --- | --- |
| *caller, handle* = Utility.Event.Create(*identifier*, *event*) | | | |
| Parameter | Type | Datatype | Description |
| *event* | parameter | *string* | The event's name. "." characters will be treated as hierarchy delimeters. |
| *identifier* | parameter | *string* | The identifier of the addon creating this event. |
| *caller* | result | *function* | A function used to trigger the event. Called with any selection of parameters, it will pass those parameters through to properly registered event handlers in order. Any errors caused by those event handlers will be caught and handled. |
| *handle* | result | *table* | The resulting event handle. |

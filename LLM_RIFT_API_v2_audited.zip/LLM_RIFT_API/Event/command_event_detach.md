# Command.Event.Detach

- Original source: command_event_detach.html
- Category: Event
- Priority tier: Core
- Source index: Event_index.html

**Doc summary:** Detaches an event handler from an event. Any parameter can be 'nil', and this is interpreted as a wildcard. If multiple events match the constraints, only one will be detached.

Detaches an event handler from an event. Any parameter can be 'nil', and this is interpreted as a wildcard. If multiple events match the constraints, only one will be detached.

### Usage:

| --- | --- | --- | --- |
| Command.Event.Detach(*event*, *handler*) | | | |
| Command.Event.Detach(*event*, *handler*, *label*) | | | |
| Command.Event.Detach(*event*, *handler*, *label*, *priority*) | | | |
| Command.Event.Detach(*event*, *handler*, *label*, *priority*, *owner*) | | | |
| Parameter | Type | Datatype | Description |
| *event* | parameter | *eventGlobal* | A global event handle, usually pulled out of the "Event." hierarchy. |
| *handler* | parameter | *function/nil* | A global event handler function. This will be called when the event fires. The first parameter will be the standard global event handle, any other parameters will follow that. |
| *label* | parameter | *string/nil* | Human-readable label used to identify the handler in error reports, performance reports, and for later detaching. |
| *owner* | parameter | *string/nil* | Owner to search for. |
| *priority* | parameter | *number/nil* | Priority of the event handler. Higher numbers trigger first. |

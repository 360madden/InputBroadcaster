# Utility.Dispatch

- Original source: utility_dispatch.html
- Category: Dispatch
- Priority tier: Core
- Source index: Dispatch_index.html

**Doc summary:** Calls a function, crediting that function's execution and errors to a specific addon. Errors will be handled by the standard error handler and not relayed to the caller. Does not return anything.

Calls a function, crediting that function's execution and errors to a specific addon. Errors will be handled by the standard error handler and not relayed to the caller. Does not return anything.

### Usage:

| --- | --- | --- | --- |
| Utility.Dispatch(*func*, *identifier*, *info*) | | | |
| Parameter | Type | Datatype | Description |
| *func* | parameter | *function* | The function to call. |
| *identifier* | parameter | *string* | The identifier of the addon to credit execution time towards. |
| *info* | parameter | *string* | An info string to be included in error reports. |

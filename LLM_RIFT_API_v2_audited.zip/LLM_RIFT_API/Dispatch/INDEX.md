# Dispatch
**Priority:** Secondary
**Purpose:** Protected call helper for safely invoking functions.
**Entry count:** 1
**LLM note:** Support helper; not a normal starting point for basic addon UI work.
## Most important files first
- [Utility.Dispatch](utility_dispatch.md) — Calls a function, crediting that function's execution and errors to a specific addon. Errors will...

## Full file list
- [Utility.Dispatch](utility_dispatch.md) — Calls a function, crediting that function's execution and errors to a specific addon. Errors will...
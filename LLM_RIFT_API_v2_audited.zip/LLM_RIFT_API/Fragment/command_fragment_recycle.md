# Command.Fragment.Recycle

- Original source: command_fragment_recycle.html
- Category: Fragment
- Priority tier: Secondary
- Source index: Fragment_index.html

**Doc summary:** Recycle planar fragments from your inventory.

Recycle planar fragments from your inventory.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Fragment.Recycle(*item*) | | | |
| Command.Fragment.Recycle(*items*) | | | |
| Parameter | Type | Datatype | Description |
| *item* | parameter | *item* | The ID of the item to be taken. |
| *items* | parameter | *table* | A table containing a list of the items to be taken. |

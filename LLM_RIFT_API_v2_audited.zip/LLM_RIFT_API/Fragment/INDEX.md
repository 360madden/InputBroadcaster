# Fragment
**Priority:** Secondary
**Purpose:** Fragment UI type documentation.
**Entry count:** 1
## Most important files first
- [Command.Fragment.Recycle](command_fragment_recycle.md) — Recycle planar fragments from your inventory.

## Full file list
- [Command.Fragment.Recycle](command_fragment_recycle.md) — Recycle planar fragments from your inventory.

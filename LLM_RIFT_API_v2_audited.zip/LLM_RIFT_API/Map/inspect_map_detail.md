# Inspect.Map.Detail

- Original source: inspect_map_detail.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Returns information about map locations.

Returns information about map locations.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Map.Detail(*location*) | | | |
| *details* = Inspect.Map.Detail(*locations*) | | | |
| Parameter | Type | Datatype | Description |
| *location* | parameter | *location* | The identifier of the location to retrieve detail for. |
| *locations* | parameter | *table* | A table of identifiers of locations to retrieve detail for. |
| *detail* | result | *table* | Detail table for a single location. |
| *details* | result | *table* | Detail tables for all requested locations. The key is the location ID, the value is the location's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | coordX | The map location's current X coordinate. |
    | coordY | The map location's current Y coordinate. |
    | coordZ | The map location's current Z coordinate. |
    | description | The description of this map location, if it has one. |
    | id | The ID of the requested element. |
    | title | The title of this map location, if it has one. |

# Inspect.Map.List

- Original source: inspect_map_list.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Returns a table of map locations.

Returns a table of map locations.

### Usage:

| --- | --- | --- | --- |
| *list* = Inspect.Map.List() | | | |
| Parameter | Type | Datatype | Description |
| *list* | result | *table* | Valid locations, in {id = true} format. |

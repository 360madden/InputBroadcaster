# Command.Map.Waypoint.Clear

- Original source: command_map_waypoint_clear.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Clears the player's current waypoint.

Clears the player's current waypoint.

### Usage:

| --- | --- | --- | --- |
| Command.Map.Waypoint.Clear() | | | |

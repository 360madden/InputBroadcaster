# Event.Map.Change

- Original source: event_map_change.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Signals the change of a map element, in some manner besides coordinates.

Signals the change of a map element, in some manner besides coordinates.

### Usage:

| --- | --- | --- | --- |
| Event.Map.Change(*elements*) | | | |
| Parameter | Type | Datatype | Description |
| *elements* | parameter | *variant* | The changed elements. Takes the form of a table. The key is the element ID. |

# Event.Map.Detail.Coord

- Original source: event_map_detail_coord.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Signals the coordinate change of a map element.

Signals the coordinate change of a map element.

### Usage:

| --- | --- | --- | --- |
| Event.Map.Detail.Coord(*x*, *y*, *z*) | | | |
| Parameter | Type | Datatype | Description |
| *x* | parameter | *variant* | The new X coordinate of the changed elements. Takes the form of a table. The key is the element ID. |
| *y* | parameter | *<nope>* | The new Y coordinate of the changed elements. Takes the form of a table. The key is the element ID. |
| *z* | parameter | *<nope>* | The new Z coordinate of the changed elements. Takes the form of a table. The key is the element ID. |

# Map
**Priority:** Core
**Purpose:** Map locations, waypoint commands, monitor mode, and map detail/events.
**Entry count:** 12
**LLM note:** Use map docs only when the addon truly needs coordinates, map elements, or waypoints.
## Most important files first
- [Inspect.Map.Detail](inspect_map_detail.md) — Returns information about map locations.
- [Inspect.Map.List](inspect_map_list.md) — Returns a table of map locations.
- [Command.Map.Monitor](command_map_monitor.md) — Controls the state of the map monitor flag. When enabled, mainmap data will be received, updating...
- [Inspect.Map.Monitor](inspect_map_monitor.md) — Inspects the state of the map monitor flag. See Command.Map.Monitor() for details.
- [Event.Map.Detail.Coord](event_map_detail_coord.md) — Signals the coordinate change of a map element.
- [Inspect.Map.Waypoint.Get](inspect_map_waypoint_get.md) — Gets a unit's current waypoint.
- [Command.Map.Waypoint.Set](command_map_waypoint_set.md) — Sets the player's waypoint.
- [Command.Map.Waypoint.Clear](command_map_waypoint_clear.md) — Clears the player's current waypoint.

## Full file list
- [Event.Map.Detail.Coord](event_map_detail_coord.md) — Signals the coordinate change of a map element.
- [Inspect.Map.Detail](inspect_map_detail.md) — Returns information about map locations.
- [Event.Map.Waypoint.Update](event_map_waypoint_update.md) — Signals the change of a player's waypoint.
- [Inspect.Map.List](inspect_map_list.md) — Returns a table of map locations.
- [Inspect.Map.Waypoint.Get](inspect_map_waypoint_get.md) — Gets a unit's current waypoint.
- [Command.Map.Waypoint.Clear](command_map_waypoint_clear.md) — Clears the player's current waypoint.
- [Command.Map.Waypoint.Set](command_map_waypoint_set.md) — Sets the player's waypoint.
- [Inspect.Map.Monitor](inspect_map_monitor.md) — Inspects the state of the map monitor flag. See Command.Map.Monitor() for details.
- [Command.Map.Monitor](command_map_monitor.md) — Controls the state of the map monitor flag. When enabled, mainmap data will be received, updating...
- [Event.Map.Add](event_map_add.md) — Signals the addition of a map element.
- [Event.Map.Change](event_map_change.md) — Signals the change of a map element, in some manner besides coordinates.
- [Event.Map.Remove](event_map_remove.md) — Signals the removal of a map element.
# Inspect.Map.Monitor

- Original source: inspect_map_monitor.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Inspects the state of the map monitor flag. See Command.Map.Monitor() for details.

Inspects the state of the map monitor flag. See Command.Map.Monitor() for details.

### Usage:

| --- | --- | --- | --- |
| *monitor* = Inspect.Map.Monitor() | | | |
| Parameter | Type | Datatype | Description |
| *monitor* | result | *boolean* | The current state of the map monitor flag. |

# Event.Map.Remove

- Original source: event_map_remove.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Signals the removal of a map element.

Signals the removal of a map element.

### Usage:

| --- | --- | --- | --- |
| Event.Map.Remove(*elements*) | | | |
| Parameter | Type | Datatype | Description |
| *elements* | parameter | *variant* | The changed elements. Takes the form of a table. The key is the element ID. |

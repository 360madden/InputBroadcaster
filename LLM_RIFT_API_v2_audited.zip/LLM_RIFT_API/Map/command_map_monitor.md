# Command.Map.Monitor

- Original source: command_map_monitor.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Controls the state of the map monitor flag. When enabled, mainmap data will be received, updating every sixty seconds. When disabled, mainmap data will be received only when the built-in map window is open.

Controls the state of the map monitor flag. When enabled, mainmap data will be received, updating every sixty seconds. When disabled, mainmap data will be received only when the built-in map window is open.

### Usage:

| --- | --- | --- | --- |
| Command.Map.Monitor(*monitor*) | | | |
| Parameter | Type | Datatype | Description |
| *monitor* | parameter | *boolean* | The new state of the map monitor flag. |

# Event.Map.Waypoint.Update

- Original source: event_map_waypoint_update.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Signals the change of a player's waypoint.

Signals the change of a player's waypoint.

### Usage:

| --- | --- | --- | --- |
| Event.Map.Waypoint.Update(*units*) | | | |
| Parameter | Type | Datatype | Description |
| *units* | parameter | *variant* | The unit whose waypoint has changed. Takes the form of a table. The key is the element ID. |

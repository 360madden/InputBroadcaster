# Event.Map.Add

- Original source: event_map_add.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Signals the addition of a map element.

Signals the addition of a map element.

### Usage:

| --- | --- | --- | --- |
| Event.Map.Add(*elements*) | | | |
| Parameter | Type | Datatype | Description |
| *elements* | parameter | *variant* | The changed elements. Takes the form of a table. The key is the element ID. |

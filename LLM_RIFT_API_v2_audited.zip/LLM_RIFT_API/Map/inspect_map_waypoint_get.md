# Inspect.Map.Waypoint.Get

- Original source: inspect_map_waypoint_get.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Gets a unit's current waypoint.

Gets a unit's current waypoint.

### Usage:

| --- | --- | --- | --- |
| *x, z* = Inspect.Map.Waypoint.Get(*unit*) | | | |
| Parameter | Type | Datatype | Description |
| *unit* | parameter | *unit* | A unit, in either unit ID or unit specifier format. |
| *x* | result | *number* | The x coordinate of the waypoint. |
| *z* | result | *number* | The z coordinate of the waypoint. |

# Command.Map.Waypoint.Set

- Original source: command_map_waypoint_set.html
- Category: Map
- Priority tier: Core
- Source index: Map_index.html

**Doc summary:** Sets the player's waypoint.

Sets the player's waypoint.

### Usage:

| --- | --- | --- | --- |
| Command.Map.Waypoint.Set(*x*, *z*) | | | |
| Parameter | Type | Datatype | Description |
| *x* | parameter | *number* | The x coordinate of the waypoint. |
| *z* | parameter | *number* | The z coordinate of the waypoint. |

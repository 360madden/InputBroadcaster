# Command.Cursor

- Original source: command_cursor.html
- Category: Cursor
- Priority tier: Core
- Source index: Cursor_index.html

**Doc summary:** Changes the contents of the cursor. Ability cursors may be set only if the environment is not in secure mode.

Changes the contents of the cursor. Ability cursors may be set only if the environment is not in secure mode.

### Usage:

| --- | --- | --- | --- |
| Command.Cursor(*hold*) | | | |
| Parameter | Type | Datatype | Description |
| *hold* | parameter | *variant* | The new cursor. Currently accepts ability, item, itemtype, or non-empty non-wildcard slot IDs. Pass nil to clear the cursor. |

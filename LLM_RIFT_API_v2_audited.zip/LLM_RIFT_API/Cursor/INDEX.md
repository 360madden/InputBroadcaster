# Cursor
**Priority:** Secondary
**Purpose:** Cursor state and cursor-related events.
**Entry count:** 3
**LLM note:** Useful only for cursor-driven interactions.
## Most important files first
- [Inspect.Cursor](inspect_cursor.md) — Returns the current contents of the cursor.
- [Command.Cursor](command_cursor.md) — Changes the contents of the cursor. Ability cursors may be set only if the environment is not in ...
- [Event.Cursor](event_cursor.md) — Signals that the cursor has changed.

## Full file list
- [Inspect.Cursor](inspect_cursor.md) — Returns the current contents of the cursor.
- [Command.Cursor](command_cursor.md) — Changes the contents of the cursor. Ability cursors may be set only if the environment is not in ...
- [Event.Cursor](event_cursor.md) — Signals that the cursor has changed.
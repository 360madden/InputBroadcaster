# Event.Cursor

- Original source: event_cursor.html
- Category: Cursor
- Priority tier: Core
- Source index: Cursor_index.html

**Doc summary:** Signals that the cursor has changed.

Signals that the cursor has changed.

### Usage:

| --- | --- | --- | --- |
| Event.Cursor(*type*, *held*) | | | |
| Parameter | Type | Datatype | Description |
| *held* | parameter | *<nope>* | The blob describing the new element held. Generally, some kind of identifier used in another part of the addon system. |
| *type* | parameter | *variant* | The current cursor type. Valid values include "ability", "item", and "itemtype". |

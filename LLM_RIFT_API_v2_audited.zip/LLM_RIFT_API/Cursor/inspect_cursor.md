# Inspect.Cursor

- Original source: inspect_cursor.html
- Category: Cursor
- Priority tier: Core
- Source index: Cursor_index.html

**Doc summary:** Returns the current contents of the cursor.

Returns the current contents of the cursor.

### Usage:

| --- | --- | --- | --- |
| *type, held* = Inspect.Cursor() | | | |
| Parameter | Type | Datatype | Description |
| *held* | result | *variant, nil* | The blob describing what is currently held. Generally, some kind of identifier used in another part of the addon system. |
| *type* | result | *string, nil* | The current cursor type. Valid values include "ability", "item", "itemtype", and nil. |

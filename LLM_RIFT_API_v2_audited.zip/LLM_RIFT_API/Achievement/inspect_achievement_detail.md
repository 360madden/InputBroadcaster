# Inspect.Achievement.Detail

- Original source: inspect_achievement_detail.html
- Category: Achievement
- Priority tier: Secondary
- Source index: Achievement_index.html

**Doc summary:** Provides detailed information about achievements.

Provides detailed information about achievements.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Achievement.Detail(*achievement*) | | | |
| *details* = Inspect.Achievement.Detail(*achievements*) | | | |
| Parameter | Type | Datatype | Description |
| *achievement* | parameter | *achievement* | The identifier of the achievement to retrieve detail for. |
| *achievements* | parameter | *table* | A table of identifiers of achievements to retrieve detail for. |
| *detail* | result | *table* | Detail table for a single achievement. |
| *details* | result | *table* | Detail tables for all requested achievements. The key is the achievement ID, the value is the achievement's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | alliance | The alliance that this achievement requires, either "guardian", "defiant", or nil. |
    | category | ID of the achievement's category. |
    | complete | true is the achievement is completed by this character. If the achievement has been completed by another of the player's characters, gives that character's name. |
    | description | The achievement's description. |
    | icon | Internal name of the achievement's icon. |
    | id | The ID of the requested element. |
    | name | The achievement's name. |
    | previous | The ID of the achievement immediately previous to this in a chain. |
    | requirement | Table listing the requirements for this achievement. Each item may include multiple members.  type: The type of the requirement. Valid values include "achievement", "artifactset", "discover", "event", "quest", and "tradeskill".  name: The name of the requirement.  count: The count required for completion.  countDone: The count already completed.  complete: Signals that this requirement is complete.  id: The id of whatever this requires. |
    | score | The number of points this achievement awards for completion. |
    | sort | A number indicating the order that this achievement should be sorted in. |
    | title | The ID of the title this achievement awards. |
    | watch | Signals that this achievement is being watched. |

# Inspect.Achievement.List

- Original source: inspect_achievement_list.html
- Category: Achievement
- Priority tier: Secondary
- Source index: Achievement_index.html

**Doc summary:** Returns a table of all known achievements.

Returns a table of all known achievements.

### Usage:

| --- | --- | --- | --- |
| *achievements* = Inspect.Achievement.List() | | | |
| Parameter | Type | Datatype | Description |
| *achievements* | result | *table* | All known achievements, in {id = true} format. |

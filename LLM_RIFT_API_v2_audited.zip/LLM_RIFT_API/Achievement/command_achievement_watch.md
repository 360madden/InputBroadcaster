# Command.Achievement.Watch

- Original source: command_achievement_watch.html
- Category: Achievement
- Priority tier: Secondary
- Source index: Achievement_index.html

**Doc summary:** Watches an achievement, possibly unwatching another item if the player is already watching the maximum item count. Permitted only on unfinished achievements.

Watches an achievement, possibly unwatching another item if the player is already watching the maximum item count. Permitted only on unfinished achievements.

### Usage:

| --- | --- | --- | --- |
| Command.Achievement.Watch(*achievement*, *flag*) | | | |
| Parameter | Type | Datatype | Description |
| *achievement* | parameter | *achievement* | The achievement to be affected. |
| *flag* | parameter | *boolean* | The new watch status. |

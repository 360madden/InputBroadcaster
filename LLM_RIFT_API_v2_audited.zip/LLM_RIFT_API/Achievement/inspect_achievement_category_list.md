# Inspect.Achievement.Category.List

- Original source: inspect_achievement_category_list.html
- Category: Achievement
- Priority tier: Secondary
- Source index: Achievement_index.html

**Doc summary:** Returns a table of valid achievement categories.

Returns a table of valid achievement categories.

### Usage:

| --- | --- | --- | --- |
| *categories* = Inspect.Achievement.Category.List() | | | |
| Parameter | Type | Datatype | Description |
| *categories* | result | *table* | Valid achievement categories, in {id = true} format. |

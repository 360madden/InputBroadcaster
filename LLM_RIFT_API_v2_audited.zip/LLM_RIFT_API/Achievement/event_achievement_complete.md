# Event.Achievement.Complete

- Original source: event_achievement_complete.html
- Category: Achievement
- Priority tier: Secondary
- Source index: Achievement_index.html

**Doc summary:** Signals an achievement completing.

Signals an achievement completing.

### Usage:

| --- | --- | --- | --- |
| Event.Achievement.Complete(*achievement*) | | | |
| Parameter | Type | Datatype | Description |
| *achievement* | parameter | *variant* | The ID of the achievement. |

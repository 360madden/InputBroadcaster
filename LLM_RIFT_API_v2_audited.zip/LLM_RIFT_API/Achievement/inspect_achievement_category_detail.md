# Inspect.Achievement.Category.Detail

- Original source: inspect_achievement_category_detail.html
- Category: Achievement
- Priority tier: Secondary
- Source index: Achievement_index.html

**Doc summary:** Returns information about achievement categories.

Returns information about achievement categories.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Achievement.Category.Detail(*category*) | | | |
| *details* = Inspect.Achievement.Category.Detail(*categories*) | | | |
| Parameter | Type | Datatype | Description |
| *categories* | parameter | *table* | A table of identifiers of achievement categories to retrieve detail for. |
| *category* | parameter | *achievementcategory* | The identifier of the achievement category to retrieve detail for. |
| *detail* | result | *table* | Detail table for a single achievement category. |
| *details* | result | *table* | Detail tables for all requested achievement categories. The key is the category ID, the value is the category's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | id | The ID of the requested element. |
    | name | The name of the achievement category. |
    | parent | The category's parent, if it has one. |

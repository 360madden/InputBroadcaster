# Event.Achievement.Update

- Original source: event_achievement_update.html
- Category: Achievement
- Priority tier: Secondary
- Source index: Achievement_index.html

**Doc summary:** Signals a change in an achievement's information.

Signals a change in an achievement's information.

### Usage:

| --- | --- | --- | --- |
| Event.Achievement.Update(*achievements*) | | | |
| Parameter | Type | Datatype | Description |
| *achievements* | parameter | *variant* | A table of the achievements, in {id = true} format. |

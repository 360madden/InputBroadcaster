# Achievement
**Priority:** Secondary
**Purpose:** Achievement and achievement-category inspection/events.
**Entry count:** 7
## Most important files first
- [Inspect.Achievement.Category.Detail](inspect_achievement_category_detail.md) — Returns information about achievement categories.
- [Inspect.Achievement.Detail](inspect_achievement_detail.md) — Provides detailed information about achievements.
- [Inspect.Achievement.Category.List](inspect_achievement_category_list.md) — Returns a table of valid achievement categories.
- [Inspect.Achievement.List](inspect_achievement_list.md) — Returns a table of all known achievements.
- [Event.Achievement.Update](event_achievement_update.md) — Signals a change in an achievement's information.
- [Command.Achievement.Watch](command_achievement_watch.md) — Watches an achievement, possibly unwatching another item if the player is already watching the ma...

## Full file list
- [Inspect.Achievement.Category.Detail](inspect_achievement_category_detail.md) — Returns information about achievement categories.
- [Inspect.Achievement.Detail](inspect_achievement_detail.md) — Provides detailed information about achievements.
- [Inspect.Achievement.Category.List](inspect_achievement_category_list.md) — Returns a table of valid achievement categories.
- [Inspect.Achievement.List](inspect_achievement_list.md) — Returns a table of all known achievements.
- [Event.Achievement.Update](event_achievement_update.md) — Signals a change in an achievement's information.
- [Command.Achievement.Watch](command_achievement_watch.md) — Watches an achievement, possibly unwatching another item if the player is already watching the ma...
- [Event.Achievement.Complete](event_achievement_complete.md) — Signals an achievement completing.

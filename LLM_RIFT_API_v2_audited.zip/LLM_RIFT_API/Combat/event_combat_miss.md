# Event.Combat.Miss

- Original source: event_combat_miss.html
- Category: Combat
- Priority tier: Secondary
- Source index: Combat_index.html

**Doc summary:** Signals an ability's effect missing a unit. All units referenced by this event will be accessible within this event's handlers.

Signals an ability's effect missing a unit. All units referenced by this event will be accessible within this event's handlers.

### Usage:

| --- | --- | --- | --- |
| Event.Combat.Miss(*info*) | | | |
| Parameter | Type | Datatype | Description |
| *info* | parameter | *variant* | Detailed information table about this event, containing several named parameters. |

**members**
:   |  |  |
    | --- | --- |
    | ability | The ability ID for the ability used, if available. |
    | abilityName | The name of the ability used. |
    | caster | The unit ID for this event's initiator, if one exists. |
    | casterName | The name of this event's initiator, if available. |
    | target | The unit ID for the target. |
    | targetName | The name of the target, if available. |

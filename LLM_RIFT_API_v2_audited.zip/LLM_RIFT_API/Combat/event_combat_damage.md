# Event.Combat.Damage

- Original source: event_combat_damage.html
- Category: Combat
- Priority tier: Secondary
- Source index: Combat_index.html

**Doc summary:** Signals damage done to a unit. All units referenced by this event will be accessible within this event's handlers.

Signals damage done to a unit. All units referenced by this event will be accessible within this event's handlers.

### Usage:

| --- | --- | --- | --- |
| Event.Combat.Damage(*info*) | | | |
| Parameter | Type | Datatype | Description |
| *info* | parameter | *variant* | Detailed information table about this event, containing several named parameters. |

**members**
:   |  |  |
    | --- | --- |
    | ability | The ability ID for the ability used, if available. |
    | abilityName | The name of the ability used. |
    | caster | The unit ID for this event's initiator, if one exists. |
    | casterName | The name of this event's initiator, if available. |
    | crit | Whether this was the result of a critical hit. |
    | damage | The amount of damage actually done. |
    | damageAbsorbed | The amount of damage absorbed. |
    | damageBlocked | The amount of damage blocked. |
    | damageIntercepted | The amount of damage intercepted. |
    | damageModified | The amount of damage modified. |
    | overkill | The amount of overkill done. |
    | target | The unit ID for the target. |
    | targetName | The name of the target, if available. |
    | type | The damage type. Values include "life", "death", "air", "earth", "fire", "water". |

# Event.Experience.Accumulated

- Original source: event_experience_accumulated.html
- Category: Experience
- Priority tier: Secondary
- Source index: Experience_index.html

**Doc summary:** Signals your accumulated experience changing.

Signals your accumulated experience changing.

### Usage:

| --- | --- | --- | --- |
| Event.Experience.Accumulated(*accumulated*) | | | |
| Parameter | Type | Datatype | Description |
| *accumulated* | parameter | *variant* | Total quantity of accumulated experience in this level. |

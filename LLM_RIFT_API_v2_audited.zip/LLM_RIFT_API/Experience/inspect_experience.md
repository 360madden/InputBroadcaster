# Inspect.Experience

- Original source: inspect_experience.html
- Category: Experience
- Priority tier: Secondary
- Source index: Experience_index.html

**Doc summary:** Returns information on your experience.

Returns information on your experience.

### Usage:

| --- | --- | --- | --- |
| *result* = Inspect.Experience() | | | |
| Parameter | Type | Datatype | Description |
| *result* | result | *table* | Table containing information on experience. |

**members**
:   |  |  |
    | --- | --- |
    | accumulated | Experience accumulated so far in this character level. |
    | needed | Quantity of experience needed to gain a level. |
    | rested | Quantity of available rested experience. |

# Event.Experience.Rested

- Original source: event_experience_rested.html
- Category: Experience
- Priority tier: Secondary
- Source index: Experience_index.html

**Doc summary:** Signals your available rested experience changing.

Signals your available rested experience changing.

### Usage:

| --- | --- | --- | --- |
| Event.Experience.Rested(*rested*) | | | |
| Parameter | Type | Datatype | Description |
| *rested* | parameter | *variant* | Quantity of available rested experience. |

# Experience
**Priority:** Secondary
**Purpose:** Experience inspection and events.
**Entry count:** 3
## Most important files first
- [Inspect.Experience](inspect_experience.md) — Returns information on your experience.
- [Event.Experience.Accumulated](event_experience_accumulated.md) — Signals your accumulated experience changing.
- [Event.Experience.Rested](event_experience_rested.md) — Signals your available rested experience changing.

## Full file list
- [Inspect.Experience](inspect_experience.md) — Returns information on your experience.
- [Event.Experience.Accumulated](event_experience_accumulated.md) — Signals your accumulated experience changing.
- [Event.Experience.Rested](event_experience_rested.md) — Signals your available rested experience changing.

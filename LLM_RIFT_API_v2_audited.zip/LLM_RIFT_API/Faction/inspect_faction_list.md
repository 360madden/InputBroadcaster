# Inspect.Faction.List

- Original source: inspect_faction_list.html
- Category: Faction
- Priority tier: Secondary
- Source index: Faction_index.html

**Doc summary:** Returns a table of all known factions.

Returns a table of all known factions.

### Usage:

| --- | --- | --- | --- |
| *factions* = Inspect.Faction.List() | | | |
| Parameter | Type | Datatype | Description |
| *factions* | result | *table* | All known factions, in {id = notoriety} format. |

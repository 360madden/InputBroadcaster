# Inspect.Faction.Detail

- Original source: inspect_faction_detail.html
- Category: Faction
- Priority tier: Secondary
- Source index: Faction_index.html

**Doc summary:** Provides detailed information about factions.

Provides detailed information about factions.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Faction.Detail(*faction*) | | | |
| *details* = Inspect.Faction.Detail(*factions*) | | | |
| Parameter | Type | Datatype | Description |
| *faction* | parameter | *faction* | The identifier of the faction to retrieve detail for. |
| *factions* | parameter | *table* | A table of identifiers of factions to retrieve detail for. |
| *detail* | result | *table* | Detail table for a single faction. |
| *details* | result | *table* | Detail tables for all requested factions. The key is the faction ID, the value is the faction's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | categoryName | Name of the faction's category. |
    | id | The ID of the requested element. |
    | name | The faction's name. |
    | notoriety | The current notoriety you have with this faction. |

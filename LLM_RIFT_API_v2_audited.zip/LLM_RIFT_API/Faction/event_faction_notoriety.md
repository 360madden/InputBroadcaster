# Event.Faction.Notoriety

- Original source: event_faction_notoriety.html
- Category: Faction
- Priority tier: Secondary
- Source index: Faction_index.html

**Doc summary:** Signals a change in the player's faction notoriety.

Signals a change in the player's faction notoriety.

### Usage:

| --- | --- | --- | --- |
| Event.Faction.Notoriety(*notoriety*) | | | |
| Parameter | Type | Datatype | Description |
| *notoriety* | parameter | *variant* | New notoriety values, in key/value form. |

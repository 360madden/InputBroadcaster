# Faction
**Priority:** Secondary
**Purpose:** Faction inspection and events.
**Entry count:** 3
## Most important files first
- [Inspect.Faction.Detail](inspect_faction_detail.md) — Provides detailed information about factions.
- [Inspect.Faction.List](inspect_faction_list.md) — Returns a table of all known factions.
- [Event.Faction.Notoriety](event_faction_notoriety.md) — Signals a change in the player's faction notoriety.

## Full file list
- [Inspect.Faction.Detail](inspect_faction_detail.md) — Provides detailed information about factions.
- [Inspect.Faction.List](inspect_faction_list.md) — Returns a table of all known factions.
- [Event.Faction.Notoriety](event_faction_notoriety.md) — Signals a change in the player's faction notoriety.

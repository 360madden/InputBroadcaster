# Mask:ClearWidth

- Original source: mask_clearwidth.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Clear a set width from this frame.

Clear a set width from this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:ClearWidth() | | | |

**noSecureFrameAndEnvironment**
:   true

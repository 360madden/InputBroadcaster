# Mask.Event:WheelForward

- Original source: mask_event_wheelforward.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mousewheel has been moved forward inside the frame. Blocks mousewheel events from frames below this one.

Signals that the mousewheel has been moved forward inside the frame. Blocks mousewheel events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:WheelForward() | | | |

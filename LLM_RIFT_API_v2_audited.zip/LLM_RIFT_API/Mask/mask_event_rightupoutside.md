# Mask.Event:RightUpoutside

- Original source: mask_event_rightupoutside.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mouse's right button has been released outside the frame, after a "Down" message. Blocks right mouse events and mouse movement events from frames below this one. May block left mouse events depending on the MouseMasking mode.

Signals that the mouse's right button has been released outside the frame, after a "Down" message. Blocks right mouse events and mouse movement events from frames below this one. May block left mouse events depending on the MouseMasking mode.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:RightUpoutside() | | | |

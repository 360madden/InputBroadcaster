# Mask:EventMacroGet

- Original source: mask_eventmacroget.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Gets the macro that will be triggered when this event occurs.

Gets the macro that will be triggered when this event occurs.

### Usage:

| --- | --- | --- | --- |
| *macro* = Layout:EventMacroGet(*handle*) | | | |
| Parameter | Type | Datatype | Description |
| *handle* | parameter | *eventFrame* | A handle to a frame event, usually pulled out of the "Event.UI." hierarchy. |
| *macro* | result | *string/nil* | The macro that will be triggered. |

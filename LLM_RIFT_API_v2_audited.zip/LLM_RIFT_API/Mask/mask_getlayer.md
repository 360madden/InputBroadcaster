# Mask:GetLayer

- Original source: mask_getlayer.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Gets the frame's layer order.

Gets the frame's layer order.

### Usage:

| --- | --- | --- | --- |
| *layer* = Frame:GetLayer() | | | |
| Parameter | Type | Datatype | Description |
| *layer* | result | *number* | The render layer of this frame. See Frame:SetLayer for details. |

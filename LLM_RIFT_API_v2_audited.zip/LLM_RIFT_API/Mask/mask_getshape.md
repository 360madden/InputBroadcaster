# Mask:GetShape

- Original source: mask_getshape.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Returns the current mask shape.

Returns the current mask shape.

### Usage:

| --- | --- | --- | --- |
| *shape* = Mask:GetShape() | | | |
| Parameter | Type | Datatype | Description |
| *shape* | result | *table* | The current shape. See Canvas:SetShape() for details. |

# Mask:ClearPoint

- Original source: mask_clearpoint.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Clear a set point from this frame.

Clear a set point from this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:ClearPoint(*coordinate*) | | | |
| Frame:ClearPoint(*x*, *y*) | | | |
| Parameter | Type | Datatype | Description |
| *coordinate* | parameter | *string* | Named coordinate. |
| *x* | parameter | *number/nil* | X coordinate of the point. |
| *y* | parameter | *number/nil* | Y coordinate of the point. |

**noSecureFrameAndEnvironment**
:   true

# Mask:GetWidth

- Original source: mask_getwidth.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Retrieves the width of this element.

Retrieves the width of this element.

### Usage:

| --- | --- | --- | --- |
| *width* = Layout:GetWidth() | | | |
| Parameter | Type | Datatype | Description |
| *width* | result | *number* | The width of this element. |

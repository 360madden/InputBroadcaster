# Mask.Event:KeyFocusLoss

- Original source: mask_event_keyfocusloss.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals losing key focus.

Signals losing key focus.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyFocusLoss() | | | |

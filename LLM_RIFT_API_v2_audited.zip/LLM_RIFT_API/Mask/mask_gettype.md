# Mask:GetType

- Original source: mask_gettype.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Retrieves the type of this element.

Retrieves the type of this element.

### Usage:

| --- | --- | --- | --- |
| *type* = Layout:GetType() | | | |
| Parameter | Type | Datatype | Description |
| *type* | result | *string* | The type of this element. |

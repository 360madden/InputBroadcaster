# Mask.Event:Mouse5Click

- Original source: mask_event_mouse5click.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mouse's fifth button has been clicked inside the frame. Blocks fifth button mouse events from frames below this one.

Signals that the mouse's fifth button has been clicked inside the frame. Blocks fifth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse5Click() | | | |

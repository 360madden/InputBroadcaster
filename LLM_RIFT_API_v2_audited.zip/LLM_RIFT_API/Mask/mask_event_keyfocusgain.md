# Mask.Event:KeyFocusGain

- Original source: mask_event_keyfocusgain.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals gaining key focus.

Signals gaining key focus.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyFocusGain() | | | |

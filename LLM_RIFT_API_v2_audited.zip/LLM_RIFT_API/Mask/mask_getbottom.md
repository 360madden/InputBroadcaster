# Mask:GetBottom

- Original source: mask_getbottom.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Retrieves the Y position of the bottom edge of this element.

Retrieves the Y position of the bottom edge of this element.

### Usage:

| --- | --- | --- | --- |
| *bottom* = Layout:GetBottom() | | | |
| Parameter | Type | Datatype | Description |
| *bottom* | result | *number* | The Y position of the bottom edge of this element. |

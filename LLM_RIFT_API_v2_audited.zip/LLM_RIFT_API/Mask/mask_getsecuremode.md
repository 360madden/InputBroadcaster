# Mask:GetSecureMode

- Original source: mask_getsecuremode.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Get the current secure mode. See SetSecureMode for details.

Get the current secure mode. See SetSecureMode for details.

### Usage:

| --- | --- | --- | --- |
| *secure* = Frame:GetSecureMode() | | | |
| Parameter | Type | Datatype | Description |
| *secure* | result | *string* | The current secure mode. |

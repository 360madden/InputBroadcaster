# Mask:GetParent

- Original source: mask_getparent.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Gets the parent of this frame.

Gets the parent of this frame.

### Usage:

| --- | --- | --- | --- |
| *parent* = Frame:GetParent() | | | |
| Parameter | Type | Datatype | Description |
| *parent* | result | *Element* | The parent element of this frame. |

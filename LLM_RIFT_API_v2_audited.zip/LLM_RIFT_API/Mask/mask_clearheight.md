# Mask:ClearHeight

- Original source: mask_clearheight.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Clear a set height from this frame.

Clear a set height from this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:ClearHeight() | | | |

**noSecureFrameAndEnvironment**
:   true

# Mask:EventAttach

- Original source: mask_eventattach.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Attaches an event handler to an event.

Attaches an event handler to an event.

### Usage:

| --- | --- | --- | --- |
| Layout:EventAttach(*handle*, *callback*, *label*) | | | |
| Layout:EventAttach(*handle*, *callback*, *label*, *priority*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *function* | A global event handler function. This will be called when the event fires. The first parameter will be the frame that the event is called on, the second parameter will be the standard frame event handle, any other parameters will follow that. |
| *handle* | parameter | *eventFrame* | A handle to a frame event, usually pulled out of the "Event.UI." hierarchy. |
| *label* | parameter | *string* | Human-readable label used to identify the handler in error reports, performance reports, and for later detaching. |
| *priority* | parameter | *number* | Priority of the event handler. Higher numbers trigger first. |

**noSecureFrameAndEnvironment**
:   true

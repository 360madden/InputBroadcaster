# Mask.Event:Mouse4Up

- Original source: mask_event_mouse4up.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mouse's fourth button has been released inside the frame. Blocks fourth button mouse events from frames below this one.

Signals that the mouse's fourth button has been released inside the frame. Blocks fourth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse4Up() | | | |

# Mask.Event:KeyDown

- Original source: mask_event_keydown.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals a key pressed.

Signals a key pressed.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyDown(*button*) | | | |
| Parameter | Type | Datatype | Description |
| *button* | parameter | *variant* | The key, in string form. |

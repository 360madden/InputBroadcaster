# Mask.Event:KeyType

- Original source: mask_event_keytype.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals text typed.

Signals text typed.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyType(*typed*) | | | |
| Parameter | Type | Datatype | Description |
| *typed* | parameter | *variant* | The text. |

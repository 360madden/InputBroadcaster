# Mask.Event:MiddleUpoutside

- Original source: mask_event_middleupoutside.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mouse's middle button has been released outside the frame, after a "Down" message. Blocks middle mouse events from frames below this one.

Signals that the mouse's middle button has been released outside the frame, after a "Down" message. Blocks middle mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:MiddleUpoutside() | | | |

# Mask.Event:RightDown

- Original source: mask_event_rightdown.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mouse's right button has been pressed inside the frame. Blocks right mouse events and mouse movement events from frames below this one. May block left mouse events depending on the MouseMasking mode.

Signals that the mouse's right button has been pressed inside the frame. Blocks right mouse events and mouse movement events from frames below this one. May block left mouse events depending on the MouseMasking mode.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:RightDown() | | | |

# Mask:GetVisible

- Original source: mask_getvisible.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Gets the visibility flag for this frame.

Gets the visibility flag for this frame.

### Usage:

| --- | --- | --- | --- |
| *visible* = Element:GetVisible() | | | |
| Parameter | Type | Datatype | Description |
| *visible* | result | *boolean* | This frame's visibility flag, as set by SetVisible. Does not check the visibility flags of the frame's parents. |

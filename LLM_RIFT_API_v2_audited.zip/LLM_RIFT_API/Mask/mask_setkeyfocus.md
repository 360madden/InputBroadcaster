# Mask:SetKeyFocus

- Original source: mask_setkeyfocus.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Sets the key focus status. Note that only one frame can be the key focus at a time. Focusing on another frame will automatically unset the current focus.

Sets the key focus status. Note that only one frame can be the key focus at a time. Focusing on another frame will automatically unset the current focus.

### Usage:

| --- | --- | --- | --- |
| Element:SetKeyFocus(*focus*) | | | |
| Parameter | Type | Datatype | Description |
| *focus* | parameter | *boolean* | The new key focus setting. |

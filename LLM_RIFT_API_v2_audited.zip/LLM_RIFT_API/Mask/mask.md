# Mask

- Original source: mask.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** A UI element of type Mask or derived from Mask.

A UI element of type Mask or derived from Mask.

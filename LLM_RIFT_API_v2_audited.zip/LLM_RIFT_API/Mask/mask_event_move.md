# Mask.Event:Move

- Original source: mask_event_move.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the frame's vertices have moved.

Signals that the frame's vertices have moved.

### Usage:

| --- | --- | --- | --- |
| Layout.Event:Move() | | | |

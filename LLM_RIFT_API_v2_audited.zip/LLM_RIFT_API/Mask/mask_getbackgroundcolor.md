# Mask:GetBackgroundColor

- Original source: mask_getbackgroundcolor.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Retrieves the background color of this frame.

Retrieves the background color of this frame.

### Usage:

| --- | --- | --- | --- |
| *r, g, b, a* = Element:GetBackgroundColor() | | | |
| Parameter | Type | Datatype | Description |
| *a* | result | *number* | Alpha. 1 is fully opaque, 0 is fully transparent. |
| *b* | result | *number* | Blue. |
| *g* | result | *number* | Green. |
| *r* | result | *number* | Red. |

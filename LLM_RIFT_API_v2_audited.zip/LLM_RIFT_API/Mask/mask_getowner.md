# Mask:GetOwner

- Original source: mask_getowner.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Retrieves the owner of this element.

Retrieves the owner of this element.

### Usage:

| --- | --- | --- | --- |
| *owner* = Layout:GetOwner() | | | |
| Parameter | Type | Datatype | Description |
| *owner* | result | *string* | The owner of this element. Given as an addon identifier. |

# Mask:ClearAll

- Original source: mask_clearall.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Clear all set points and sizes from this frame.

Clear all set points and sizes from this frame.

### Usage:

| --- | --- | --- | --- |
| Frame:ClearAll() | | | |

**noSecureFrameAndEnvironment**
:   true

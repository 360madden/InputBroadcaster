# Mask.Event:Strata

- Original source: mask_event_strata.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals a change in the item's strata.

Signals a change in the item's strata.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Strata() | | | |

# Mask:GetHeight

- Original source: mask_getheight.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Retrieves the height of this element.

Retrieves the height of this element.

### Usage:

| --- | --- | --- | --- |
| *height* = Layout:GetHeight() | | | |
| Parameter | Type | Datatype | Description |
| *height* | result | *number* | The height of this element. |

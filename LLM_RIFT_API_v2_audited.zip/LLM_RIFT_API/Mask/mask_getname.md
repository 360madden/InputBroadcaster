# Mask:GetName

- Original source: mask_getname.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Retrieves the name of this element.

Retrieves the name of this element.

### Usage:

| --- | --- | --- | --- |
| *name* = Layout:GetName() | | | |
| Parameter | Type | Datatype | Description |
| *name* | result | *string* | The name of this element, as provided by the addon that created it. |

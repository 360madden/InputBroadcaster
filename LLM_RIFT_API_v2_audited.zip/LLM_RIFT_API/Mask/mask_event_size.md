# Mask.Event:Size

- Original source: mask_event_size.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the frame's size has changed.

Signals that the frame's size has changed.

### Usage:

| --- | --- | --- | --- |
| Layout.Event:Size() | | | |

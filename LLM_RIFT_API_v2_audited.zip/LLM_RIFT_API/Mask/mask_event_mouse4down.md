# Mask.Event:Mouse4Down

- Original source: mask_event_mouse4down.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mouse's fourth button has been pressed inside the frame. Blocks fourth button mouse events from frames below this one.

Signals that the mouse's fourth button has been pressed inside the frame. Blocks fourth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse4Down() | | | |

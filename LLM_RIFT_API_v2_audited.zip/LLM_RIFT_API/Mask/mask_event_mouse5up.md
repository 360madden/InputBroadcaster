# Mask.Event:Mouse5Up

- Original source: mask_event_mouse5up.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mouse's fifth button has been released inside the frame. Blocks fifth button mouse events from frames below this one.

Signals that the mouse's fifth button has been released inside the frame. Blocks fifth button mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Mouse5Up() | | | |

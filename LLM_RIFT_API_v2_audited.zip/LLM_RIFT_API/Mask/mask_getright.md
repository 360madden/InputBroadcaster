# Mask:GetRight

- Original source: mask_getright.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Retrieves the X position of the right edge of this element.

Retrieves the X position of the right edge of this element.

### Usage:

| --- | --- | --- | --- |
| *right* = Layout:GetRight() | | | |
| Parameter | Type | Datatype | Description |
| *right* | result | *number* | The X position of the right edge of this element. |

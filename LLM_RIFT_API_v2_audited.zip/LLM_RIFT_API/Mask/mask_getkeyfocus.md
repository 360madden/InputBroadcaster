# Mask:GetKeyFocus

- Original source: mask_getkeyfocus.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Gets the key focus status.

Gets the key focus status.

### Usage:

| --- | --- | --- | --- |
| *focus* = Element:GetKeyFocus() | | | |
| Parameter | Type | Datatype | Description |
| *focus* | result | *boolean* | Whether this frame is the current key focus. |

# Mask:GetMouseMasking

- Original source: mask_getmousemasking.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Get the current mouse masking mode. See SetMouseMasking for details.

Get the current mouse masking mode. See SetMouseMasking for details.

### Usage:

| --- | --- | --- | --- |
| *mask* = Element:GetMouseMasking() | | | |
| Parameter | Type | Datatype | Description |
| *mask* | result | *string* | The current mouse masking mode. |

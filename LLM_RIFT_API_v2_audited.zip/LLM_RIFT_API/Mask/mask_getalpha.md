# Mask:GetAlpha

- Original source: mask_getalpha.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Gets the alpha multiplier of this frame.

Gets the alpha multiplier of this frame.

### Usage:

| --- | --- | --- | --- |
| *alpha* = Element:GetAlpha() | | | |
| Parameter | Type | Datatype | Description |
| *alpha* | result | *number* | The alpha multiplier of this frame. 1 is fully opaque, 0 is fully transparent. This does not include multiplied alphas from this frame's parent - it's the exact value passed to SetAlpha. |

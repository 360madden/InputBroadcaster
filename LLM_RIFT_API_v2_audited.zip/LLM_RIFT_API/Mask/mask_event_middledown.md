# Mask.Event:MiddleDown

- Original source: mask_event_middledown.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mouse's middle button has been pressed inside the frame. Blocks middle mouse events from frames below this one.

Signals that the mouse's middle button has been pressed inside the frame. Blocks middle mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:MiddleDown() | | | |

# Mask.Event:MiddleClick

- Original source: mask_event_middleclick.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mouse's middle button has been clicked inside the frame. Blocks middle mouse events from frames below this one.

Signals that the mouse's middle button has been clicked inside the frame. Blocks middle mouse events from frames below this one.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:MiddleClick() | | | |

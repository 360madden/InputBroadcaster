# Mask.Event:MouseMove

- Original source: mask_event_mousemove.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals that the mouse cursor has been moved within the frame. Blocks mouse movement events from frames below this one. May block left and right events depending on the MouseMasking mode.

Signals that the mouse cursor has been moved within the frame. Blocks mouse movement events from frames below this one. May block left and right events depending on the MouseMasking mode.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:MouseMove(*x*, *y*) | | | |
| Parameter | Type | Datatype | Description |
| *x* | parameter | *variant* | X coordinate. |
| *y* | parameter | *<nope>* | Y coordinate. |

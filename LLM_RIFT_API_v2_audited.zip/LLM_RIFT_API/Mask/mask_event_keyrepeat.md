# Mask.Event:KeyRepeat

- Original source: mask_event_keyrepeat.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Frame.Event:KeyRepeat@summary

Frame.Event:KeyRepeat@summary

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyRepeat(*button*) | | | |
| Parameter | Type | Datatype | Description |
| *button* | parameter | *variant* | The key, in string form. |

# Mask.Event:Layer

- Original source: mask_event_layer.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals a change in the item's layer.

Signals a change in the item's layer.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:Layer() | | | |

# Mask:SetAllPoints

- Original source: mask_setallpoints.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Pins all the edges of this frame to the edges of a different frame. If no target is given, defaults to this frame's parent.

Pins all the edges of this frame to the edges of a different frame. If no target is given, defaults to this frame's parent.

### Usage:

| --- | --- | --- | --- |
| Frame:SetAllPoints() | | | |
| Frame:SetAllPoints(*target*) | | | |
| Parameter | Type | Datatype | Description |
| *target* | parameter | *Layout* | Target Layout to pin this frame's edges to. |

**noSecureFrameAndEnvironment**
:   true

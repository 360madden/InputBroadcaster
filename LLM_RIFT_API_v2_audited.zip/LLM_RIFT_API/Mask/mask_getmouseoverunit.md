# Mask:GetMouseoverUnit

- Original source: mask_getmouseoverunit.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Gets the unit that is being represented by this frame.

Gets the unit that is being represented by this frame.

### Usage:

| --- | --- | --- | --- |
| *unit* = Frame:GetMouseoverUnit() | | | |
| Parameter | Type | Datatype | Description |
| *unit* | result | *string* | The current mouseover unit. May be nil if there is no mouseover unit. |

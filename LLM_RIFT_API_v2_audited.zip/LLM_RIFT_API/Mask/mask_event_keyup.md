# Mask.Event:KeyUp

- Original source: mask_event_keyup.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Signals a key released.

Signals a key released.

### Usage:

| --- | --- | --- | --- |
| Frame.Event:KeyUp(*button*) | | | |
| Parameter | Type | Datatype | Description |
| *button* | parameter | *variant* | The key, in string form. |

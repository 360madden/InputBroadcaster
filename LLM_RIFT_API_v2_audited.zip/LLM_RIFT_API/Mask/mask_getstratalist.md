# Mask:GetStrataList

- Original source: mask_getstratalist.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Gets a list of valid stratas for this frame.

Gets a list of valid stratas for this frame.

### Usage:

| --- | --- | --- | --- |
| *stratas* = Frame:GetStrataList() | | | |
| Parameter | Type | Datatype | Description |
| *stratas* | result | *table* | An array of valid stratas, in order. |

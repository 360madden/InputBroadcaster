# Mask:GetChildren

- Original source: mask_getchildren.html
- Category: Mask
- Priority tier: Core
- Source index: Mask_index.html

**Doc summary:** Returns a table containing all of this element's children.

Returns a table containing all of this element's children.

### Usage:

| --- | --- | --- | --- |
| *children* = Element:GetChildren() | | | |
| Parameter | Type | Datatype | Description |
| *children* | result | *table* | A table containing this element's children. |

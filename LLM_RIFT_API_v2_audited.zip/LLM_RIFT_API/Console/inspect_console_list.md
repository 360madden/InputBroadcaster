# Inspect.Console.List

- Original source: inspect_console_list.html
- Category: Console
- Priority tier: Core
- Source index: Console_index.html

**Doc summary:** Returns a table of the current open text consoles.

Returns a table of the current open text consoles.

### Usage:

| --- | --- | --- | --- |
| *consoles* = Inspect.Console.List() | | | |
| Parameter | Type | Datatype | Description |
| *consoles* | result | *table* | A table containing the IDs of the available consoles. |

# Console
**Priority:** Secondary
**Purpose:** Console-specific debug and display APIs.
**Entry count:** 3
**LLM note:** Useful for debug output, but not a core starting point for addon architecture.
## Most important files first
- [Command.Console.Display](command_console_display.md) — Prints a line of text in a console window of your choice. Note that the line length is limited, i...
- [Inspect.Console.List](inspect_console_list.md) — Returns a table of the current open text consoles.
- [Inspect.Console.Detail](inspect_console_detail.md) — Provides detailed information about consoles.

## Full file list
- [Inspect.Console.Detail](inspect_console_detail.md) — Provides detailed information about consoles.
- [Inspect.Console.List](inspect_console_list.md) — Returns a table of the current open text consoles.
- [Command.Console.Display](command_console_display.md) — Prints a line of text in a console window of your choice. Note that the line length is limited, i...
# Inspect.Console.Detail

- Original source: inspect_console_detail.html
- Category: Console
- Priority tier: Core
- Source index: Console_index.html

**Doc summary:** Provides detailed information about consoles.

Provides detailed information about consoles.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Console.Detail(*console*) | | | |
| *details* = Inspect.Console.Detail(*consoles*) | | | |
| Parameter | Type | Datatype | Description |
| *console* | parameter | *console* | The identifier of the console to retrieve information for. May also be "general" or "combat". |
| *consoles* | parameter | *table* | A table of consoles to retrieve detail for. |
| *detail* | result | *table* | Detail table for a single console. |
| *details* | result | *table* | Detail tables for all requested consoles. |

**members**
:   |  |  |
    | --- | --- |
    | accolade | Indicates that this console displays Accolade messages. |
    | achievement | Indicates that this console displays Achievement messages. |
    | channel | May contain a table of public channels that this console will display. nil if the console does not display any public channels. |
    | combatBad | Indicates that this console displays Combat Bad messages. |
    | combatGood | Indicates that this console displays Combat Good messages. |
    | combatNeutral | Indicates that this console displays Combat Neutral messages. |
    | combatOther | Indicates that this console displays Combat Other messages. |
    | combatSpecial | Indicates that this console displays Combat Special messages. |
    | craftingOther | Indicates that this console displays Crafting Others messages. |
    | craftingSelf | Indicates that this console displays Crafting Self messages. |
    | emote | Indicates that this console displays Emote messages. |
    | experience | Indicates that this console displays Experience messages. |
    | guild | Indicates that this console displays Guild messages. |
    | id | The ID of the requested element. |
    | lootGroup | Indicates that this console displays Group Loot messages. |
    | lootItem | Indicates that this console displays Item Loot messages. |
    | lootMoney | Indicates that this console displays Money Loot messages. |
    | name | The player-chosen name of the console. |
    | notoriety | Indicates that this console displays Notoriety messages. |
    | npc | Indicates that this console displays NPC messages. |
    | officer | Indicates that this console displays Officer messages. |
    | party | Indicates that this console displays Party messages. |
    | purchase | Indicates that this console displays Purchase messages. |
    | raid | Indicates that this console displays Raid messages. |
    | raidWarning | Indicates that this console displays Raid Warning messages. |
    | say | Indicates that this console displays Say messages. |
    | skill | Indicates that this console displays Skill messages. |
    | system | Indicates that this console displays System messages. |
    | tell | Indicates that this console displays Tell messages. |
    | yell | Indicates that this console displays Yell messages. |

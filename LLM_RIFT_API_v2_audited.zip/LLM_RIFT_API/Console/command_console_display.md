# Command.Console.Display

- Original source: command_console_display.html
- Category: Console
- Priority tier: Core
- Source index: Console_index.html

**Doc summary:** Prints a line of text in a console window of your choice. Note that the line length is limited, including HTML tags.

Prints a line of text in a console window of your choice. Note that the line length is limited, including HTML tags.

### Usage:

| --- | --- | --- | --- |
| Command.Console.Display(*console*, *suppressPrefix*, *text*, *html*) | | | |
| Parameter | Type | Datatype | Description |
| *console* | parameter | *console* | The console to display text into. May be "general", "combat", or a console ID. |
| *html* | parameter | *boolean* | Enables HTML mode. In HTML mode, a limited number of formatting tags are available: <u>, <font color="#rrggbb">, and <a lua="print('This is a lua script.')">. |
| *suppressPrefix* | parameter | *boolean* | Suppress the automatic addon shortname prefix. |
| *text* | parameter | *string* | The text to be printed. |

# Event.Dimension.Layout.Remove

- Original source: event_dimension_layout_remove.html
- Category: Dimension
- Priority tier: Secondary
- Source index: Dimension_index.html

**Doc summary:** Signals that a dimension item has been removed.

Signals that a dimension item has been removed.

### Usage:

| --- | --- | --- | --- |
| Event.Dimension.Layout.Remove(*removedItem*) | | | |
| Parameter | Type | Datatype | Description |
| *removedItem* | parameter | *variant* | The dimension item that has been removed. |

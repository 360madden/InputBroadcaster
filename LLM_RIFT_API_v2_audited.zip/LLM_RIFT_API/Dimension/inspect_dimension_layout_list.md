# Inspect.Dimension.Layout.List

- Original source: inspect_dimension_layout_list.html
- Category: Dimension
- Priority tier: Secondary
- Source index: Dimension_index.html

**Doc summary:** Returns a list of dimension items in the dimension you're currently in, and whether or not they are crated.

Returns a list of dimension items in the dimension you're currently in, and whether or not they are crated.

### Usage:

| --- | --- | --- | --- |
| *list* = Inspect.Dimension.Layout.List() | | | |
| Parameter | Type | Datatype | Description |
| *list* | result | *table* | The list of detail results. |

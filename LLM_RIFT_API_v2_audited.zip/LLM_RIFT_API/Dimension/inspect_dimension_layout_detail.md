# Inspect.Dimension.Layout.Detail

- Original source: inspect_dimension_layout_detail.html
- Category: Dimension
- Priority tier: Secondary
- Source index: Dimension_index.html

**Doc summary:** Returns details about the specified dimension item.

Returns details about the specified dimension item.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Dimension.Layout.Detail(*dimensionitem*) | | | |
| *details* = Inspect.Dimension.Layout.Detail(*dimensionitems*) | | | |
| Parameter | Type | Datatype | Description |
| *dimensionitem* | parameter | *dimensionitem* | The identifier of the dimension item to retrieve detail for. |
| *dimensionitems* | parameter | *table* | A table of identifiers of dimension items to retrieve detail for. |
| *detail* | result | *table* | Table of details about the dimension item specified. |
| *details* | result | *table* | Detail table for all requsted dimension items. The key is the dimension item ID, the value is the dimension item's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | coordX | The X coordinate of the item. |
    | coordY | The Y coordinate of the item. |
    | coordZ | The Z coordinate of the item. |
    | crated | Indicates that the item is crated. |
    | icon | Resource filename of the item's icon. |
    | id | The item's id. |
    | name | The name of the item. |
    | pitch | The pitch of the item. |
    | roll | The roll of the item. |
    | scale | The scale of the item. |
    | selected | Indicates that the item is selected. |
    | type | The type of the item. |
    | yaw | The yaw of the item. |

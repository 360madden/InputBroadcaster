# Command.Dimension.Layout.Pickup

- Original source: command_dimension_layout_pickup.html
- Category: Dimension
- Priority tier: Secondary
- Source index: Dimension_index.html

**Doc summary:** Pick up the specified dimension item from the world to your inventory.

Pick up the specified dimension item from the world to your inventory.

### Usage:

| --- | --- | --- | --- |
| Command.Dimension.Layout.Pickup(*dimensionItem*) | | | |
| Parameter | Type | Datatype | Description |
| *dimensionItem* | parameter | *dimensionitem* | The ID of the dimension item to operate on. |

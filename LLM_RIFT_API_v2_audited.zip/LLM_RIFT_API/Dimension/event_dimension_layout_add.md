# Event.Dimension.Layout.Add

- Original source: event_dimension_layout_add.html
- Category: Dimension
- Priority tier: Secondary
- Source index: Dimension_index.html

**Doc summary:** Signals that a dimension item has been added.

Signals that a dimension item has been added.

### Usage:

| --- | --- | --- | --- |
| Event.Dimension.Layout.Add(*addedItem*) | | | |
| Parameter | Type | Datatype | Description |
| *addedItem* | parameter | *variant* | The dimension item that has been added. |

# Command.Dimension.Layout.Select

- Original source: command_dimension_layout_select.html
- Category: Dimension
- Priority tier: Secondary
- Source index: Dimension_index.html

**Doc summary:** Selects or deselects the specified dimension item.

Selects or deselects the specified dimension item.

### Usage:

| --- | --- | --- | --- |
| Command.Dimension.Layout.Select(*dimensionItem*, *selected*) | | | |
| Parameter | Type | Datatype | Description |
| *dimensionItem* | parameter | *dimensionitem* | The ID of the dimension item to operate on. |
| *selected* | parameter | *boolean* | Indicates if the dimension item should be selected or deselected. |

# Dimension
**Priority:** Secondary
**Purpose:** Dimension inspection and dimension events.
**Entry count:** 8
## Most important files first
- [Inspect.Dimension.Layout.Detail](inspect_dimension_layout_detail.md) — Returns details about the specified dimension item.
- [Inspect.Dimension.Layout.List](inspect_dimension_layout_list.md) — Returns a list of dimension items in the dimension you're currently in, and whether or not they a...
- [Event.Dimension.Layout.Update](event_dimension_layout_update.md) — Signals that a dimension item has been updated.
- [Command.Dimension.Layout.Pickup](command_dimension_layout_pickup.md) — Pick up the specified dimension item from the world to your inventory.
- [Command.Dimension.Layout.Place](command_dimension_layout_place.md) — Places the item (dimension or inventory) in your current dimension and modifies the details speci...
- [Command.Dimension.Layout.Select](command_dimension_layout_select.md) — Selects or deselects the specified dimension item.

## Full file list
- [Inspect.Dimension.Layout.Detail](inspect_dimension_layout_detail.md) — Returns details about the specified dimension item.
- [Inspect.Dimension.Layout.List](inspect_dimension_layout_list.md) — Returns a list of dimension items in the dimension you're currently in, and whether or not they a...
- [Event.Dimension.Layout.Update](event_dimension_layout_update.md) — Signals that a dimension item has been updated.
- [Command.Dimension.Layout.Pickup](command_dimension_layout_pickup.md) — Pick up the specified dimension item from the world to your inventory.
- [Command.Dimension.Layout.Place](command_dimension_layout_place.md) — Places the item (dimension or inventory) in your current dimension and modifies the details speci...
- [Command.Dimension.Layout.Select](command_dimension_layout_select.md) — Selects or deselects the specified dimension item.
- [Event.Dimension.Layout.Add](event_dimension_layout_add.md) — Signals that a dimension item has been added.
- [Event.Dimension.Layout.Remove](event_dimension_layout_remove.md) — Signals that a dimension item has been removed.

# Event.Dimension.Layout.Update

- Original source: event_dimension_layout_update.html
- Category: Dimension
- Priority tier: Secondary
- Source index: Dimension_index.html

**Doc summary:** Signals that a dimension item has been updated.

Signals that a dimension item has been updated.

### Usage:

| --- | --- | --- | --- |
| Event.Dimension.Layout.Update(*updatedItem*) | | | |
| Parameter | Type | Datatype | Description |
| *updatedItem* | parameter | *variant* | The dimension item that has been updated. |

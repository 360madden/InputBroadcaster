# Command.Dimension.Layout.Place

- Original source: command_dimension_layout_place.html
- Category: Dimension
- Priority tier: Secondary
- Source index: Dimension_index.html

**Doc summary:** Places the item (dimension or inventory) in your current dimension and modifies the details specified by the values parameter.

Places the item (dimension or inventory) in your current dimension and modifies the details specified by the values parameter.

### Usage:

| --- | --- | --- | --- |
| Command.Dimension.Layout.Place(*item*, *values*) | | | |
| Command.Dimension.Layout.Place(*dimensionItem*, *values*) | | | |
| Parameter | Type | Datatype | Description |
| *dimensionItem* | parameter | *dimensionitem* | The ID of the dimension item to operate on. |
| *item* | parameter | *item* | The inventory item to operate on. |
| *values* | parameter | *table* | Table containing data to set on the dimension item. All parameters are optional and will default to current or default values.  coordX: The X coordinate of the item.  coordY: The Y coordinate of the item.  coordZ: The Z coordinate of the item.  pitch: The pitch rotation of the item.  roll: The roll rotation of the item.  scale: The scale of the item.  yaw: The yaw rotation of the item. |

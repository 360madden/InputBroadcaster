# Event.Guild.Roster.Detail.Rank

- Original source: event_guild_roster_detail_rank.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a change in a guildmember's rank.

Signals a change in a guildmember's rank.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Roster.Detail.Rank(*units*) | | | |
| Parameter | Type | Datatype | Description |
| *units* | parameter | *variant* | Table of the units changed. Key is the unit ID, value is the new value. |

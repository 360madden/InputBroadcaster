# Event.Guild.Log

- Original source: event_guild_log.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals incoming guild log data. Can be triggered manually with Command.Guild.Log.Request().

Signals incoming guild log data. Can be triggered manually with Command.Guild.Log.Request().

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Log(*log*) | | | |
| Parameter | Type | Datatype | Description |
| *log* | parameter | *variant* | An array containing the refreshed guild log items, in order. |

**members**
:   |  |  |
    | --- | --- |
    | achievement | The achievement involved. |
    | coin | The amount of silver involved. |
    | count | The number of items involved. |
    | item | The item type involved. |
    | level | The level involved. |
    | rank | The rank involved. |
    | source | The source of the log event. |
    | target | The target of the log event. |
    | type | The type of the log message. May be any of achievement, bankCoinDeposit, bankCoinHeal, bankCoinTithe, bankCoinWithdraw, bankItemDeposit, bankItemWithdraw, bankVault, charterSign, charterUnsign, demote, demoteTrial, dimensionBuy, finder, firstAchievement, firstCollection, firstItem, firstKill, firstQuest, form, found, invite, kick, leave, level, motd, promote, rankEdit, rename, transferred, unlearnActive, unlearnPassive, wallDelete, wallModify, xp, or xpQuest. |
    | xp | The amount of XP involved. |

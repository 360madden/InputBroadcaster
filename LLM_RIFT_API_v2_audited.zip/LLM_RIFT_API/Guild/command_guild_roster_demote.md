# Command.Guild.Roster.Demote

- Original source: command_guild_roster_demote.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Demotes a guildmember by one rank.

Demotes a guildmember by one rank.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Roster.Demote(*member*) | | | |
| Command.Guild.Roster.Demote(*member*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *member* | parameter | *string* | The guildmember to target. |

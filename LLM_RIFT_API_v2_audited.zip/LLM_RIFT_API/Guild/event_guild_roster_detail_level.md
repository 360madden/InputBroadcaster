# Event.Guild.Roster.Detail.Level

- Original source: event_guild_roster_detail_level.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a change in a guildmember's level.

Signals a change in a guildmember's level.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Roster.Detail.Level(*units*) | | | |
| Parameter | Type | Datatype | Description |
| *units* | parameter | *variant* | Table of the units changed. Key is the unit ID, value is the new value. |

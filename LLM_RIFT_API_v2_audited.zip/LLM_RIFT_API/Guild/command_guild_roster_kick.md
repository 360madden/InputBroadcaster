# Command.Guild.Roster.Kick

- Original source: command_guild_roster_kick.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Kicks a guildmember from the guild.

Kicks a guildmember from the guild.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Roster.Kick(*member*) | | | |
| Command.Guild.Roster.Kick(*member*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *member* | parameter | *string* | The guildmember to target. |

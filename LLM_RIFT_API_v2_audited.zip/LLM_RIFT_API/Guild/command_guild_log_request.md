# Command.Guild.Log.Request

- Original source: command_guild_log_request.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Requests a guild log event.

Requests a guild log event.

### Usage:

| --- | --- | --- | --- |
| Command.Guild.Log.Request() | | | |
| Command.Guild.Log.Request(*callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |

**throttleBulk**
:   true

# Event.Guild.Bank.Change

- Original source: event_guild_bank_change.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a change in a guild bank vault's information.

Signals a change in a guild bank vault's information.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Bank.Change(*vaults*) | | | |
| Parameter | Type | Datatype | Description |
| *vaults* | parameter | *variant* | A lookup table of vaults that have changed. |

# Event.Guild.Roster.Detail.Zone

- Original source: event_guild_roster_detail_zone.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a change in a guildmember's zone.

Signals a change in a guildmember's zone.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Roster.Detail.Zone(*units*) | | | |
| Parameter | Type | Datatype | Description |
| *units* | parameter | *variant* | Table of the units changed. Key is the unit ID, value is the new value. |

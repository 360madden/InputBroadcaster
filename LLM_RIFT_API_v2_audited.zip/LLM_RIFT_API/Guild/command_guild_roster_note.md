# Command.Guild.Roster.Note

- Original source: command_guild_roster_note.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Changes your guild note.

Changes your guild note.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Roster.Note(*note*) | | | |
| Command.Guild.Roster.Note(*note*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *note* | parameter | *string* | The new note. |

# Event.Guild.Roster.Add

- Original source: event_guild_roster_add.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a new player added to the guild roster.

Signals a new player added to the guild roster.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Roster.Add(*add*) | | | |
| Parameter | Type | Datatype | Description |
| *add* | parameter | *variant* | The name of the added guildmember. |

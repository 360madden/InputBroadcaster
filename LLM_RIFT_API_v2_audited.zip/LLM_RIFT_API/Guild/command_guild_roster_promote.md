# Command.Guild.Roster.Promote

- Original source: command_guild_roster_promote.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Promotes a guildmember by one rank.

Promotes a guildmember by one rank.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Roster.Promote(*member*) | | | |
| Command.Guild.Roster.Promote(*member*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *member* | parameter | *string* | The guildmember to target. |

# Command.Guild.Bank.Purchase

- Original source: command_guild_bank_purchase.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Purchases a new guild bank vault.

Purchases a new guild bank vault.

### Usage:

Interaction category: guildbank

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Bank.Purchase() | | | |
| Command.Guild.Bank.Purchase(*callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |

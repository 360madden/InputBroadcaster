# Event.Guild.Roster.Remove

- Original source: event_guild_roster_remove.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a player removed from the guild roster.

Signals a player removed from the guild roster.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Roster.Remove(*remove*) | | | |
| Parameter | Type | Datatype | Description |
| *remove* | parameter | *variant* | The name of the removed guildmember. |

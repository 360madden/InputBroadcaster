# Event.Guild.Roster.Detail.NoteOfficer

- Original source: event_guild_roster_detail_noteofficer.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a change in a guildmember's officer note.

Signals a change in a guildmember's officer note.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Roster.Detail.NoteOfficer(*units*) | | | |
| Parameter | Type | Datatype | Description |
| *units* | parameter | *variant* | Table of the units changed. Key is the unit ID, value is the new value. |

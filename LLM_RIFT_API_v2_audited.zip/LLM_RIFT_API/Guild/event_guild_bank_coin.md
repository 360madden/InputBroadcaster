# Event.Guild.Bank.Coin

- Original source: event_guild_bank_coin.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a change in the guild bank's money.

Signals a change in the guild bank's money.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Bank.Coin(*coin*) | | | |
| Parameter | Type | Datatype | Description |
| *coin* | parameter | *variant* | The new amount of money in the guild bank. |

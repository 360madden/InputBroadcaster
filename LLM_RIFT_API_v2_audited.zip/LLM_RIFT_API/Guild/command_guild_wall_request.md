# Command.Guild.Wall.Request

- Original source: command_guild_wall_request.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Requests a guild wall event.

Requests a guild wall event.

### Usage:

| --- | --- | --- | --- |
| Command.Guild.Wall.Request() | | | |
| Command.Guild.Wall.Request(*callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |

**throttleBulk**
:   true

# Event.Guild.Roster.Detail.Note

- Original source: event_guild_roster_detail_note.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a change in a guildmember's note.

Signals a change in a guildmember's note.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Roster.Detail.Note(*units*) | | | |
| Parameter | Type | Datatype | Description |
| *units* | parameter | *variant* | Table of the units changed. Key is the unit ID, value is the new value. |

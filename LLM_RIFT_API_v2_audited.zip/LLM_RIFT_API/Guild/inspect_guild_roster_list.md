# Inspect.Guild.Roster.List

- Original source: inspect_guild_roster_list.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Lists guildmembers.

Lists guildmembers.

### Usage:

| --- | --- | --- | --- |
| *list* = Inspect.Guild.Roster.List() | | | |
| Parameter | Type | Datatype | Description |
| *list* | result | *table* | A table listing all your guildmembers. The key is the guildmember's name, the value is the guildmember's status. |

# Inspect.Guild.Roster.Detail

- Original source: inspect_guild_roster_detail.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Provides detailed information about guildmembers.

Provides detailed information about guildmembers.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Guild.Roster.Detail(*guildmember*) | | | |
| *details* = Inspect.Guild.Roster.Detail(*guildmembers*) | | | |
| Parameter | Type | Datatype | Description |
| *guildmember* | parameter | *string* | The name of the guildmember to retrieve data for. |
| *guildmembers* | parameter | *table* | A table of names of guildmembers to retrieve data for. |
| *detail* | result | *table* | Detail table for a single guildmember. |
| *details* | result | *table* | Detail tables for all requested guildmembers. The key is the guildmember's name, the value is the guildmember's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | id | The ID of the requested element. |
    | level | The guildmember's level. |
    | logout | The guildmember's last logout time, in UNIX time. |
    | name | The guildmember's name. |
    | note | The guildmember's public note. |
    | noteOfficer | The guildmember's officer note. |
    | rank | The guildmember's rank. |
    | score | The guildmember's achievement score. |
    | status | The guildmember's current status. May include "online" or "mobile". nil if the guildmember is offline. |
    | zone | The guildmember's current zone, if online. |

# Inspect.Guild.Rank.List

- Original source: inspect_guild_rank_list.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Lists available guild ranks.

Lists available guild ranks.

### Usage:

| --- | --- | --- | --- |
| *list* = Inspect.Guild.Rank.List() | | | |
| Parameter | Type | Datatype | Description |
| *list* | result | *table* | A table of the IDs of the available ranks. The value is the rank's name. |

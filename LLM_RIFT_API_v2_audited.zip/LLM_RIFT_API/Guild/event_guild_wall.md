# Event.Guild.Wall

- Original source: event_guild_wall.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals incoming guild wall data. Can be triggered manually with Command.Guild.Wall.Request().

Signals incoming guild wall data. Can be triggered manually with Command.Guild.Wall.Request().

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Wall(*wall*) | | | |
| Parameter | Type | Datatype | Description |
| *wall* | parameter | *variant* | An array containing the refreshed guild wall items, in order. |

**members**
:   |  |  |
    | --- | --- |
    | id | The ID of the guild wall entry. |
    | poster | The poster of the guild wall entry. |
    | text | The text of the guild wall entry. |
    | time | The time the wall entry was posted, in UNIX time. |

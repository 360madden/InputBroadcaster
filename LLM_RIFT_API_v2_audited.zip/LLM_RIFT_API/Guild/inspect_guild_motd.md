# Inspect.Guild.Motd

- Original source: inspect_guild_motd.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Returns the current guild Message of the Day.

Returns the current guild Message of the Day.

### Usage:

| --- | --- | --- | --- |
| *motd* = Inspect.Guild.Motd() | | | |
| Parameter | Type | Datatype | Description |
| *motd* | result | *string* | The current Message of the Day. |

# Inspect.Guild.Bank.Detail

- Original source: inspect_guild_bank_detail.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Provides detailed information about guild bank vaults.

Provides detailed information about guild bank vaults.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Guild.Bank.Detail(*guildvault*) | | | |
| *details* = Inspect.Guild.Bank.Detail(*guildvaults*) | | | |
| Parameter | Type | Datatype | Description |
| *guildvault* | parameter | *slot* | A slot specifier representing the entire guild bank vault to retrieve information for. |
| *guildvaults* | parameter | *table* | A table of slot specifiers, each representing an entire guild bank vault, to retrieve information for. |
| *detail* | result | *table* | Detail table for a guild bank vault. |
| *details* | result | *table* | Detail tables for all requested guild bank vault. The key is the vault specifier, the value is the vault's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | id | The ID of the requested element. |
    | name | The name of the vault. |

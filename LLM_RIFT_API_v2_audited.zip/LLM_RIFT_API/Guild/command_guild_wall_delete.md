# Command.Guild.Wall.Delete

- Original source: command_guild_wall_delete.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Deletes an entry from the guild wall.

Deletes an entry from the guild wall.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Wall.Delete(*wall*) | | | |
| Command.Guild.Wall.Delete(*wall*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *wall* | parameter | *guildwall* | The ID of the target wall post. |

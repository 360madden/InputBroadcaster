# Command.Guild.Bank.Withdraw

- Original source: command_guild_bank_withdraw.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Withdraws money from the guild bank.

Withdraws money from the guild bank.

### Usage:

Interaction category: guildbank

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Bank.Withdraw(*coin*) | | | |
| Command.Guild.Bank.Withdraw(*coin*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *coin* | parameter | *number* | The string "coin", used as a value to request the player's money. |

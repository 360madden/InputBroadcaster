# Event.Guild.Roster.Detail.Status

- Original source: event_guild_roster_detail_status.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a change in a guildmember's status.

Signals a change in a guildmember's status.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Roster.Detail.Status(*units*) | | | |
| Parameter | Type | Datatype | Description |
| *units* | parameter | *variant* | Table of the units changed. Key is the unit ID, value is the new value, or "false" in place of nil. |

# Inspect.Guild.Bank.List

- Original source: inspect_guild_bank_list.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Returns a table of all available guild bank vaults.

Returns a table of all available guild bank vaults.

### Usage:

| --- | --- | --- | --- |
| *list* = Inspect.Guild.Bank.List() | | | |
| Parameter | Type | Datatype | Description |
| *list* | result | *table* | All available guild vaults, in {id = name} format. |

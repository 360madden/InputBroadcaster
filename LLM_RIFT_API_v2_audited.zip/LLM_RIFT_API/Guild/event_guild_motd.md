# Event.Guild.Motd

- Original source: event_guild_motd.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a change in the guild Message of the Day.

Signals a change in the guild Message of the Day.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Motd(*motd*) | | | |
| Parameter | Type | Datatype | Description |
| *motd* | parameter | *variant* | The new Message of the Day. |

# Inspect.Guild.Rank.Detail

- Original source: inspect_guild_rank_detail.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Provides detailed information about guild ranks.

Provides detailed information about guild ranks.

### Usage:

| --- | --- | --- | --- |
| *detail* = Inspect.Guild.Rank.Detail(*guildrank*) | | | |
| *details* = Inspect.Guild.Rank.Detail(*guildranks*) | | | |
| Parameter | Type | Datatype | Description |
| *guildrank* | parameter | *guildrank* | The identifier of the rank to retrieve detail for. |
| *guildranks* | parameter | *table* | A table of identifiers of ranks to retrieve detail for. |
| *detail* | result | *table* | Detail table for a single rank. |
| *details* | result | *table* | Detail table for all requested ranks. The key is the rank ID, the value is the rank's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | addonStorageDelete | Signals that this rank has permission to modify or delete addon storage elements. |
    | addonStorageWrite | Signals that this rank has permission to non-destructively write addon storage elements. |
    | demote | Signals that this rank has permission to demote guildmembers. |
    | finderEdit | Signals that this rank has permission to edit the Guild Finder settings. |
    | finderReceive | Signals that this rank has permission to receive Guild Finder messages. |
    | id | The ID of the requested element. |
    | invite | Signals that this rank has permission to invite new guildmembers. |
    | kick | Signals that this rank has permission to kick guildmembers. |
    | listen | Signals that this rank has permission to listen to guild chat. |
    | motd | Signals that this rank has permission to change the guild Message of the Day. |
    | name | The name of this rank. |
    | noteOfficer | Signals that this rank has permission to view and edit Officer Notes. |
    | officer | Signals that this rank has permission to listen to and speak in officer chat. |
    | perk | Signals that this rank has permission to choose guild perks. |
    | promote | Signals that this rank has permission to promote guildmembers. |
    | questAbandon | Signals that this rank has permission to abandon guild quests. |
    | questAccept | Signals that this rank has permission to accept guild quests. |
    | questComplete | Signals that this rank has permission to complete guild quests. |
    | rally | Signals that this rank has permission to set the guild rally point. |
    | rankEdit | Signals that this rank has permission to edit rank permissions. |
    | rename | Signals that this rank has permission to rename the guild. |
    | speak | Signals that this rank has permission to speak in guild chat. |
    | vaultAccess | A table containing information on vault access permissions. The key is the vault ID in slot format. The value is a table containing two members, "access" which may be nil, "deposit", or "full", and "withdrawLimit" which gives the number of stacks that may be withdrawn daily. |
    | vaultBuy | Signals that this rank has permission to buy guild vaults. |
    | vaultRename | Signals that this rank has permission to rename guild vaults. |
    | wallDelete | Signals that this rank has permission to delete entries off the Guild Wall. |
    | wallPost | Signals that this rank has permission to post to the Guild Wall. |

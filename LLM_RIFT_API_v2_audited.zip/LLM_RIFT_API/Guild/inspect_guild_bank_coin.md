# Inspect.Guild.Bank.Coin

- Original source: inspect_guild_bank_coin.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Returns the amount of money contained within the guild bank.

Returns the amount of money contained within the guild bank.

### Usage:

Interaction category: guildbank

| --- | --- | --- | --- |
| *coin* = Inspect.Guild.Bank.Coin() | | | |
| Parameter | Type | Datatype | Description |
| *coin* | result | *number* | The current money in the guild bank, in silver. |

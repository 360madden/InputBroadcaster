# Command.Guild.Bank.Deposit

- Original source: command_guild_bank_deposit.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Deposits money into the guild bank.

Deposits money into the guild bank.

### Usage:

Interaction category: guildbank

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Bank.Deposit(*coin*) | | | |
| Command.Guild.Bank.Deposit(*coin*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *coin* | parameter | *number* | The string "coin", used as a value to request the player's money. |

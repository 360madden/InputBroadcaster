# Event.Guild.Rank

- Original source: event_guild_rank.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Signals a change in one of your guild's ranks.

Signals a change in one of your guild's ranks.

### Usage:

| --- | --- | --- | --- |
| Event.Guild.Rank(*ranks*) | | | |
| Parameter | Type | Datatype | Description |
| *ranks* | parameter | *variant* | A lookup table of ranks that have changed. |

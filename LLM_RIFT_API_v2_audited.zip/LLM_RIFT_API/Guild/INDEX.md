# Guild
**Priority:** Secondary
**Purpose:** Guild inspection, commands, and events.
**Entry count:** 35
## Most important files first
- [Inspect.Guild.Bank.Detail](inspect_guild_bank_detail.md) — Provides detailed information about guild bank vaults.
- [Inspect.Guild.Rank.Detail](inspect_guild_rank_detail.md) — Provides detailed information about guild ranks.
- [Inspect.Guild.Roster.Detail](inspect_guild_roster_detail.md) — Provides detailed information about guildmembers.
- [Inspect.Guild.Rank.List](inspect_guild_rank_list.md) — Lists available guild ranks.
- [Inspect.Guild.Roster.List](inspect_guild_roster_list.md) — Lists guildmembers.
- [Event.Guild.Roster.Detail.Level](event_guild_roster_detail_level.md) — Signals a change in a guildmember's level.
- [Event.Guild.Roster.Detail.Note](event_guild_roster_detail_note.md) — Signals a change in a guildmember's note.
- [Event.Guild.Roster.Detail.NoteOfficer](event_guild_roster_detail_noteofficer.md) — Signals a change in a guildmember's officer note.

## Full file list
- [Inspect.Guild.Bank.Detail](inspect_guild_bank_detail.md) — Provides detailed information about guild bank vaults.
- [Inspect.Guild.Rank.Detail](inspect_guild_rank_detail.md) — Provides detailed information about guild ranks.
- [Inspect.Guild.Roster.Detail](inspect_guild_roster_detail.md) — Provides detailed information about guildmembers.
- [Inspect.Guild.Rank.List](inspect_guild_rank_list.md) — Lists available guild ranks.
- [Inspect.Guild.Roster.List](inspect_guild_roster_list.md) — Lists guildmembers.
- [Event.Guild.Roster.Detail.Level](event_guild_roster_detail_level.md) — Signals a change in a guildmember's level.
- [Event.Guild.Roster.Detail.Note](event_guild_roster_detail_note.md) — Signals a change in a guildmember's note.
- [Event.Guild.Roster.Detail.NoteOfficer](event_guild_roster_detail_noteofficer.md) — Signals a change in a guildmember's officer note.
- [Event.Guild.Roster.Detail.Rank](event_guild_roster_detail_rank.md) — Signals a change in a guildmember's rank.
- [Event.Guild.Roster.Detail.Status](event_guild_roster_detail_status.md) — Signals a change in a guildmember's status.
- [Event.Guild.Roster.Detail.Zone](event_guild_roster_detail_zone.md) — Signals a change in a guildmember's zone.
- [Inspect.Guild.Bank.List](inspect_guild_bank_list.md) — Returns a table of all available guild bank vaults.
- [Inspect.Guild.Bank.Coin](inspect_guild_bank_coin.md) — Returns the amount of money contained within the guild bank.
- [Inspect.Guild.Motd](inspect_guild_motd.md) — Returns the current guild Message of the Day.
- [Command.Guild.Bank.Deposit](command_guild_bank_deposit.md) — Deposits money into the guild bank.
- [Command.Guild.Bank.Purchase](command_guild_bank_purchase.md) — Purchases a new guild bank vault.
- [Command.Guild.Bank.Withdraw](command_guild_bank_withdraw.md) — Withdraws money from the guild bank.
- [Command.Guild.Log.Request](command_guild_log_request.md) — Requests a guild log event.
- [Command.Guild.Motd](command_guild_motd.md) — Changes the guild's Message of the Day.
- [Command.Guild.Roster.Demote](command_guild_roster_demote.md) — Demotes a guildmember by one rank.
- [Command.Guild.Roster.Kick](command_guild_roster_kick.md) — Kicks a guildmember from the guild.
- [Command.Guild.Roster.Note](command_guild_roster_note.md) — Changes your guild note.
- [Command.Guild.Roster.NoteOfficer](command_guild_roster_noteofficer.md) — Changes a guildmember's officer note.
- [Command.Guild.Roster.Promote](command_guild_roster_promote.md) — Promotes a guildmember by one rank.
- [Command.Guild.Wall.Delete](command_guild_wall_delete.md) — Deletes an entry from the guild wall.
- [Command.Guild.Wall.Post](command_guild_wall_post.md) — Posts an entry to the guild wall.
- [Command.Guild.Wall.Request](command_guild_wall_request.md) — Requests a guild wall event.
- [Event.Guild.Bank.Change](event_guild_bank_change.md) — Signals a change in a guild bank vault's information.
- [Event.Guild.Bank.Coin](event_guild_bank_coin.md) — Signals a change in the guild bank's money.
- [Event.Guild.Log](event_guild_log.md) — Signals incoming guild log data. Can be triggered manually with Command.Guild.Log.Request().
- [Event.Guild.Motd](event_guild_motd.md) — Signals a change in the guild Message of the Day.
- [Event.Guild.Rank](event_guild_rank.md) — Signals a change in one of your guild's ranks.
- [Event.Guild.Roster.Add](event_guild_roster_add.md) — Signals a new player added to the guild roster.
- [Event.Guild.Roster.Remove](event_guild_roster_remove.md) — Signals a player removed from the guild roster.
- [Event.Guild.Wall](event_guild_wall.md) — Signals incoming guild wall data. Can be triggered manually with Command.Guild.Wall.Request().

# Command.Guild.Roster.NoteOfficer

- Original source: command_guild_roster_noteofficer.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Changes a guildmember's officer note.

Changes a guildmember's officer note.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Roster.NoteOfficer(*member*, *note*) | | | |
| Command.Guild.Roster.NoteOfficer(*member*, *note*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *member* | parameter | *string* | The guildmember to target. |
| *note* | parameter | *string* | The new note. |

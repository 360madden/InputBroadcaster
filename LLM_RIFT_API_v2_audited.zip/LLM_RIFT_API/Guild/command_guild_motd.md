# Command.Guild.Motd

- Original source: command_guild_motd.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Changes the guild's Message of the Day.

Changes the guild's Message of the Day.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Motd(*motd*) | | | |
| Command.Guild.Motd(*motd*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *motd* | parameter | *string* | The new Message of the Day. |

# Command.Guild.Wall.Post

- Original source: command_guild_wall_post.html
- Category: Guild
- Priority tier: Secondary
- Source index: Guild_index.html

**Doc summary:** Posts an entry to the guild wall.

Posts an entry to the guild wall.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Guild.Wall.Post(*post*) | | | |
| Command.Guild.Wall.Post(*post*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *post* | parameter | *string* | The item to post. |

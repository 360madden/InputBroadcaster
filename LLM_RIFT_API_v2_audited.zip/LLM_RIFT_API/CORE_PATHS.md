# CORE_PATHS

See also `START_HERE_FOR_CODE.md` for the tightest raw-doc shortlist.

Use these first when the goal is to generate Rift addon code with the least drift.

## Start here
1. `START_HERE_FOR_CODE.md`
2. `HIGH_VALUE_SUMMARIES/`
3. `MASTER_INDEX.md`
4. Core raw docs in this order:
   - `UI/ui_createcontext.md`, `UI/ui_createframe.md`
   - `Frame/frame_setpoint.md`, `Frame/frame_clearall.md`, `Frame/frame_setvisible.md`
   - `Text/text_settext.md`, `Texture/texture_settexture.md`
   - `Native/native_eventattach.md`, `Native/native_eventdetach.md`
   - `Event/command_event_attach.md`, `Event/command_event_detach.md`
   - `Unit/inspect_unit_detail.md`, `Unit/inspect_unit_list.md`
   - `Slash/command_slash_register.md`
   - `Addon/event_addon_startup_end.md`
   - `Map/inspect_map_detail.md` only when coordinates or waypoints matter

## Avoid first-pass focus on
- `Miscellaneous/`
- `Type/`
- `Matrix/`
- `Role/`
- `Shard/`
- `Zone/`
- `Fragment/`
- most `UI.Native.*` pages unless the task explicitly targets a built-in Rift window or HUD element

## Best task routes
- **Create a movable widget:** `HIGH_VALUE_SUMMARIES/UI_FRAMEWORK_OVERVIEW.md`, `HIGH_VALUE_SUMMARIES/FRAME_POSITIONING_OVERVIEW.md`, then `UI/ui_createcontext.md`, `UI/ui_createframe.md`, `Frame/frame_setpoint.md`, `Text/text_settext.md`
- **Attach live updates:** `HIGH_VALUE_SUMMARIES/EVENT_SYSTEM_OVERVIEW.md`, then `Event/command_event_attach.md`, `Native/native_eventattach.md`, `UI/` input event docs
- **Read player or target data:** `HIGH_VALUE_SUMMARIES/UNIT_AND_TARGET_OVERVIEW.md`, `HIGH_VALUE_SUMMARIES/INSPECT_API_OVERVIEW.md`, then `Unit/inspect_unit_detail.md`
- **Use slash commands:** `HIGH_VALUE_SUMMARIES/COMMAND_AND_SLASH_OVERVIEW.md`, then `Slash/command_slash_register.md`
- **Coordinates, markers, or range groundwork:** `HIGH_VALUE_SUMMARIES/MAP_AND_COORDINATE_OVERVIEW.md`, then `Map/inspect_map_detail.md`, `Map/command_map_waypoint_set.md`, `Unit/inspect_unit_detail.md`

## Summary discipline
Use the summary docs to find the right subsystem quickly. For exact signatures, parameter shapes, return values, and edge-case wording, fall back to the raw category files.

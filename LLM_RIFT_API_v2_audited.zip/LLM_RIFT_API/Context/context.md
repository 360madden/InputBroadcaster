# Context

- Original source: context.html
- Category: Context
- Priority tier: Core
- Source index: Context_index.html

**Doc summary:** A UI element of type Context or derived from Context.

A UI element of type Context or derived from Context.

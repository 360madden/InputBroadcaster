# Context
**Priority:** Core
**Purpose:** Root UI context objects used before creating frames.
**Entry count:** 1
## Most important files first
- [Context](context.md) — A UI element of type Context or derived from Context.

## Full file list
- [Context](context.md) — A UI element of type Context or derived from Context.

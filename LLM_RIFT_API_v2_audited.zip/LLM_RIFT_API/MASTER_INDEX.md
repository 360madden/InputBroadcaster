# MASTER_INDEX

This package is optimized for LLM-assisted Rift addon coding. It is a Markdown-only derivative of the uploaded HTML dump. It is **not** intended to preserve browser pathing.

## Fastest route for code generation
1. Read `START_HERE_FOR_CODE.md`.
2. Read `CORE_PATHS.md`.
3. Read the files in `HIGH_VALUE_SUMMARIES/`.
4. Use the category `INDEX.md` files in core folders to jump to exact raw docs.
5. Use the raw category files for exact signatures and wording.

## Priority reading order
1. UI construction: `UI/`, `Frame/`, `Canvas/`, `Text/`, `Texture/`, `Native/`
2. Events: `Event/`, plus frame/widget `:EventAttach` docs
3. State reads: `Unit/`, `Map/`, `Setting/`, `Addon/`
4. Control surfaces: `Slash/`, `System/`, `Map/`, `Unit/`
5. Situational gameplay APIs after that


## Best raw docs to open first
- `UI/ui_createcontext.md`
- `UI/ui_createframe.md`
- `Frame/frame_setpoint.md`
- `Frame/frame_clearall.md`
- `Frame/frame_setvisible.md`
- `Text/text_settext.md`
- `Texture/texture_settexture.md`
- `Native/native_eventattach.md`
- `Event/command_event_attach.md`
- `Event/command_event_detach.md`
- `Unit/inspect_unit_detail.md`
- `Slash/command_slash_register.md`
- `Addon/event_addon_startup_end.md`

## Low-signal areas to ignore until needed
- `Miscellaneous/`
- `Type/`
- `Matrix/`
- `Role/`
- `Shard/`
- `Zone/`
- `Fragment/`
- `CopyToClipboard/`
- most `UI.Native.*` docs unless the task explicitly targets a built-in Rift UI element

## High-value summaries
- [`HIGH_VALUE_SUMMARIES/UI_FRAMEWORK_OVERVIEW.md`](HIGH_VALUE_SUMMARIES/UI_FRAMEWORK_OVERVIEW.md)
- [`HIGH_VALUE_SUMMARIES/FRAME_POSITIONING_OVERVIEW.md`](HIGH_VALUE_SUMMARIES/FRAME_POSITIONING_OVERVIEW.md)
- [`HIGH_VALUE_SUMMARIES/EVENT_SYSTEM_OVERVIEW.md`](HIGH_VALUE_SUMMARIES/EVENT_SYSTEM_OVERVIEW.md)
- [`HIGH_VALUE_SUMMARIES/UNIT_AND_TARGET_OVERVIEW.md`](HIGH_VALUE_SUMMARIES/UNIT_AND_TARGET_OVERVIEW.md)
- [`HIGH_VALUE_SUMMARIES/INSPECT_API_OVERVIEW.md`](HIGH_VALUE_SUMMARIES/INSPECT_API_OVERVIEW.md)
- [`HIGH_VALUE_SUMMARIES/COMMAND_AND_SLASH_OVERVIEW.md`](HIGH_VALUE_SUMMARIES/COMMAND_AND_SLASH_OVERVIEW.md)
- [`HIGH_VALUE_SUMMARIES/MAP_AND_COORDINATE_OVERVIEW.md`](HIGH_VALUE_SUMMARIES/MAP_AND_COORDINATE_OVERVIEW.md)
- [`HIGH_VALUE_SUMMARIES/SETTINGS_AND_PERSISTENCE_OVERVIEW.md`](HIGH_VALUE_SUMMARIES/SETTINGS_AND_PERSISTENCE_OVERVIEW.md)

## Task routing
- **Create any basic addon UI:** UI/, Frame/, Canvas/, Native/, Text/, Texture/
- **Create text overlays or labels:** Text/, Frame/, UI/
- **Anchor, move, or resize UI elements:** Frame/, Native/, Layout/
- **Attach live updates or input handlers:** Event/, Native/, UI/, Frame/, Canvas/
- **Read player/target/unit data:** Unit/, plus `HIGH_VALUE_SUMMARIES/UNIT_AND_TARGET_OVERVIEW.md`
- **Read map data or coordinates:** Map/, Unit/, plus `HIGH_VALUE_SUMMARIES/MAP_AND_COORDINATE_OVERVIEW.md`
- **Register slash commands:** Slash/, Event/
- **Handle addon startup or saved variables:** Addon/, Setting/, System/

## Categories
- **Addon** — Core; 13 docs; [`Addon/INDEX.md`](Addon/INDEX.md) — Addon lifecycle events, startup/shutdown, and saved-variable timing.
- **Canvas** — Core; 88 docs; [`Canvas/INDEX.md`](Canvas/INDEX.md) — Canvas frame APIs: frame-like UI element behavior plus drawing/input/event methods.
- **Console** — Secondary; 3 docs; [`Console/INDEX.md`](Console/INDEX.md) — Console-specific debug and display APIs.
- **Context** — Core; 1 docs; [`Context/INDEX.md`](Context/INDEX.md) — Root UI context objects used before creating frames.
- **CopyToClipboard** — Secondary; 1 docs; [`CopyToClipboard/INDEX.md`](CopyToClipboard/INDEX.md) — Clipboard helper command.
- **Cursor** — Secondary; 3 docs; [`Cursor/INDEX.md`](Cursor/INDEX.md) — Cursor state and cursor-related events.
- **Dispatch** — Secondary; 1 docs; [`Dispatch/INDEX.md`](Dispatch/INDEX.md) — Protected call helper for safely invoking functions.
- **Element** — Secondary; 1 docs; [`Element/INDEX.md`](Element/INDEX.md) — Base UI element type documentation.
- **Event** — Core; 4 docs; [`Event/INDEX.md`](Event/INDEX.md) — Global event creation, attachment, detachment, and inspection.
- **Frame** — Core; 86 docs; [`Frame/INDEX.md`](Frame/INDEX.md) — Base frame APIs: positioning, visibility, child relationships, and UI input events.
- **Layout** — Secondary; 23 docs; [`Layout/INDEX.md`](Layout/INDEX.md) — Layout-oriented frame methods and event helpers.
- **Map** — Core; 12 docs; [`Map/INDEX.md`](Map/INDEX.md) — Map locations, waypoint commands, monitor mode, and map detail/events.
- **Mask** — Core; 88 docs; [`Mask/INDEX.md`](Mask/INDEX.md) — Mask frame APIs for clipping child content.
- **Mouse** — Secondary; 2 docs; [`Mouse/INDEX.md`](Mouse/INDEX.md) — Mouse state and mouse-specific global events.
- **Native** — Core; 171 docs; [`Native/INDEX.md`](Native/INDEX.md) — Native UI element APIs shared across many frame/widget types.
- **RiftButton** — Core; 93 docs; [`RiftButton/INDEX.md`](RiftButton/INDEX.md) — Standard Rift button widget APIs.
- **RiftCheckbox** — Core; 91 docs; [`RiftCheckbox/INDEX.md`](RiftCheckbox/INDEX.md) — Standard Rift checkbox widget APIs.
- **RiftScrollbar** — Core; 102 docs; [`RiftScrollbar/INDEX.md`](RiftScrollbar/INDEX.md) — Standard Rift scrollbar widget APIs.
- **RiftSlider** — Core; 95 docs; [`RiftSlider/INDEX.md`](RiftSlider/INDEX.md) — Standard Rift slider widget APIs.
- **RiftTextfield** — Core; 95 docs; [`RiftTextfield/INDEX.md`](RiftTextfield/INDEX.md) — Standard Rift textfield widget APIs.
- **RiftWindow** — Core; 93 docs; [`RiftWindow/INDEX.md`](RiftWindow/INDEX.md) — Standard Rift window widget APIs.
- **RiftWindowBorder** — Core; 64 docs; [`RiftWindowBorder/INDEX.md`](RiftWindowBorder/INDEX.md) — RiftWindow border widget APIs.
- **RiftWindowContent** — Core; 64 docs; [`RiftWindowContent/INDEX.md`](RiftWindowContent/INDEX.md) — RiftWindow content widget APIs.
- **Setting** — Core; 2 docs; [`Setting/INDEX.md`](Setting/INDEX.md) — Setting inspection APIs and setting value lookups.
- **Slash** — Core; 1 docs; [`Slash/INDEX.md`](Slash/INDEX.md) — Slash-command registration APIs.
- **System** — Core; 15 docs; [`System/INDEX.md`](System/INDEX.md) — System-level commands and update/secure/error events.
- **Text** — Core; 100 docs; [`Text/INDEX.md`](Text/INDEX.md) — Text frame APIs including content, font, alignment, and text metrics.
- **Texture** — Core; 90 docs; [`Texture/INDEX.md`](Texture/INDEX.md) — Texture frame APIs for images and texture resources.
- **Tooltip** — Secondary; 3 docs; [`Tooltip/INDEX.md`](Tooltip/INDEX.md) — Tooltip creation and tooltip control APIs.
- **Type** — Peripheral; 2 docs; [`Type/INDEX.md`](Type/INDEX.md) — Type inspection helpers for Rift-specific identifiers and values.
- **UI** — Core; 113 docs; [`UI/INDEX.md`](UI/INDEX.md) — UI creation functions and UI input/control events.
- **Unit** — Core; 51 docs; [`Unit/INDEX.md`](Unit/INDEX.md) — Unit commands, unit detail inspection, and unit-related events.
- **Ability** — Secondary; 11 docs; [`Ability/INDEX.md`](Ability/INDEX.md) — Ability inspection and ability-related events.
- **Achievement** — Secondary; 7 docs; [`Achievement/INDEX.md`](Achievement/INDEX.md) — Achievement and achievement-category inspection/events.
- **Attunement** — Secondary; 5 docs; [`Attunement/INDEX.md`](Attunement/INDEX.md) — Attunement inspection and events.
- **Auction** — Secondary; 13 docs; [`Auction/INDEX.md`](Auction/INDEX.md) — Auction inspection, events, and commands.
- **Buff** — Secondary; 8 docs; [`Buff/INDEX.md`](Buff/INDEX.md) — Buff inspection and buff-related events.
- **Chat** — Secondary; 2 docs; [`Chat/INDEX.md`](Chat/INDEX.md) — Chat inspection and chat-related events.
- **Combat** — Secondary; 8 docs; [`Combat/INDEX.md`](Combat/INDEX.md) — Combat state inspection and combat events.
- **Currency** — Secondary; 5 docs; [`Currency/INDEX.md`](Currency/INDEX.md) — Currency inspection and currency events.
- **Dimension** — Secondary; 8 docs; [`Dimension/INDEX.md`](Dimension/INDEX.md) — Dimension inspection and dimension events.
- **Experience** — Secondary; 3 docs; [`Experience/INDEX.md`](Experience/INDEX.md) — Experience inspection and events.
- **Faction** — Secondary; 3 docs; [`Faction/INDEX.md`](Faction/INDEX.md) — Faction inspection and events.
- **Fragment** — Secondary; 1 docs; [`Fragment/INDEX.md`](Fragment/INDEX.md) — Fragment UI type documentation.
- **Guild** — Secondary; 35 docs; [`Guild/INDEX.md`](Guild/INDEX.md) — Guild inspection, commands, and events.
- **Interaction** — Secondary; 2 docs; [`Interaction/INDEX.md`](Interaction/INDEX.md) — Interaction inspection and interaction events.
- **Item** — Secondary; 24 docs; [`Item/INDEX.md`](Item/INDEX.md) — Item inspection, commands, and item-related events.
- **Mail** — Secondary; 11 docs; [`Mail/INDEX.md`](Mail/INDEX.md) — Mail commands, inspection, and events.
- **Message** — Secondary; 9 docs; [`Message/INDEX.md`](Message/INDEX.md) — Message events and messaging helpers.
- **Minion** — Secondary; 12 docs; [`Minion/INDEX.md`](Minion/INDEX.md) — Minion inspection, commands, and events.
- **Miscellaneous** — Peripheral; 29 docs; [`Miscellaneous/INDEX.md`](Miscellaneous/INDEX.md) — Low-level identifier/type pages and a small number of utility/reference pages.
- **Pvp** — Secondary; 6 docs; [`Pvp/INDEX.md`](Pvp/INDEX.md) — PvP inspection and PvP events.
- **Quest** — Secondary; 11 docs; [`Quest/INDEX.md`](Quest/INDEX.md) — Quest inspection, commands, and quest events.
- **Queue** — Secondary; 4 docs; [`Queue/INDEX.md`](Queue/INDEX.md) — Queue inspection and queue events.
- **Role** — Secondary; 1 docs; [`Role/INDEX.md`](Role/INDEX.md) — Role identifier/type documentation.
- **Serialize** — Secondary; 2 docs; [`Serialize/INDEX.md`](Serialize/INDEX.md) — Serialization and deserialization helpers.
- **Shard** — Secondary; 1 docs; [`Shard/INDEX.md`](Shard/INDEX.md) — Shard identifier/type documentation.
- **Social** — Secondary; 12 docs; [`Social/INDEX.md`](Social/INDEX.md) — Social commands, inspection, and events.
- **Stat** — Secondary; 2 docs; [`Stat/INDEX.md`](Stat/INDEX.md) — Stat inspection APIs.
- **Storage** — Secondary; 10 docs; [`Storage/INDEX.md`](Storage/INDEX.md) — Storage inspection and storage events.
- **Time** — Secondary; 3 docs; [`Time/INDEX.md`](Time/INDEX.md) — Time inspection and time-related events.
- **Title** — Secondary; 7 docs; [`Title/INDEX.md`](Title/INDEX.md) — Title inspection and title events.
- **Zone** — Secondary; 1 docs; [`Zone/INDEX.md`](Zone/INDEX.md) — Zone identifier/type documentation.
- **Matrix** — Peripheral; 1 docs; [`Matrix/INDEX.md`](Matrix/INDEX.md) — API entries grouped under Matrix_index.html.

## Excluded or demoted from the uploaded dump
- Entire categories dropped as low-signal for coding quality: `Documentation`, `TEMPORARY`.
- Generic helper/type noise dropped: `boolean`, `callbackfunction`, `dump`, `error`, `function`, `function/nil`, `function/string`, `function/string/nil`, `nil`, `number`, `number/nil`, `string`, `string/nil`, `table`, `types`, `variant`.
- Rationale: these pages add little coding guidance compared with the functional API pages and can distract retrieval.

## Summary discipline
The summary docs are a synthesis layer. For exact signatures, parameter types, return tables, event payloads, and edge-case wording, prefer the raw Markdown files in the category folders.

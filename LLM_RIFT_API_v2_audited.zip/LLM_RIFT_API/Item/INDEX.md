# Item
**Priority:** Secondary
**Purpose:** Item inspection, commands, and item-related events.
**Entry count:** 24
## Most important files first
- [Inspect.Item.Detail](inspect_item_detail.md) — Provides detailed information about items.
- [Inspect.Item.List](inspect_item_list.md) — Generate a list of item IDs from a slot specifier or set of slot specifiers.
- [Inspect.Item.Mount.List](inspect_item_mount_list.md) — Returns details about all of your collected mounts.
- [Event.Item.Update](event_item_update.md) — Signals that an item has changed.
- [Inspect.Item.Find](inspect_item_find.md) — Finds a slot specifier based on an item ID.
- [Command.Item.Destroy](command_item_destroy.md) — Destroys an item. Be careful: this really does destroy an item. There is no confirmation dialog a...
- [Command.Item.Mount.Use](command_item_mount_use.md) — Uses a collected mount.
- [Command.Item.Move](command_item_move.md) — Moves an item from one location to another. This cannot move items directly between equipment, wa...

## Full file list
- [Inspect.Item.Detail](inspect_item_detail.md) — Provides detailed information about items.
- [Inspect.Item.List](inspect_item_list.md) — Generate a list of item IDs from a slot specifier or set of slot specifiers.
- [Inspect.Item.Mount.List](inspect_item_mount_list.md) — Returns details about all of your collected mounts.
- [Event.Item.Update](event_item_update.md) — Signals that an item has changed.
- [Inspect.Item.Find](inspect_item_find.md) — Finds a slot specifier based on an item ID.
- [Command.Item.Destroy](command_item_destroy.md) — Destroys an item. Be careful: this really does destroy an item. There is no confirmation dialog a...
- [Command.Item.Mount.Use](command_item_mount_use.md) — Uses a collected mount.
- [Command.Item.Move](command_item_move.md) — Moves an item from one location to another. This cannot move items directly between equipment, wa...
- [Command.Item.Split](command_item_split.md) — Splits a number of items off a stack.
- [Command.Item.Standard.Drag](command_item_standard_drag.md) — Behaves in the same way that the addon system does when an inventory icon is dragged.
- [Command.Item.Standard.Drop](command_item_standard_drop.md) — Behaves in the same way that the addon system does when an inventory icon is dropped.
- [Command.Item.Standard.Left](command_item_standard_left.md) — Behaves in the same way that the addon system does when an inventory icon is left-clicked.
- [Command.Item.Standard.Right](command_item_standard_right.md) — Behaves in the same way that the addon system does when an inventory icon is right-clicked.
- [Event.Item.Slot](event_item_slot.md) — Signals that the contents of an item slot have changed.
- [Utility.Item.Slot.All](utility_item_slot_all.md) — Generates a slot specifier for all known items.
- [Utility.Item.Slot.Bank](utility_item_slot_bank.md) — Generates a slot specifier for the player's bank.
- [Utility.Item.Slot.Equipment](utility_item_slot_equipment.md) — Generates a slot specifier for the player's equipment.
- [Utility.Item.Slot.Fragments](utility_item_slot_fragments.md) — Generates a slot specifier for the player's fragment inventory.
- [Utility.Item.Slot.Guild](utility_item_slot_guild.md) — Generates a slot specifier for the player's guild bank.
- [Utility.Item.Slot.Inventory](utility_item_slot_inventory.md) — Generates a slot specifier for the player's inventory.
- [Utility.Item.Slot.Parse](utility_item_slot_parse.md) — Parses a slot specifier, returning information on what it represents.
- [Utility.Item.Slot.Quest](utility_item_slot_quest.md) — Generates a slot specifier for the player's quest bag.
- [Utility.Item.Slot.Vault](utility_item_slot_vault.md) — Generates a slot specifier for the player's bank vaults.
- [Utility.Item.Slot.Wardrobe](utility_item_slot_wardrobe.md) — Generates a slot specifier for the player's wardrobe.

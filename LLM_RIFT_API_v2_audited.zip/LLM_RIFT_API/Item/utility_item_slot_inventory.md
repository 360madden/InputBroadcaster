# Utility.Item.Slot.Inventory

- Original source: utility_item_slot_inventory.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Generates a slot specifier for the player's inventory.

Generates a slot specifier for the player's inventory.

### Usage:

| --- | --- | --- | --- |
| *slot* = Utility.Item.Slot.Inventory() | | | |
| *slot* = Utility.Item.Slot.Inventory(*bag*) | | | |
| *slot* = Utility.Item.Slot.Inventory(*bag*, *slot*) | | | |
| Parameter | Type | Datatype | Description |
| *bag* | parameter | *number, string* | The number of the bag whose contents should be inspected, starting at 1, or "bag" to inspect the actual inventory bags. |
| *slot* | parameter | *number, slot* | The requested slot specifier. |
| *slot* | result | *number, slot* | The requested slot specifier. |

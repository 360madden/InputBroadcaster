# Command.Item.Standard.Right

- Original source: command_item_standard_right.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Behaves in the same way that the addon system does when an inventory icon is right-clicked.

Behaves in the same way that the addon system does when an inventory icon is right-clicked.

### Usage:

Interaction category: item

| --- | --- | --- | --- |
| Command.Item.Standard.Right(*target*) | | | |
| Parameter | Type | Datatype | Description |
| *target* | parameter | *item, slot* | The item or slot to be targeted. |

**hardwareevent**
:   true

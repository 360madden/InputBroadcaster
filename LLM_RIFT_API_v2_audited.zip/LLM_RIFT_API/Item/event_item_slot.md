# Event.Item.Slot

- Original source: event_item_slot.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Signals that the contents of an item slot have changed.

Signals that the contents of an item slot have changed.

### Usage:

| --- | --- | --- | --- |
| Event.Item.Slot(*updates*) | | | |
| Parameter | Type | Datatype | Description |
| *updates* | parameter | *variant* | Table of changes. Key is the slot identifier, value is an item ID, false if the slot is now empty, or the string "nil" if the slot no longer exists. |

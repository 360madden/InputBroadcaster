# Command.Item.Standard.Drag

- Original source: command_item_standard_drag.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Behaves in the same way that the addon system does when an inventory icon is dragged.

Behaves in the same way that the addon system does when an inventory icon is dragged.

### Usage:

Interaction category: item

| --- | --- | --- | --- |
| Command.Item.Standard.Drag(*target*) | | | |
| Parameter | Type | Datatype | Description |
| *target* | parameter | *item, slot* | The item or slot to be targeted. |

# Utility.Item.Slot.Equipment

- Original source: utility_item_slot_equipment.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Generates a slot specifier for the player's equipment.

Generates a slot specifier for the player's equipment.

### Usage:

| --- | --- | --- | --- |
| *slot* = Utility.Item.Slot.Equipment() | | | |
| *slot* = Utility.Item.Slot.Equipment(*slot*) | | | |
| Parameter | Type | Datatype | Description |
| *slot* | parameter | *string, slot* | The requested slot specifier. |
| *slot* | result | *string, slot* | The requested slot specifier. |

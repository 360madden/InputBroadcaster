# Utility.Item.Slot.Bank

- Original source: utility_item_slot_bank.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Generates a slot specifier for the player's bank.

Generates a slot specifier for the player's bank.

### Usage:

| --- | --- | --- | --- |
| *slot* = Utility.Item.Slot.Bank() | | | |
| *slot* = Utility.Item.Slot.Bank(*segment*) | | | |
| *slot* = Utility.Item.Slot.Bank(*segment*, *slot*) | | | |
| Parameter | Type | Datatype | Description |
| *segment* | parameter | *number, string* | Segment to inspect. Use "main" for the main bank area, "bag" for the bank bags, or a number starting at 1 for the contents of a specific bank bag. |
| *slot* | parameter | *number, slot* | The requested slot specifier. |
| *slot* | result | *number, slot* | The requested slot specifier. |

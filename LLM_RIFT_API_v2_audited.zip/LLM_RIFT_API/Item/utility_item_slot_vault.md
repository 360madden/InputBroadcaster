# Utility.Item.Slot.Vault

- Original source: utility_item_slot_vault.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Generates a slot specifier for the player's bank vaults.

Generates a slot specifier for the player's bank vaults.

### Usage:

| --- | --- | --- | --- |
| *slot* = Utility.Item.Slot.Vault() | | | |
| *slot* = Utility.Item.Slot.Vault(*vault*) | | | |
| *slot* = Utility.Item.Slot.Vault(*vault*, *slot*) | | | |
| Parameter | Type | Datatype | Description |
| *slot* | parameter | *number, slot* | The requested slot specifier. |
| *vault* | parameter | *number* | The vault ID, starting at 1. |
| *slot* | result | *number, slot* | The requested slot specifier. |

# Utility.Item.Slot.All

- Original source: utility_item_slot_all.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Generates a slot specifier for all known items.

Generates a slot specifier for all known items.

### Usage:

| --- | --- | --- | --- |
| *slot* = Utility.Item.Slot.All() | | | |
| Parameter | Type | Datatype | Description |
| *slot* | result | *slot* | The requested slot specifier. |

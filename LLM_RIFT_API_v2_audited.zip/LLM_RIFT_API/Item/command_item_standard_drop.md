# Command.Item.Standard.Drop

- Original source: command_item_standard_drop.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Behaves in the same way that the addon system does when an inventory icon is dropped.

Behaves in the same way that the addon system does when an inventory icon is dropped.

### Usage:

Interaction category: item

| --- | --- | --- | --- |
| Command.Item.Standard.Drop(*target*) | | | |
| Parameter | Type | Datatype | Description |
| *target* | parameter | *item, slot* | The item or slot to be targeted. |

**hardwareevent**
:   true

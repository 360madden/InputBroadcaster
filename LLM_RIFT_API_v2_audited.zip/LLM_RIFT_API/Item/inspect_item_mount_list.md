# Inspect.Item.Mount.List

- Original source: inspect_item_mount_list.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Returns details about all of your collected mounts.

Returns details about all of your collected mounts.

### Usage:

| --- | --- | --- | --- |
| *mounts* = Inspect.Item.Mount.List() | | | |
| Parameter | Type | Datatype | Description |
| *mounts* | result | *table* | Valid collected mount, in {id = "type"} format. |

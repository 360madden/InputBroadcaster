# Inspect.Item.List

- Original source: inspect_item_list.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Generate a list of item IDs from a slot specifier or set of slot specifiers.

Generate a list of item IDs from a slot specifier or set of slot specifiers.

### Usage:

| --- | --- | --- | --- |
| *items* = Inspect.Item.List() | | | |
| *item* = Inspect.Item.List(*slot*) | | | |
| *items* = Inspect.Item.List(*slot*) | | | |
| *items* = Inspect.Item.List(*slots*) | | | |
| Parameter | Type | Datatype | Description |
| *slot* | parameter | *slot* | A single slot specifier. |
| *slots* | parameter | *table* | A table of slot specifiers. |
| *item* | result | *item* | A single item ID. This will be returned only if the input is a single fully-specified slot specifier. |
| *items* | result | *table* | A table of item IDs. The key is the slot specifier, the value is the item ID. |

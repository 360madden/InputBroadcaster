# Utility.Item.Slot.Fragments

- Original source: utility_item_slot_fragments.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Generates a slot specifier for the player's fragment inventory.

Generates a slot specifier for the player's fragment inventory.

### Usage:

| --- | --- | --- | --- |
| *slot* = Utility.Item.Slot.Fragments() | | | |
| *slot* = Utility.Item.Slot.Fragments(*slot*) | | | |
| Parameter | Type | Datatype | Description |
| *slot* | parameter | *number, slot* | The requested slot specifier. |
| *slot* | result | *number, slot* | The requested slot specifier. |

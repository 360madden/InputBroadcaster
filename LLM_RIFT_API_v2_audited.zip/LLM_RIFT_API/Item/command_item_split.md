# Command.Item.Split

- Original source: command_item_split.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Splits a number of items off a stack.

Splits a number of items off a stack.

### Usage:

Interaction category: item

Throttled.

| --- | --- | --- | --- |
| Command.Item.Split(*source*, *stack*) | | | |
| Parameter | Type | Datatype | Description |
| *source* | parameter | *item, slot* | The item to split. May be a slot specifier or an item ID. |
| *stack* | parameter | *number* | The number of items to move into the new stack. Must be a positive integer. |

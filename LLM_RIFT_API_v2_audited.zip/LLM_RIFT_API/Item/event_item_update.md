# Event.Item.Update

- Original source: event_item_update.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Signals that an item has changed.

Signals that an item has changed.

### Usage:

| --- | --- | --- | --- |
| Event.Item.Update(*updates*) | | | |
| Parameter | Type | Datatype | Description |
| *updates* | parameter | *variant* | Table of changes. Key is the slot identifier, value is an item ID, false if the slot is now empty, or the string "nil" if the slot no longer exists. |

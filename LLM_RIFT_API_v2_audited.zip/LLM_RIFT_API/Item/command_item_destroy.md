# Command.Item.Destroy

- Original source: command_item_destroy.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Destroys an item. Be careful: this really does destroy an item. There is no confirmation dialog and the process is irreversible. This cannot destroy items directly out of the guild bank.

Destroys an item. Be careful: this really does destroy an item. There is no confirmation dialog and the process is irreversible. This cannot destroy items directly out of the guild bank.

### Usage:

Interaction category: item

Throttled.

| --- | --- | --- | --- |
| Command.Item.Destroy(*target*) | | | |
| Parameter | Type | Datatype | Description |
| *target* | parameter | *item* | The item ID of the item to destroy. |

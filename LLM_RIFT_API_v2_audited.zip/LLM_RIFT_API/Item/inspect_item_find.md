# Inspect.Item.Find

- Original source: inspect_item_find.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Finds a slot specifier based on an item ID.

Finds a slot specifier based on an item ID.

### Usage:

| --- | --- | --- | --- |
| *slot* = Inspect.Item.Find(*item*) | | | |
| *slots* = Inspect.Item.Find(*items*) | | | |
| Parameter | Type | Datatype | Description |
| *item* | parameter | *item* | A single item ID. |
| *items* | parameter | *table* | A table of item IDs. |
| *slot* | result | *slot* | A slot specifier for that item. |
| *slots* | result | *table* | Slot specifiers for all requested items. The key is the string used to lookup, the value is the slot specifier. |

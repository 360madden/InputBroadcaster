# Utility.Item.Slot.Wardrobe

- Original source: utility_item_slot_wardrobe.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Generates a slot specifier for the player's wardrobe.

Generates a slot specifier for the player's wardrobe.

### Usage:

| --- | --- | --- | --- |
| *slot* = Utility.Item.Slot.Wardrobe() | | | |
| *slot* = Utility.Item.Slot.Wardrobe(*costume*) | | | |
| *slot* = Utility.Item.Slot.Wardrobe(*costume*, *slot*) | | | |
| Parameter | Type | Datatype | Description |
| *costume* | parameter | *number* | The number of the wardrobe costume to inspect, starting at 1. |
| *slot* | parameter | *string, slot* | The requested slot specifier. |
| *slot* | result | *string, slot* | The requested slot specifier. |

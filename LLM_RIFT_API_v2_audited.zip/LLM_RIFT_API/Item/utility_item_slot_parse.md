# Utility.Item.Slot.Parse

- Original source: utility_item_slot_parse.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Parses a slot specifier, returning information on what it represents.

Parses a slot specifier, returning information on what it represents.

### Usage:

| --- | --- | --- | --- |
| *type, parameter, parameter* = Utility.Item.Slot.Parse(*slot*) | | | |
| *type, parameter* = Utility.Item.Slot.Parse(*slot*) | | | |
| *type* = Utility.Item.Slot.Parse(*slot*) | | | |
| Utility.Item.Slot.Parse(*slot*) | | | |
| Parameter | Type | Datatype | Description |
| *slot* | parameter | *slot* | The slot ID, starting at 1. |
| *parameter* | result | *variant* | A parameter for this slot type. Actual meaning depends on the type. |
| *type* | result | *string* | The type of this element. |

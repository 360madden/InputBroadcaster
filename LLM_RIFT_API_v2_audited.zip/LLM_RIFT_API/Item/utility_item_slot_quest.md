# Utility.Item.Slot.Quest

- Original source: utility_item_slot_quest.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Generates a slot specifier for the player's quest bag.

Generates a slot specifier for the player's quest bag.

### Usage:

| --- | --- | --- | --- |
| *slot* = Utility.Item.Slot.Quest() | | | |
| *slot* = Utility.Item.Slot.Quest(*slot*) | | | |
| Parameter | Type | Datatype | Description |
| *slot* | parameter | *number, slot* | The requested slot specifier. |
| *slot* | result | *number, slot* | The requested slot specifier. |

# Inspect.Item.Detail

- Original source: inspect_item_detail.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Provides detailed information about items.

Provides detailed information about items.

### Usage:

| --- | --- | --- | --- |
| *item* = Inspect.Item.Detail(*item*) | | | |
| *item* = Inspect.Item.Detail(*itemtype*) | | | |
| *item* = Inspect.Item.Detail(*slot*) | | | |
| *items* = Inspect.Item.Detail(*slot*) | | | |
| *items* = Inspect.Item.Detail(*elements*) | | | |
| Parameter | Type | Datatype | Description |
| *elements* | parameter | *table* | A table of slot specifiers, item IDs, or item types. |
| *item* | parameter | *item, table* | Detail table for a single item. |
| *itemtype* | parameter | *itemtype* | A single item type. |
| *slot* | parameter | *slot* | A single slot specifier. |
| *item* | result | *item, table* | Detail table for a single item. |
| *items* | result | *table* | Detail tables for all requested items. The key is the string used to lookup, the value is the item's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | bind | The item's binding type. May be "equip", "use", "pickup", or "account". |
    | bound | The item's bound flag. |
    | category | The item's type category. |
    | coin | The amount of silver this item represents. |
    | cooldown | The cooldown for using this item. |
    | cooldownBegin | The time the current cooldown started, in the context of Inspect.Time.Frame. |
    | cooldownDuration | Duration of the current cooldown the item is influenced by, in seconds. |
    | cooldownExpired | Number of seconds the current cooldown is past its expiration time. Generally indicates lag. |
    | cooldownRemaining | Time remaining in the item's current cooldown, in seconds. |
    | crafter | The name of the player who crafted this item. |
    | damageDelay | If a weapon, the delay between autoattacks using this weapon. |
    | damageMax | If a weapon, the maximum damage done by a single hit with this item. |
    | damageMin | If a weapon, the minimum damage done by a single hit with this item. |
    | damageType | If a weapon, the damage type done by autoattacks. Values include "life", "death", "air", "earth", "fire", and "water". |
    | description | The description of this item. |
    | flavor | The flavor text for this item. |
    | fragmentAffinity | The planar type of the planar fragment. |
    | fragmentTier | The pairing rating of the stats for the planar fragment. |
    | icon | Resource filename of the item's icon. |
    | id | The ID of the requested element. |
    | infusionLevel | The current level of a planar fragment. |
    | lootable | Indicates that the item contains loot. |
    | mountAquatic | Indicates that the mount is aquatic. |
    | mountAutoscale | Indicates if the mount autoscales to your fastest mount speed. |
    | mountSpeed | The speed of your character while mounted. |
    | name | The item's name. |
    | range | If a ranged weapon, the maximum range of this item. |
    | rarity | The item's rarity. Values include "sellable", "uncommon", "rare", "epic", "relic", "transcendent", or "quest". Common items have a rarity of nil. |
    | requiredCalling | Space-delimited list of the required callings to use this item. |
    | requiredFaction | The ID of the faction required to use this item. |
    | requiredFactionLevel | The faction notoriety required to use this item. |
    | requiredLevel | The level required to use this item. |
    | requiredPrestige | The prestige rank required to use this item. |
    | requiredSkill | The skill required to use this item. |
    | requiredSkillLevel | The skill level required to use this item. |
    | sell | The sell value of this item, in silver. |
    | slots | If a container, the number of slots that this item can contain. |
    | stack | The size of this item stack. |
    | stackMax | The maximum size of this item stack. |
    | stats | The base stats of this item. Members may include "armor", "block", "critAttack", "critPower", "critSpell", "dexterity", "dodge", "endurance", "energyMax", "energyRegen", "hit", "intelligence", "manaMax", "manaRegen", "movement", "powerAttack", "powerMax", "powerRegen", "powerSpell", "resistAir", "resistAll", "resistDeath", "resistEarth", "resistFire", "resistLife", "resistWater", "stealth", "stealthDetect", "strength", and "wisdom". |
    | statsRune | The added rune stats of this item. May contain the same members as stats. |
    | statsRuneTemporary | The added temporary rune stats of this item. May contain the same members as stats. |
    | type | The item's type specifier. |

# Utility.Item.Slot.Guild

- Original source: utility_item_slot_guild.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Generates a slot specifier for the player's guild bank.

Generates a slot specifier for the player's guild bank.

### Usage:

| --- | --- | --- | --- |
| *slot* = Utility.Item.Slot.Guild() | | | |
| *slot* = Utility.Item.Slot.Guild(*vault*) | | | |
| *slot* = Utility.Item.Slot.Guild(*vault*, *slot*) | | | |
| Parameter | Type | Datatype | Description |
| *slot* | parameter | *number, slot* | The requested slot specifier. |
| *vault* | parameter | *number* | The vault ID to inspect. Starts at 1. |
| *slot* | result | *number, slot* | The requested slot specifier. |

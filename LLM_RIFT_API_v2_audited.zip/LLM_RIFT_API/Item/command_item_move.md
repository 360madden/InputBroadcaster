# Command.Item.Move

- Original source: command_item_move.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Moves an item from one location to another. This cannot move items directly between equipment, wardrobe, or guild bank - you'll have to stop off in the inventory first.

Moves an item from one location to another. This cannot move items directly between equipment, wardrobe, or guild bank - you'll have to stop off in the inventory first.

### Usage:

Interaction category: item

Throttled.

| --- | --- | --- | --- |
| Command.Item.Move(*source*, *destination*) | | | |
| Parameter | Type | Datatype | Description |
| *destination* | parameter | *slot* | The location to move the item. May attempt to stack or swap if there is already an item here. |
| *source* | parameter | *item, slot* | The item to move. Must be a slot specifier that refers to an actual item. |

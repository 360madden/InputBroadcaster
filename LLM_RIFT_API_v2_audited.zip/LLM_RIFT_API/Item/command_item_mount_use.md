# Command.Item.Mount.Use

- Original source: command_item_mount_use.html
- Category: Item
- Priority tier: Secondary
- Source index: Item_index.html

**Doc summary:** Uses a collected mount.

Uses a collected mount.

### Usage:

Throttled.

| --- | --- | --- | --- |
| Command.Item.Mount.Use(*mount*) | | | |
| Parameter | Type | Datatype | Description |
| *mount* | parameter | *item* | The item ID of the collected mount to use. |

# Command.Auction.Bid

- Original source: command_auction_bid.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Bids or buys out an auction.

Bids or buys out an auction.

### Usage:

Interaction category: auction

Throttled.

| --- | --- | --- | --- |
| Command.Auction.Bid(*auction*, *bid*) | | | |
| Command.Auction.Bid(*auction*, *bid*, *quantity*) | | | |
| Command.Auction.Bid(*auction*, *bid*, *callback*) | | | |
| Command.Auction.Bid(*auction*, *bid*, *quantity*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *auction* | parameter | *auction* | The auction to be targeted. |
| *bid* | parameter | *number* | The amount to bid. To place a buyout, simply bid the buyout value. |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *quantity* | parameter | *number* | How many items to purchase. If omitted, defaults to the entire auction quantity. |

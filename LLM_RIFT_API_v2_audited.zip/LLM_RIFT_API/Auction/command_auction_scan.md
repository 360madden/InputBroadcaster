# Command.Auction.Scan

- Original source: command_auction_scan.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Requests an auction house scan. For type "search", if "index" is omitted then this function will error if the "auctionfullscan" queue is not ready. Type "search" with "index" will throttle on the "auction" command queue. Other types throttle on the "global" command queue.

Requests an auction house scan. For type "search", if "index" is omitted then this function will error if the "auctionfullscan" queue is not ready. Type "search" with "index" will throttle on the "auction" command queue. Other types throttle on the "global" command queue.

### Usage:

Interaction category: auction

| --- | --- | --- | --- |
| Command.Auction.Scan(*parameters*) | | | |
| Parameter | Type | Datatype | Description |
| *parameters* | parameter | *table* | Table containing data about the requested scan.  type: Type of scan to perform. One of "bids", "buy", "mine", "orders", or "search".  If type is "bids", "mine", or "orders", no other parameters are allowed.  If type is "search":  category: Category to search for. Same as the "category" member returned by Inspect.Item.Detail(). Optional.  index: Numeric item index to start the scan at. If provided, the auction scan will return the first 50 items immediately following this index.  levelMax: Maximum level the item must require. Optional.  levelMin: Minimum level the item must require. Optional.  priceMax: Maximum price of the item. Optional.  priceMin: Minimum price of the item. Optional.  rarity: The minimum rarity to search for. Same as the "rarity" member returned by Inspect.Item.Detail(). Optional.  role: The role that the item must be compatible with. One of "mage", "rogue", "cleric", "warrior", or "primalist". Optional.  statType: Which stat to filter based on. One of "armor", "block", "critPower", "critSpell", "dexterity", "dodge", "endurance", "health", "hit", "intelligence", "mana", "powerAttack", "powerSpell", "resistAir", "resistDeath", "resistEarth", "resistFire", "resistLife", "resistWater", "strength", or "wisdom". Optional. If provided, statMin and statMax must also be provided.  statMax: Maximum allowed value for the filter stat. Optional. If provided, statType and statMin must also be provided.  statMin: Minimum allowed value for the filter stat. Optional. If provided, statType and statMax must also be provided.  sort: Which column the requested items should be sorted based on. One of "rarity", "name", "level", "time", "seller", "pricePerUnit", "bid", "buyout", "stack". Optional.  sortOrder: What order to sort in. One of "ascending" or "descending". Optional.  text: A string to search for in the item name. Optional.  type: Type of scan to perform. One of "search", "buy", "mine", or "bids". If "mine" or "bids", must be the only member in the table.  If type is "buy":  category: Category to search for. Same as the "category" member returned by Inspect.Item.Detail(). Optional.  text: A string to search for in the item name. Optional. |

**hardwareevent**
:   true

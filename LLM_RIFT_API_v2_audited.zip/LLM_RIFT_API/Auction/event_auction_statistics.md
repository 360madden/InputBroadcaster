# Event.Auction.Statistics

- Original source: event_auction_statistics.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Signals receipt of auction statistics.

Signals receipt of auction statistics.

### Usage:

| --- | --- | --- | --- |
| Event.Auction.Statistics(*itemtype*, *data*) | | | |
| Parameter | Type | Datatype | Description |
| *data* | parameter | *<nope>* | Table containing a series of tables with different timestamps, each containing data for a single day. |
| *itemtype* | parameter | *variant* | Item type that the attached statistics refer to. |

**members**
:   |  |  |
    | --- | --- |
    | priceAverage | Average item price during this day. |
    | priceMax | Maximum item price during this day. |
    | priceMin | Minimum item price during this day. |
    | priceVariance | Variance in item price during this day. |
    | time | UNIX timestamp of the day. |
    | volume | Quantity of items traded during this day. |

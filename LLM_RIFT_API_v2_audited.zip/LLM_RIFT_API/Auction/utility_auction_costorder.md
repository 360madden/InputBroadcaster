# Utility.Auction.CostOrder

- Original source: utility_auction_costorder.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Returns the amount of silver it will cost to post a given order.

Returns the amount of silver it will cost to post a given order.

### Usage:

| --- | --- | --- | --- |
| *cost* = Utility.Auction.CostOrder(*itemtype*, *quantity*, *time*, *buyout*) | | | |
| Parameter | Type | Datatype | Description |
| *buyout* | parameter | *number* | The total buyout for the new auction, in silver. Must be evenly divisible by quantity. |
| *itemtype* | parameter | *itemtype* | The item type to be ordered. |
| *quantity* | parameter | *number* | The number of items to be ordered. |
| *time* | parameter | *number* | The duration that the order should last, in hours. Valid values are limited to 12, 24, and 48. |
| *cost* | result | *number* | The cost of posting this order, in silver. Includes the full deposit for the items. |

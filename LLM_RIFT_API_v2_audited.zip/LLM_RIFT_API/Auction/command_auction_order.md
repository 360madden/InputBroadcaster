# Command.Auction.Order

- Original source: command_auction_order.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Posts a new buy order.

Posts a new buy order.

### Usage:

Interaction category: auction

Throttled.

| --- | --- | --- | --- |
| Command.Auction.Order(*itemtype*, *quantity*, *time*, *buyout*) | | | |
| Command.Auction.Order(*itemtype*, *quantity*, *time*, *buyout*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *buyout* | parameter | *number* | The total buyout for the new auction, in silver. Must be evenly divisible by quantity. |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *itemtype* | parameter | *itemtype* | The item type to be ordered. |
| *quantity* | parameter | *number* | The number of items to be ordered. |
| *time* | parameter | *number* | The duration that the order should last, in hours. Valid values are limited to 12, 24, and 48. |

# Command.Auction.Analyze

- Original source: command_auction_analyze.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Requests auction statistics from the server. The results will be sent to Event.Auction.Statistics. This command is throttled by the "auctionanalyze" throttle type, proportional to the number of days requested.

Requests auction statistics from the server. The results will be sent to Event.Auction.Statistics. This command is throttled by the "auctionanalyze" throttle type, proportional to the number of days requested.

### Usage:

Interaction category: auction

| --- | --- | --- | --- |
| Command.Auction.Analyze(*itemtype*, *begin*, *end*) | | | |
| Command.Auction.Analyze(*itemtype*, *begin*, *end*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *begin* | parameter | *number* | UNIX timestamp to begin analysis at. |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *end* | parameter | *number* | UNIX timestamp to end analysis at. |
| *itemtype* | parameter | *itemtype* | Item type to analyze. |

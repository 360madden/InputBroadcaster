# Command.Auction.Cancel

- Original source: command_auction_cancel.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Cancels an auction.

Cancels an auction.

### Usage:

Interaction category: auction

Throttled.

| --- | --- | --- | --- |
| Command.Auction.Cancel(*auction*) | | | |
| Command.Auction.Cancel(*auction*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *auction* | parameter | *auction* | The auction to be targeted. |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |

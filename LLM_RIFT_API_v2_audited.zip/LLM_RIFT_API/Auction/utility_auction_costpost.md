# Utility.Auction.CostPost

- Original source: utility_auction_costpost.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Returns the amount of silver it will cost to post a given auction.

Returns the amount of silver it will cost to post a given auction.

### Usage:

| --- | --- | --- | --- |
| *cost* = Utility.Auction.CostPost(*item*, *time*, *bid*, *buyout*) | | | |
| *cost* = Utility.Auction.CostPost(*item*, *time*, *bid*, *buyout*, *partial*) | | | |
| Parameter | Type | Datatype | Description |
| *bid* | parameter | *number/nil* | The minimum bid for the new auction, in silver. nil if no bid is desired. |
| *buyout* | parameter | *number/nil* | The buyout for the new auction, in silver. nil if no buyout is desired. |
| *item* | parameter | *item* | The ID of the item to be auctioned. |
| *partial* | parameter | *boolean* | Whether partial buyouts should be permitted. Must be "false" if a buyout is not provided or if a bid is provided that is different from the buyout. If this parameter is omitted, will default to "true" when possible, or "false" otherwise. |
| *time* | parameter | *number* | The duration that the auction should last, in hours. Valid values are limited to 12, 24, and 48. |
| *cost* | result | *number* | The cost of posting this auction, in silver. |

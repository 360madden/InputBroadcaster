# Command.Auction.Post

- Original source: command_auction_post.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Posts a new auction.

Posts a new auction.

### Usage:

Interaction category: auction

Throttled.

| --- | --- | --- | --- |
| Command.Auction.Post(*item*, *time*, *bid*, *buyout*) | | | |
| Command.Auction.Post(*item*, *time*, *bid*, *buyout*, *partial*) | | | |
| Command.Auction.Post(*item*, *time*, *bid*, *buyout*, *callback*) | | | |
| Command.Auction.Post(*item*, *time*, *bid*, *buyout*, *partial*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *bid* | parameter | *number/nil* | The minimum bid for the new auction, in silver. nil if no bid is desired. |
| *buyout* | parameter | *number/nil* | The buyout for the new auction, in silver. nil if no buyout is desired. |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *item* | parameter | *item* | The ID of the item to be auctioned. |
| *partial* | parameter | *boolean* | Whether partial buyouts should be permitted. Must be "false" if a buyout is not provided or if a bid is provided that is different from the buyout. If this parameter is omitted, will default to "true" when possible, or "false" otherwise. |
| *time* | parameter | *number* | The duration that the auction should last, in hours. Valid values are limited to 12, 24, and 48. |

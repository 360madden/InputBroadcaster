# Event.Auction.Scan

- Original source: event_auction_scan.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Signals incoming auction data.

Signals incoming auction data.

### Usage:

| --- | --- | --- | --- |
| Event.Auction.Scan(*type*, *auctions*) | | | |
| Parameter | Type | Datatype | Description |
| *auctions* | parameter | *<nope>* | A table of the auctions returned from this scan. |
| *type* | parameter | *variant* | A table containing information on this scan. In the same format as the parameter to Command.Auction.Scan(). |

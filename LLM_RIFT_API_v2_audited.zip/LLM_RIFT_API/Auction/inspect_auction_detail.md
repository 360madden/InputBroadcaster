# Inspect.Auction.Detail

- Original source: inspect_auction_detail.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Provides detailed information about auctions.

Provides detailed information about auctions.

### Usage:

Interaction category: auction

| --- | --- | --- | --- |
| *detail* = Inspect.Auction.Detail(*auction*) | | | |
| *details* = Inspect.Auction.Detail(*auctions*) | | | |
| Parameter | Type | Datatype | Description |
| *auction* | parameter | *auction* | An identifier for the auction to retrieve detail for. |
| *auctions* | parameter | *table* | A table containing auction identifiers to retrieve details for. The value is the sort order. |
| *detail* | result | *table* | Detail table for a single auction. |
| *details* | result | *table* | Detail tables for all requested auctions. The key is the auction ID, the value is the auction's detail table. |

**members**
:   |  |  |
    | --- | --- |
    | bid | The current bid on this auction, in silver. |
    | bidder | Current high bidder on this auction. Available only if your current character is the bidder or the seller. |
    | buyout | The buyout amount for this auction, in silver. |
    | id | The ID of the requested element. |
    | item | ID of the item involved in the auction. |
    | itemStack | The size of this item stack. |
    | itemType | The item's type specifier. |
    | partial | Whether partial buyouts are permitted. |
    | remaining | Time remaining in the auction, as a number of seconds. |
    | seller | The name of the auction's seller. |

# Command.Auction.Fulfill

- Original source: command_auction_fulfill.html
- Category: Auction
- Priority tier: Secondary
- Source index: Auction_index.html

**Doc summary:** Fulfills an existing buy order.

Fulfills an existing buy order.

### Usage:

Interaction category: auction

Throttled.

| --- | --- | --- | --- |
| Command.Auction.Fulfill(*auction*, *item*, *quantity*) | | | |
| Command.Auction.Fulfill(*auction*, *item*, *quantity*, *callback*) | | | |
| Parameter | Type | Datatype | Description |
| *auction* | parameter | *auction* | The auction to be targeted. |
| *callback* | parameter | *callbackfunction* | A standard command callback, used for detecting success or failure. See the "callbackfunction" documentation for more details. |
| *item* | parameter | *item* | The ID of the item to be taken. |
| *quantity* | parameter | *number* | Stack size to fulfill. |

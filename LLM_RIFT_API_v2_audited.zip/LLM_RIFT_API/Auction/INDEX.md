# Auction
**Priority:** Secondary
**Purpose:** Auction inspection, events, and commands.
**Entry count:** 13
## Most important files first
- [Inspect.Auction.Detail](inspect_auction_detail.md) — Provides detailed information about auctions.
- [Command.Auction.Analyze](command_auction_analyze.md) — Requests auction statistics from the server. The results will be sent to Event.Auction.Statistics...
- [Command.Auction.Bid](command_auction_bid.md) — Bids or buys out an auction.
- [Command.Auction.Cancel](command_auction_cancel.md) — Cancels an auction.
- [Command.Auction.Fulfill](command_auction_fulfill.md) — Fulfills an existing buy order.
- [Command.Auction.Order](command_auction_order.md) — Posts a new buy order.
- [Command.Auction.Post](command_auction_post.md) — Posts a new auction.
- [Command.Auction.Scan](command_auction_scan.md) — Requests an auction house scan. For type "search", if "index" is omitted then this function will ...

## Full file list
- [Inspect.Auction.Detail](inspect_auction_detail.md) — Provides detailed information about auctions.
- [Command.Auction.Analyze](command_auction_analyze.md) — Requests auction statistics from the server. The results will be sent to Event.Auction.Statistics...
- [Command.Auction.Bid](command_auction_bid.md) — Bids or buys out an auction.
- [Command.Auction.Cancel](command_auction_cancel.md) — Cancels an auction.
- [Command.Auction.Fulfill](command_auction_fulfill.md) — Fulfills an existing buy order.
- [Command.Auction.Order](command_auction_order.md) — Posts a new buy order.
- [Command.Auction.Post](command_auction_post.md) — Posts a new auction.
- [Command.Auction.Scan](command_auction_scan.md) — Requests an auction house scan. For type "search", if "index" is omitted then this function will ...
- [Event.Auction.Scan](event_auction_scan.md) — Signals incoming auction data.
- [Event.Auction.Statistics](event_auction_statistics.md) — Signals receipt of auction statistics.
- [Utility.Auction.Cost](utility_auction_cost.md) — Returns the amount of silver it will cost to post a given auction. (deprecated)
- [Utility.Auction.CostOrder](utility_auction_costorder.md) — Returns the amount of silver it will cost to post a given order.
- [Utility.Auction.CostPost](utility_auction_costpost.md) — Returns the amount of silver it will cost to post a given auction.
